package com.sfbest.financial.db.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

/**
 * Created by 603513 on 2017/2/23.
 */
@Component
@PropertySource(value={"classpath:application-dbdev.properties","classpath:application-dbprod.properties","classpath:application-dbtest.properties"})
public class DruidDBConfig {

    @Value("${datasource-config.initialSize}")
    private int initialSize;

    @Value("${datasource-config.minIdle}")
    private int minIdle;

    @Value("${datasource-config.maxActive}")
    private int maxActive;

    @Value("${datasource-config.maxWait}")
    private int maxWait;

    @Value("${datasource-config.timeBetweenEvictionRunsMillis}")
    private int timeBetweenEvictionRunsMillis;

    @Value("${datasource-config.minEvictableIdleTimeMillis}")
    private int minEvictableIdleTimeMillis;

    @Value("${datasource-config.validationQuery}")
    private String validationQuery;

    @Value("${datasource-config.testWhileIdle}")
    private boolean testWhileIdle;

    @Value("${datasource-config.testOnBorrow}")
    private boolean testOnBorrow;

    @Value("${datasource-config.testOnReturn}")
    private boolean testOnReturn;

    @Value("${datasource-config.poolPreparedStatements}")
    private boolean poolPreparedStatements;

    @Value("${datasource-config.maxPoolPreparedStatementPerConnectionSize}")
    private int maxPoolPreparedStatementPerConnectionSize;

    @Value("${datasource-config.filters}")
    private String filters;

    @Value("{datasource-config.connectionProperties}")
    private String connectionProperties;


    @Value("${datasource-config.drvier}")
    private String driverClassName;

    public DruidDataSource prepareDataSource(){
        DruidDataSource datasource = new DruidDataSource();
        datasource.setDriverClassName(driverClassName);
        //configuration
        datasource.setInitialSize(initialSize);
        datasource.setMinIdle(minIdle);
        datasource.setMaxActive(maxActive);
        datasource.setMaxWait(maxWait);
        datasource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        datasource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
        datasource.setValidationQuery(validationQuery);
        datasource.setTestWhileIdle(testWhileIdle);
        datasource.setTestOnBorrow(testOnBorrow);
        datasource.setTestOnReturn(testOnReturn);
        datasource.setPoolPreparedStatements(poolPreparedStatements);
        datasource.setMaxPoolPreparedStatementPerConnectionSize(maxPoolPreparedStatementPerConnectionSize);
        try {
            datasource.setFilters(filters);
        } catch (SQLException e) {
            //logger.error("druid configuration initialization filter", e);
        }
        datasource.setConnectionProperties(connectionProperties);

        return datasource;
    }




}
