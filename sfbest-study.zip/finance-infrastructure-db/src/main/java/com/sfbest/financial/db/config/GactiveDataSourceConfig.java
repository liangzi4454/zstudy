package com.sfbest.financial.db.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.sfbest.financial.db.datasource.DynamicDataSource;
import com.sfbest.financial.db.datasource.DynamicDataSourceGlobal;
import com.sfbest.financial.db.datasource.DynamicDataSourceTransactionManager;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by 01061941 on 2017/3/27.
 */
@Configuration
@MapperScan(basePackages = GactiveDataSourceConfig.PACKAGE, sqlSessionFactoryRef = "gactiveSqlSessionFactory",sqlSessionTemplateRef = "gactiveSessionTemplate")
public class GactiveDataSourceConfig {
    static final String PACKAGE="com.sfbest.financial.db.mapper.gactive";

    @Autowired
    DruidDBConfig config;

    @Bean(name="gactiveReadSource")     //声明其为Bean实例
    public DataSource gactiveReadSource( @Value("${datasources.gactive.read.name}")String name ,@Value("${datasources.gactive.read.url}")String url,@Value("${datasources.gactive.read.username}")String username, @Value("${datasources.gactive.read.password}")String password){

        DruidDataSource dataSource=config.prepareDataSource();
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setName(name);
        return dataSource;
    }

    @Bean(name="gactiveWriteSource")     //声明其为Bean实例
    public DataSource gactiveWriteSource( @Value("${datasources.gactive.write.name}")String name ,@Value("${datasources.gactive.write.url}")String url,@Value("${datasources.gactive.write.username}")String username, @Value("${datasources.gactive.write.password}")String password){

        DruidDataSource dataSource=config.prepareDataSource();
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setName(name);
        return dataSource;
    }

    @Bean(name="dynamicGactiveDataSource")
    public DataSource dynamicGactiveDataSource(@Qualifier("gactiveReadSource") DataSource readSource,@Qualifier("gactiveWriteSource") DataSource writeSource){
        DynamicDataSource dataSource=new DynamicDataSource();
        Map<Object, Object> dataSourceMap = new HashMap<>();
        dataSourceMap.put(DynamicDataSourceGlobal.READ.name(), readSource);
        dataSourceMap.put(DynamicDataSourceGlobal.WRITE.name(), writeSource);
        dataSource.setTargetDataSources(dataSourceMap);
        dataSource.setDefaultTargetDataSource(readSource);
        return dataSource;
    }

    @Bean(name="gactiveTransactionManager")
    public DataSourceTransactionManager gactiveTransactionManager(@Qualifier("dynamicGactiveDataSource")DataSource dataSource){
        DataSourceTransactionManager transactionManager=  new DynamicDataSourceTransactionManager();
        transactionManager.setDataSource(dataSource);
        return transactionManager;
    }
    @Bean(name = "gactiveSqlSessionFactory")
    public SqlSessionFactory adsSqlSessionFactory(@Qualifier("dynamicGactiveDataSource") DataSource adsDataSource) throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(adsDataSource);
        ResourcePatternResolver loader = new PathMatchingResourcePatternResolver();
        sessionFactory.setMapperLocations(loader.getResources ("classpath*:/mybatis/mapper/gactive/*.xml"));
        return sessionFactory.getObject();
    }

    @Bean(name="gactiveSessionTemplate")
    public SqlSessionTemplate gfdSessionTemplate(@Qualifier("gactiveSqlSessionFactory")SqlSessionFactory factoryBean){
        return new SqlSessionTemplate(factoryBean);
    }
}
