package com.sfbest.financial.db.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.sfbest.financial.db.datasource.DynamicDataSource;
import com.sfbest.financial.db.datasource.DynamicDataSourceGlobal;
import com.sfbest.financial.db.datasource.DynamicDataSourceTransactionManager;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by 603513 on 2017/2/24.
 */
@Configuration
@MapperScan(basePackages = GfdDataSourceConfig.PACKAGE, sqlSessionFactoryRef = "gfdSqlSessionFactory",sqlSessionTemplateRef="gfdSessionTemplate")
public class GfdDataSourceConfig {

     static final String PACKAGE="com.sfbest.financial.db.mapper.gfd";

    @Autowired
    DruidDBConfig config;



    @Bean(name="gfdReadSource")     //声明其为Bean实例
    public DataSource gfdReadSource( @Value("${datasources.gfd.read.name}")String name ,@Value("${datasources.gfd.read.url}")String url,@Value("${datasources.gfd.read.username}")String username, @Value("${datasources.gfd.read.password}")String password){

        DruidDataSource dataSource=config.prepareDataSource();
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setName(name);

        //configuration


        return dataSource;
    }

    @Bean(name="gfdWriteSource")     //声明其为Bean实例
    public DataSource gfdWriteSource( @Value("${datasources.gfd.write.name}")String name ,@Value("${datasources.gfd.write.url}")String url,@Value("${datasources.gfd.write.username}")String username, @Value("${datasources.gfd.write.password}")String password){

        DruidDataSource dataSource=config.prepareDataSource();
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setName(name);
        return dataSource;
    }

    @Bean(name="dynamicGfdDataSource")
    public DataSource dynamicGfdDataSource(@Qualifier("gfdReadSource") DataSource readSource,@Qualifier("gfdWriteSource") DataSource writeSource){
        DynamicDataSource dataSource=new DynamicDataSource();
        Map<Object, Object> dataSourceMap = new HashMap<>();
        dataSourceMap.put(DynamicDataSourceGlobal.READ.name(), readSource);
        dataSourceMap.put(DynamicDataSourceGlobal.WRITE.name(), writeSource);
        dataSource.setTargetDataSources(dataSourceMap);
        dataSource.setDefaultTargetDataSource(readSource);
        return dataSource;
    }

    @Bean(name="gfdTransactionManager")
    public DataSourceTransactionManager gfdTransactionManager(@Qualifier("dynamicGfdDataSource")DataSource dataSource){
        DataSourceTransactionManager transactionManager=  new DynamicDataSourceTransactionManager();
        transactionManager.setDataSource(dataSource);
        return transactionManager;
    }
    @Bean(name = "gfdSqlSessionFactory")
    public SqlSessionFactory adsSqlSessionFactory(@Qualifier("dynamicGfdDataSource") DataSource adsDataSource) throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(adsDataSource);
        ResourcePatternResolver loader = new PathMatchingResourcePatternResolver();
        sessionFactory.setMapperLocations(loader.getResources ("classpath*:/mybatis/mapper/gfd/*.xml"));
        return sessionFactory.getObject();
    }

    @Bean(name="gfdSessionTemplate")
    public SqlSessionTemplate gfdSessionTemplate(@Qualifier("gfdSqlSessionFactory")SqlSessionFactory factoryBean){
        return new SqlSessionTemplate(factoryBean);
    }

}

