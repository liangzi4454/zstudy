package com.sfbest.financial.db.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.sfbest.financial.db.datasource.DynamicDataSource;
import com.sfbest.financial.db.datasource.DynamicDataSourceGlobal;
import com.sfbest.financial.db.datasource.DynamicDataSourceTransactionManager;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by LHY on 2017/3/7.
 */
@Configuration
@MapperScan(basePackages = GfmDataSourceConfig.PACKAGE, sqlSessionFactoryRef = "gfmSqlSessionFactory",sqlSessionTemplateRef="gfmSessionTemplate")
public class GfmDataSourceConfig {

    static final String PACKAGE="com.sfbest.financial.db.mapper.gfm";

    @Autowired
    DruidDBConfig config;

    @Bean(name="gfmReadSource")     //声明其为Bean实例
    public DataSource gfmReadSource( @Value("${datasources.gfm.read.name}")String name ,@Value("${datasources.gfm.read.url}")String url,@Value("${datasources.gfm.read.username}")String username, @Value("${datasources.gfm.read.password}")String password){
        DruidDataSource dataSource=config.prepareDataSource();
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setName(name);
        return dataSource;
    }

    @Bean(name="gfmWriteSource")     //声明其为Bean实例
    public DataSource gfmWriteSource( @Value("${datasources.gfm.write.name}")String name ,@Value("${datasources.gfm.write.url}")String url,@Value("${datasources.gfm.write.username}")String username, @Value("${datasources.gfm.write.password}")String password){
        DruidDataSource dataSource=config.prepareDataSource();
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setName(name);
        return dataSource;
    }

    @Bean(name="dynamicgfmDataSource")
    public DataSource dynamicgfmDataSource(@Qualifier("gfmReadSource") DataSource readSource, @Qualifier("gfmWriteSource") DataSource writeSource){
        DynamicDataSource dataSource=new DynamicDataSource();
        Map<Object, Object> dataSourceMap = new HashMap<>();
        dataSourceMap.put(DynamicDataSourceGlobal.READ.name(), readSource);
        dataSourceMap.put(DynamicDataSourceGlobal.WRITE.name(), writeSource);
        dataSource.setTargetDataSources(dataSourceMap);
        dataSource.setDefaultTargetDataSource(readSource);
        return dataSource;
    }

    @Bean(name="gfmTransactionManager")
    public DataSourceTransactionManager gfmTransactionManager(@Qualifier("dynamicgfmDataSource")DataSource dataSource){
        DataSourceTransactionManager transactionManager=  new DynamicDataSourceTransactionManager();
        transactionManager.setDataSource(dataSource);
        return transactionManager;
    }
    @Bean(name = "gfmSqlSessionFactory")
    public SqlSessionFactory adsSqlSessionFactory(@Qualifier("dynamicgfmDataSource") DataSource adsDataSource) throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(adsDataSource);
        ResourcePatternResolver loader = new PathMatchingResourcePatternResolver();
        sessionFactory.setMapperLocations(loader.getResources ("classpath*:/mybatis/mapper/gfm/*.xml"));
        return sessionFactory.getObject();
    }

    @Bean(name="gfmSessionTemplate")
    public SqlSessionTemplate gfmSessionTemplate(@Qualifier("gfmSqlSessionFactory")SqlSessionFactory factoryBean){
        return new SqlSessionTemplate(factoryBean);
    }

}

