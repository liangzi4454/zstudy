package com.sfbest.financial.db.datasource;

/**
 * Created by 603513 on 2017/2/24.
 */
public enum DynamicDataSourceGlobal {
    READ, WRITE;
}