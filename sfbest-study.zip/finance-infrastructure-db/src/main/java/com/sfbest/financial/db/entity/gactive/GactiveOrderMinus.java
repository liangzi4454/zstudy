package com.sfbest.financial.db.entity.gactive;

import java.io.Serializable;

/**
 * Created by 01061941 on 2017/3/27.
 */
public class GactiveOrderMinus implements Serializable {

    private static final long serialVersionUID = 6916674074972887589L;
    private Integer actId;
    private Double platformAssumeProportion;
    private Double merchantAssumeProportion;

    public Integer getActId() {
        return actId;
    }

    public void setActId(Integer actId) {
        this.actId = actId;
    }

    public Double getPlatformAssumeProportion() {
        return platformAssumeProportion;
    }

    public void setPlatformAssumeProportion(Double platformAssumeProportion) {
        this.platformAssumeProportion = platformAssumeProportion;
    }

    public Double getMerchantAssumeProportion() {
        return merchantAssumeProportion;
    }

    public void setMerchantAssumeProportion(Double merchantAssumeProportion) {
        this.merchantAssumeProportion = merchantAssumeProportion;
    }
}
