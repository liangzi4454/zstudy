package com.sfbest.financial.db.entity.gfd;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *  物资出入库,采购盘点等做账的中间表
 * @Author:01237177 王拓
 * @date:2017/3/3
 */
public class GfdAccountCertification implements Serializable {
    private Integer id;
    /** 账单编号 */
    private String billCode;
    /** 发票编号 */
    private String invoiceCode;
    /** 月结卡号 */
    private String customerCode;
    /** 月结卡号对应的网点 */
    private String zoneCode;
    /** 集团客户编码(结算账号) */
    private String vipCode;
    /** 结算账号对应的网点 */
    private String vipZoneCode;
    /** 总账日期 */
    private Long glDt;
    /** 完整帐期标志(0-非完整帐期发票，1-完整帐期发票) */
    private String billEndInvFlg;
    /** 发票开始日期 */
    private Long startDt;
    /** 发票结束日期 */
    private Long endDt;
    /** 账期开始日期 */
    private Long billStartDt;
    /** 账期结束日期 */
    private Long billEndDt;
    /** 账期 */
    private Long billPeriod;
    /** 付款条件（必须为数字） */
    private Integer paymentTerm;
    /** 到期日 */
    private Long paymentDueDt;
    /** 合同帐户类别 */
    private String vktyp;
    /** 行项目主业务 */
    private String mainTransaction;
    /** 凭证项的分事务 */
    private String subTransaction;
    /** 账单版本号 */
    private String billVersionNo;
    /** 总计输入金额（单位：元） */
    private BigDecimal amount;
    /** 货币码 */
    private String currencyCode;
    /** 收款批次号 */
    private String receiptBatchNumber;
    /** BU类型 */
    private String buType;
    /** 系统来源 */
    private String sourceSys;
    /** 账单行记录数 */
    private Integer billCnt;
    /** ECBIL记录唯一ID */
    private String uniqueId;
    /** BG代码 */
    private String bgCode;
    /** 销售/购买税代码  */
    private String taxCode;
    /** 税率(销项税和进项税) **/
    private Double tax;
    /** 部门 */
    private String depart;
    /** 供应商编码 **/
    private String supplierNumber;
    /** 出入库单号 **/
    private String ioNumber;
    /** 费用类型 */
    private String chargeItemCode;
    /** 拆税区域类型 */
    private String regionTypeCode;
    /** 拆税规则代码 */
    private String taxRuleCode;
    /** 处理状态:0未处理,1已处理,2处理失败 */
    private String dealStatus;
    /** 创建时间 */
    private Integer createTime;

    /** 总账日期: 不做入库处理只做展示使用 */
    private String glDtStr;
    /** 发票开始日期: 不做入库处理只做展示使用 */
    private String startDtStr;
    /** 发票结束日期: 不做入库处理只做展示使用 */
    private String endDtStr;
    /** 账期开始日期: 不做入库处理只做展示使用 */
    private String billStartDtStr;
    /** 账期结束日期: 不做入库处理只做展示使用 */
    private String billEndDtStr;
    /** 账期: 不做入库处理只做展示使用 */
    private String billPeriodStr;
    /** 到期日: 不做入库处理只做展示使用 */
    private String paymentDueDtStr;
    /** 创建时间: 不做入库处理只做展示使用 **/
    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBillCode() {
        return billCode;
    }

    public void setBillCode(String billCode) {
        this.billCode = billCode == null ? null : billCode.trim();
    }

    public String getInvoiceCode() {
        return invoiceCode;
    }

    public void setInvoiceCode(String invoiceCode) {
        this.invoiceCode = invoiceCode == null ? null : invoiceCode.trim();
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode == null ? null : customerCode.trim();
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode == null ? null : zoneCode.trim();
    }

    public String getVipCode() {
        return vipCode;
    }

    public void setVipCode(String vipCode) {
        this.vipCode = vipCode == null ? null : vipCode.trim();
    }

    public String getVipZoneCode() {
        return vipZoneCode;
    }

    public void setVipZoneCode(String vipZoneCode) {
        this.vipZoneCode = vipZoneCode == null ? null : vipZoneCode.trim();
    }

    public Long getGlDt() {
        return glDt;
    }

    public void setGlDt(Long glDt) {
        this.glDt = glDt;
    }

    public String getBillEndInvFlg() {
        return billEndInvFlg;
    }

    public void setBillEndInvFlg(String billEndInvFlg) {
        this.billEndInvFlg = billEndInvFlg;
    }

    public Long getStartDt() {
        return startDt;
    }

    public void setStartDt(Long startDt) {
        this.startDt = startDt;
    }

    public Long getEndDt() {
        return endDt;
    }

    public void setEndDt(Long endDt) {
        this.endDt = endDt;
    }

    public Long getBillStartDt() {
        return billStartDt;
    }

    public void setBillStartDt(Long billStartDt) {
        this.billStartDt = billStartDt;
    }

    public Long getBillEndDt() {
        return billEndDt;
    }

    public void setBillEndDt(Long billEndDt) {
        this.billEndDt = billEndDt;
    }

    public Long getBillPeriod() {
        return billPeriod;
    }

    public void setBillPeriod(Long billPeriod) {
        this.billPeriod = billPeriod;
    }

    public Integer getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(Integer paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    public Long getPaymentDueDt() {
        return paymentDueDt;
    }

    public void setPaymentDueDt(Long paymentDueDt) {
        this.paymentDueDt = paymentDueDt;
    }

    public String getVktyp() {
        return vktyp;
    }

    public void setVktyp(String vktyp) {
        this.vktyp = vktyp;
    }

    public String getMainTransaction() {
        return mainTransaction;
    }

    public void setMainTransaction(String mainTransaction) {
        this.mainTransaction = mainTransaction == null ? null : mainTransaction.trim();
    }

    public String getSubTransaction() {
        return subTransaction;
    }

    public void setSubTransaction(String subTransaction) {
        this.subTransaction = subTransaction == null ? null : subTransaction.trim();
    }

    public String getBillVersionNo() {
        return billVersionNo;
    }

    public void setBillVersionNo(String billVersionNo) {
        this.billVersionNo = billVersionNo;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode == null ? null : currencyCode.trim();
    }

    public String getReceiptBatchNumber() {
        return receiptBatchNumber;
    }

    public void setReceiptBatchNumber(String receiptBatchNumber) {
        this.receiptBatchNumber = receiptBatchNumber == null ? null : receiptBatchNumber.trim();
    }

    public String getBuType() {
        return buType;
    }

    public void setBuType(String buType) {
        this.buType = buType == null ? null : buType.trim();
    }

    public String getSourceSys() {
        return sourceSys;
    }

    public void setSourceSys(String sourceSys) {
        this.sourceSys = sourceSys == null ? null : sourceSys.trim();
    }

    public Integer getBillCnt() {
        return billCnt;
    }

    public void setBillCnt(Integer billCnt) {
        this.billCnt = billCnt;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId == null ? null : uniqueId.trim();
    }

    public String getBgCode() {
        return bgCode;
    }

    public void setBgCode(String bgCode) {
        this.bgCode = bgCode == null ? null : bgCode.trim();
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode == null ? null : taxCode.trim();
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart == null ? null : depart.trim();
    }

    public String getSupplierNumber() {
        return supplierNumber;
    }

    public void setSupplierNumber(String supplierNumber) {
        this.supplierNumber = supplierNumber;
    }

    public String getIoNumber() {
        return ioNumber;
    }

    public void setIoNumber(String ioNumber) {
        this.ioNumber = ioNumber;
    }

    public String getChargeItemCode() {
        return chargeItemCode;
    }

    public void setChargeItemCode(String chargeItemCode) {
        this.chargeItemCode = chargeItemCode == null ? null : chargeItemCode.trim();
    }

    public String getRegionTypeCode() {
        return regionTypeCode;
    }

    public void setRegionTypeCode(String regionTypeCode) {
        this.regionTypeCode = regionTypeCode == null ? null : regionTypeCode.trim();
    }

    public String getTaxRuleCode() {
        return taxRuleCode;
    }

    public void setTaxRuleCode(String taxRuleCode) {
        this.taxRuleCode = taxRuleCode == null ? null : taxRuleCode.trim();
    }

    public String getDealStatus() {
        return dealStatus;
    }

    public void setDealStatus(String dealStatus) {
        this.dealStatus = dealStatus;
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public String getGlDtStr() {
        return glDtStr;
    }

    public void setGlDtStr(String glDtStr) {
        this.glDtStr = glDtStr;
    }

    public String getStartDtStr() {
        return startDtStr;
    }

    public void setStartDtStr(String startDtStr) {
        this.startDtStr = startDtStr;
    }

    public String getEndDtStr() {
        return endDtStr;
    }

    public void setEndDtStr(String endDtStr) {
        this.endDtStr = endDtStr;
    }

    public String getBillStartDtStr() {
        return billStartDtStr;
    }

    public void setBillStartDtStr(String billStartDtStr) {
        this.billStartDtStr = billStartDtStr;
    }

    public String getBillEndDtStr() {
        return billEndDtStr;
    }

    public void setBillEndDtStr(String billEndDtStr) {
        this.billEndDtStr = billEndDtStr;
    }

    public String getBillPeriodStr() {
        return billPeriodStr;
    }

    public void setBillPeriodStr(String billPeriodStr) {
        this.billPeriodStr = billPeriodStr;
    }

    public String getPaymentDueDtStr() {
        return paymentDueDtStr;
    }

    public void setPaymentDueDtStr(String paymentDueDtStr) {
        this.paymentDueDtStr = paymentDueDtStr;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}