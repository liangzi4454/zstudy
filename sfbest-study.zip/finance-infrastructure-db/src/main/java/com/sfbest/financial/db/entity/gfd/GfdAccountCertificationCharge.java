package com.sfbest.financial.db.entity.gfd;

public class GfdAccountCertificationCharge {

    private Integer id;

    private String workName;

    private String className;

    private String chargeItemCodes;

    private String description;

    private Integer createTime;

    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWorkName() {
        return workName;
    }

    public void setWorkName(String workName) {
        this.workName = workName == null ? null : workName.trim();
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className == null ? null : className.trim();
    }

    public String getChargeItemCodes() {
        return chargeItemCodes;
    }

    public void setChargeItemCodes(String chargeItemCodes) {
        this.chargeItemCodes = chargeItemCodes == null ? null : chargeItemCodes.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}