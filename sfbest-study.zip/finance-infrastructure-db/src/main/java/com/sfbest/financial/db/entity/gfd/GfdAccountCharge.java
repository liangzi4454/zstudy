package com.sfbest.financial.db.entity.gfd;

/**
 * 费用类型实体
 */
public class GfdAccountCharge {

    private Integer id;
    /** 费用类型编码 **/
    private String chargeItemCode;
    /** 费用类型名称 **/
    private String chargeItemName;
    /** 创建时间 **/
    private Integer createTime;
    /** 创建时间: 不做入库处理只做展示使用 **/
    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getChargeItemCode() {
        return chargeItemCode;
    }

    public void setChargeItemCode(String chargeItemCode) {
        this.chargeItemCode = chargeItemCode;
    }

    public String getChargeItemName() {
        return chargeItemName;
    }

    public void setChargeItemName(String chargeItemName) {
        this.chargeItemName = chargeItemName;
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}