package com.sfbest.financial.db.entity.gfd;

/**
 * 费用类型实体,在创建模板的时候关联该表
 */
public class GfdAccountChargeItem {

    private Integer id;
    /** 费用类型id **/
    private Integer chargeId;
    /** 模板表外键 **/
    private Integer mouldId;
    /** 创建时间 **/
    private Integer createTime;
    /** 费用类型编码,不做入库处理,只做查询处理 **/
    private String chargeItemCode;
    /** 创建时间: 不做入库处理只做展示使用 **/
    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChargeId() {
        return chargeId;
    }

    public void setChargeId(Integer chargeId) {
        this.chargeId = chargeId;
    }

    public Integer getMouldId() {
        return mouldId;
    }

    public void setMouldId(Integer mouldId) {
        this.mouldId = mouldId;
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public String getChargeItemCode() {
        return chargeItemCode;
    }

    public void setChargeItemCode(String chargeItemCode) {
        this.chargeItemCode = chargeItemCode;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}