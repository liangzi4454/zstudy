package com.sfbest.financial.db.entity.gfd;

import java.math.BigDecimal;
import java.util.Date;

/**
* @Author:01237177 
* @date:2017/3/11
*/
public class GfdAccountDetail {
    private Integer id;

    private String detailSn;

    private String headerSn;

    private String billId;

    private String billType;

    private Date billDate;

    private String accountType;

    private Integer entryId;

    private String subjectCode;

    private String summary;

    private String settlement;

    private String doucumentId;

    private String documentDate;

    private String currency;

    private BigDecimal unitPrice;

    private BigDecimal exchangeRate1;

    private BigDecimal exchangeRate2;

    private Integer debitCnt;

    private BigDecimal primaryDebitAmount;

    private BigDecimal secondaryDebitAmount;

    private BigDecimal naturalDebitCurrency;

    private Integer creditCnt;

    private BigDecimal primaryCreditAmount;

    private BigDecimal secondaryCreditAmount;

    private BigDecimal naturalCreditCurrency;

    private Integer debitType;

    private String processNo;

    private String sendErrorMsg;

    private Integer sendFlag;

    private String ncTs;

    private String workCenter;

    private String workNetwork;

    private String item1;

    private String item2;

    private String item3;

    private String item4;

    private String item5;

    private String item6;

    private String item7;

    private String item8;

    private String item9;

    private String item10;

    private Integer createTime;

    private Date modifiedTime;

    private Integer isDeleted;

    /** 创建时间: 不做入库处理只做展示使用 **/
    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDetailSn() {
        return detailSn;
    }

    public void setDetailSn(String detailSn) {
        this.detailSn = detailSn == null ? null : detailSn.trim();
    }

    public String getHeaderSn() {
        return headerSn;
    }

    public void setHeaderSn(String headerSn) {
        this.headerSn = headerSn == null ? null : headerSn.trim();
    }

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId == null ? null : billId.trim();
    }

    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType == null ? null : billType.trim();
    }

    public Date getBillDate() {
        return billDate;
    }

    public void setBillDate(Date billDate) {
        this.billDate = billDate;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType == null ? null : accountType.trim();
    }

    public Integer getEntryId() {
        return entryId;
    }

    public void setEntryId(Integer entryId) {
        this.entryId = entryId;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode == null ? null : subjectCode.trim();
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary == null ? null : summary.trim();
    }

    public String getSettlement() {
        return settlement;
    }

    public void setSettlement(String settlement) {
        this.settlement = settlement == null ? null : settlement.trim();
    }

    public String getDoucumentId() {
        return doucumentId;
    }

    public void setDoucumentId(String doucumentId) {
        this.doucumentId = doucumentId == null ? null : doucumentId.trim();
    }

    public String getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate == null ? null : documentDate.trim();
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public BigDecimal getExchangeRate1() {
        return exchangeRate1;
    }

    public void setExchangeRate1(BigDecimal exchangeRate1) {
        this.exchangeRate1 = exchangeRate1;
    }

    public BigDecimal getExchangeRate2() {
        return exchangeRate2;
    }

    public void setExchangeRate2(BigDecimal exchangeRate2) {
        this.exchangeRate2 = exchangeRate2;
    }

    public Integer getDebitCnt() {
        return debitCnt;
    }

    public void setDebitCnt(Integer debitCnt) {
        this.debitCnt = debitCnt;
    }

    public BigDecimal getPrimaryDebitAmount() {
        return primaryDebitAmount;
    }

    public void setPrimaryDebitAmount(BigDecimal primaryDebitAmount) {
        this.primaryDebitAmount = primaryDebitAmount;
    }

    public BigDecimal getSecondaryDebitAmount() {
        return secondaryDebitAmount;
    }

    public void setSecondaryDebitAmount(BigDecimal secondaryDebitAmount) {
        this.secondaryDebitAmount = secondaryDebitAmount;
    }

    public BigDecimal getNaturalDebitCurrency() {
        return naturalDebitCurrency;
    }

    public void setNaturalDebitCurrency(BigDecimal naturalDebitCurrency) {
        this.naturalDebitCurrency = naturalDebitCurrency;
    }

    public Integer getCreditCnt() {
        return creditCnt;
    }

    public void setCreditCnt(Integer creditCnt) {
        this.creditCnt = creditCnt;
    }

    public BigDecimal getPrimaryCreditAmount() {
        return primaryCreditAmount;
    }

    public void setPrimaryCreditAmount(BigDecimal primaryCreditAmount) {
        this.primaryCreditAmount = primaryCreditAmount;
    }

    public BigDecimal getSecondaryCreditAmount() {
        return secondaryCreditAmount;
    }

    public void setSecondaryCreditAmount(BigDecimal secondaryCreditAmount) {
        this.secondaryCreditAmount = secondaryCreditAmount;
    }

    public BigDecimal getNaturalCreditCurrency() {
        return naturalCreditCurrency;
    }

    public void setNaturalCreditCurrency(BigDecimal naturalCreditCurrency) {
        this.naturalCreditCurrency = naturalCreditCurrency;
    }

    public Integer getDebitType() {
        return debitType;
    }

    public void setDebitType(Integer debitType) {
        this.debitType = debitType;
    }

    public String getProcessNo() {
        return processNo;
    }

    public void setProcessNo(String processNo) {
        this.processNo = processNo == null ? null : processNo.trim();
    }

    public String getSendErrorMsg() {
        return sendErrorMsg;
    }

    public void setSendErrorMsg(String sendErrorMsg) {
        this.sendErrorMsg = sendErrorMsg == null ? null : sendErrorMsg.trim();
    }

    public Integer getSendFlag() {
        return sendFlag;
    }

    public void setSendFlag(Integer sendFlag) {
        this.sendFlag = sendFlag;
    }

    public String getNcTs() {
        return ncTs;
    }

    public void setNcTs(String ncTs) {
        this.ncTs = ncTs == null ? null : ncTs.trim();
    }

    public String getWorkCenter() {
        return workCenter;
    }

    public void setWorkCenter(String workCenter) {
        this.workCenter = workCenter == null ? null : workCenter.trim();
    }

    public String getWorkNetwork() {
        return workNetwork;
    }

    public void setWorkNetwork(String workNetwork) {
        this.workNetwork = workNetwork == null ? null : workNetwork.trim();
    }

    public String getItem1() {
        return item1;
    }

    public void setItem1(String item1) {
        this.item1 = item1 == null ? null : item1.trim();
    }

    public String getItem2() {
        return item2;
    }

    public void setItem2(String item2) {
        this.item2 = item2 == null ? null : item2.trim();
    }

    public String getItem3() {
        return item3;
    }

    public void setItem3(String item3) {
        this.item3 = item3 == null ? null : item3.trim();
    }

    public String getItem4() {
        return item4;
    }

    public void setItem4(String item4) {
        this.item4 = item4 == null ? null : item4.trim();
    }

    public String getItem5() {
        return item5;
    }

    public void setItem5(String item5) {
        this.item5 = item5 == null ? null : item5.trim();
    }

    public String getItem6() {
        return item6;
    }

    public void setItem6(String item6) {
        this.item6 = item6 == null ? null : item6.trim();
    }

    public String getItem7() {
        return item7;
    }

    public void setItem7(String item7) {
        this.item7 = item7 == null ? null : item7.trim();
    }

    public String getItem8() {
        return item8;
    }

    public void setItem8(String item8) {
        this.item8 = item8 == null ? null : item8.trim();
    }

    public String getItem9() {
        return item9;
    }

    public void setItem9(String item9) {
        this.item9 = item9 == null ? null : item9.trim();
    }

    public String getItem10() {
        return item10;
    }

    public void setItem10(String item10) {
        this.item10 = item10 == null ? null : item10.trim();
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}