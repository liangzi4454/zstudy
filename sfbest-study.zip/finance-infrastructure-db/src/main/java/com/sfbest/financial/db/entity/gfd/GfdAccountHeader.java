package com.sfbest.financial.db.entity.gfd;

import java.util.Date;
/**
* @Author:01237177 
* @date:2017/3/11
*/
public class GfdAccountHeader {
    private Integer id;

    private String headerSn;

    private String billId;

    private String accountType;

    private String companyCode;

    private String voucherType;

    private String fiscalYear;

    private String fiscalMonth;

    private Integer voucherId;

    private Integer attachmentNum;

    private Date makingDate;

    private String makingMan;

    private String cashier;

    private String isSignature;

    private Date postingDate;

    private String postingMan;

    private String sourceSystem;

    private String memo1;

    private Integer xmlSerialnum;

    private Date xmlTime;

    private String processNo;

    private String sendErrMsg;

    private Integer sendFlag;

    private Integer redFlag;

    private Integer dealStatus;

    private String ncTs;

    private Integer createTime;

    private Date modifiedTime;

    private Integer isDeleted;
    /** 创建时间: 不做入库处理只做展示使用 **/
    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHeaderSn() {
        return headerSn;
    }

    public void setHeaderSn(String headerSn) {
        this.headerSn = headerSn == null ? null : headerSn.trim();
    }

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId == null ? null : billId.trim();
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType == null ? null : accountType.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType == null ? null : voucherType.trim();
    }

    public String getFiscalYear() {
        return fiscalYear;
    }

    public void setFiscalYear(String fiscalYear) {
        this.fiscalYear = fiscalYear == null ? null : fiscalYear.trim();
    }

    public String getFiscalMonth() {
        return fiscalMonth;
    }

    public void setFiscalMonth(String fiscalMonth) {
        this.fiscalMonth = fiscalMonth == null ? null : fiscalMonth.trim();
    }

    public Integer getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(Integer voucherId) {
        this.voucherId = voucherId;
    }

    public Integer getAttachmentNum() {
        return attachmentNum;
    }

    public void setAttachmentNum(Integer attachmentNum) {
        this.attachmentNum = attachmentNum;
    }

    public Date getMakingDate() {
        return makingDate;
    }

    public void setMakingDate(Date makingDate) {
        this.makingDate = makingDate;
    }

    public String getMakingMan() {
        return makingMan;
    }

    public void setMakingMan(String makingMan) {
        this.makingMan = makingMan == null ? null : makingMan.trim();
    }

    public String getCashier() {
        return cashier;
    }

    public void setCashier(String cashier) {
        this.cashier = cashier == null ? null : cashier.trim();
    }

    public String getIsSignature() {
        return isSignature;
    }

    public void setIsSignature(String isSignature) {
        this.isSignature = isSignature == null ? null : isSignature.trim();
    }

    public Date getPostingDate() {
        return postingDate;
    }

    public void setPostingDate(Date postingDate) {
        this.postingDate = postingDate;
    }

    public String getPostingMan() {
        return postingMan;
    }

    public void setPostingMan(String postingMan) {
        this.postingMan = postingMan == null ? null : postingMan.trim();
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem == null ? null : sourceSystem.trim();
    }

    public String getMemo1() {
        return memo1;
    }

    public void setMemo1(String memo1) {
        this.memo1 = memo1 == null ? null : memo1.trim();
    }

    public Integer getXmlSerialnum() {
        return xmlSerialnum;
    }

    public void setXmlSerialnum(Integer xmlSerialnum) {
        this.xmlSerialnum = xmlSerialnum;
    }

    public Date getXmlTime() {
        return xmlTime;
    }

    public void setXmlTime(Date xmlTime) {
        this.xmlTime = xmlTime;
    }

    public String getProcessNo() {
        return processNo;
    }

    public void setProcessNo(String processNo) {
        this.processNo = processNo == null ? null : processNo.trim();
    }

    public String getSendErrMsg() {
        return sendErrMsg;
    }

    public void setSendErrMsg(String sendErrMsg) {
        this.sendErrMsg = sendErrMsg == null ? null : sendErrMsg.trim();
    }

    public Integer getSendFlag() {
        return sendFlag;
    }

    public void setSendFlag(Integer sendFlag) {
        this.sendFlag = sendFlag;
    }

    public Integer getRedFlag() {
        return redFlag;
    }

    public void setRedFlag(Integer redFlag) {
        this.redFlag = redFlag;
    }

    public Integer getDealStatus() {
        return dealStatus;
    }

    public void setDealStatus(Integer dealStatus) {
        this.dealStatus = dealStatus;
    }

    public String getNcTs() {
        return ncTs;
    }

    public void setNcTs(String ncTs) {
        this.ncTs = ncTs == null ? null : ncTs.trim();
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}