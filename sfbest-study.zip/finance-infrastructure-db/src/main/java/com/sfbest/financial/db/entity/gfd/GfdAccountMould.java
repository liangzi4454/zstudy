package com.sfbest.financial.db.entity.gfd;

import java.util.ArrayList;
import java.util.List;

/**
 * 模板头信息
 */
public class GfdAccountMould {
    private Integer id;
    /** 模板名称 **/
    private String mouldName;
    /** 模板描述 **/
    private String description;
    /** 公司编码 **/
    private String companyCode;
    /** 公司名称 **/
    private String companyName;
    /** 借的数量 **/
    private Integer debitNumber;
    /** 贷的数量 **/
    private Integer creditNumber;
    /** 排序,首先根据该字段排序,然后根据创建日期排序 **/
    private Integer sort;
    /** 创建时间 **/
    private Integer createTime;
    /** 删除标识, 不做入库处理**/
    private boolean flag = true;
    /** 费用类型编码,当创建模板头信息的时候与之关联 **/
    @Deprecated
    private List<GfdAccountChargeItem> chargeItems = new ArrayList<GfdAccountChargeItem>();
    /** 费用类型编码,当创建模板头信息的时候与之关联 **/
    @Deprecated
    private List<String> chargeItemCodes = new ArrayList<String>();
    /** 费用类型ID,用逗号分隔 **/
    private String chargeIds;

    /** 创建时间: 不做入库处理只做展示使用 **/
    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMouldName() {
        return mouldName;
    }

    public void setMouldName(String mouldName) {
        this.mouldName = mouldName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getDebitNumber() {
        return debitNumber;
    }

    public void setDebitNumber(Integer debitNumber) {
        this.debitNumber = debitNumber;
    }

    public Integer getCreditNumber() {
        return creditNumber;
    }

    public void setCreditNumber(Integer creditNumber) {
        this.creditNumber = creditNumber;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public List<GfdAccountChargeItem> getChargeItems() {
        return chargeItems;
    }

    public void setChargeItems(List<GfdAccountChargeItem> chargeItems) {
        this.chargeItems = chargeItems;
    }

    public List<String> getChargeItemCodes() {
        return chargeItemCodes;
    }

    public void setChargeItemCodes(List<String> chargeItemCodes) {
        this.chargeItemCodes = chargeItemCodes;
    }

    public String getChargeIds() {
        return chargeIds;
    }

    public void setChargeIds(String chargeIds) {
        this.chargeIds = chargeIds;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}