package com.sfbest.financial.db.entity.gfd;

import java.math.BigDecimal;

/**
 * 模板体实体类
 */
public class GfdAccountMouldSubject {
    private Integer id;
    /** 模板表id主键 **/
    private Integer mouldId;
    /** 科目编码 **/
    private String subjectCode;
    /** 摘要信息 **/
    private String subjectSummary;
    /** 标准货币符号,如CNY **/
    private String currencySymbol;
    /** 汇率1 **/
    private BigDecimal exRate1;
    /** 汇率2 **/
    private BigDecimal exRate2;
    /** 计算公式,存储json格式 **/
    private String formula;
    /** 记账类型：0记账凭证，1收付凭证 **/
    private Integer accountType;
    /** 借贷方向: 0借,1贷 **/
    private Integer debitCredit;
    /** 以下item为辅助核算项 **/
    /** 客商编码 **/
    private String item1;
    /** 人员编码 **/
    private String item2;
    /** 银行账户 **/
    private String item3;
    /** 项目代码 **/
    private String item4;
    /** 收入类型 **/
    private String item5;
    /** 车牌号码 **/
    private String item6;
    /** 存货分类(固定值:SP040002) **/
    private String item7;
    /** 发票类型 **/
    private String item8;
    /** 现金流量项目 **/
    private String item9;
    /** 待抵扣进项税类型 **/
    private String item10;
    /** 排序,首先根据该字段排序,然后根据创建日期排序 **/
    private Integer sort;
    /** 创建时间 **/
    private Integer createTime;
    /** 科目名称 **/
    private String subjectName;

    /** 创建时间: 不做入库处理只做展示使用 **/
    private String createTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMouldId() {
        return mouldId;
    }

    public void setMouldId(Integer mouldId) {
        this.mouldId = mouldId;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getSubjectSummary() {
        return subjectSummary;
    }

    public void setSubjectSummary(String subjectSummary) {
        this.subjectSummary = subjectSummary;
    }

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    public BigDecimal getExRate1() {
        return exRate1;
    }

    public void setExRate1(BigDecimal exRate1) {
        this.exRate1 = exRate1;
    }

    public BigDecimal getExRate2() {
        return exRate2;
    }

    public void setExRate2(BigDecimal exRate2) {
        this.exRate2 = exRate2;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public Integer getDebitCredit() {
        return debitCredit;
    }

    public void setDebitCredit(Integer debitCredit) {
        this.debitCredit = debitCredit;
    }

    public String getItem1() {
        return item1;
    }

    public void setItem1(String item1) {
        this.item1 = item1;
    }

    public String getItem2() {
        return item2;
    }

    public void setItem2(String item2) {
        this.item2 = item2;
    }

    public String getItem3() {
        return item3;
    }

    public void setItem3(String item3) {
        this.item3 = item3;
    }

    public String getItem4() {
        return item4;
    }

    public void setItem4(String item4) {
        this.item4 = item4;
    }

    public String getItem5() {
        return item5;
    }

    public void setItem5(String item5) {
        this.item5 = item5;
    }

    public String getItem6() {
        return item6;
    }

    public void setItem6(String item6) {
        this.item6 = item6;
    }

    public String getItem7() {
        return item7;
    }

    public void setItem7(String item7) {
        this.item7 = item7;
    }

    public String getItem8() {
        return item8;
    }

    public void setItem8(String item8) {
        this.item8 = item8;
    }

    public String getItem9() {
        return item9;
    }

    public void setItem9(String item9) {
        this.item9 = item9;
    }

    public String getItem10() {
        return item10;
    }

    public void setItem10(String item10) {
        this.item10 = item10;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }
}