package com.sfbest.financial.db.entity.gfd;

import java.math.BigDecimal;

/**
 * Created by LHY on 2017/3/31.
 */
@Deprecated
public class GfdAccountMouldSubjectVO {
    /** 模板表id主键 **/
    private Integer mouldId;
    /** 科目编码 **/
    private String subjectCode;
    /** 摘要信息 **/
    private String subjectSummary;
    /** 标准货币符号,如CNY **/
    private String currencySymbol;
    /** 汇率1 **/
    private BigDecimal exRate1;
    /** 汇率2 **/
    private BigDecimal exRate2;
    /** 计算公式,存储json格式 **/
    private String formula;
    /** 记账类型：0记账凭证，1收付凭证 **/
    private Integer accountType;
    /** 借贷方向: 0借,1贷 **/
    private Integer debitCredit;
    /** 费用类型编码 **/
    private String chargeItemCode;

    public Integer getMouldId() {
        return mouldId;
    }

    public void setMouldId(Integer mouldId) {
        this.mouldId = mouldId;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getSubjectSummary() {
        return subjectSummary;
    }

    public void setSubjectSummary(String subjectSummary) {
        this.subjectSummary = subjectSummary;
    }

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    public BigDecimal getExRate1() {
        return exRate1;
    }

    public void setExRate1(BigDecimal exRate1) {
        this.exRate1 = exRate1;
    }

    public BigDecimal getExRate2() {
        return exRate2;
    }

    public void setExRate2(BigDecimal exRate2) {
        this.exRate2 = exRate2;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public Integer getDebitCredit() {
        return debitCredit;
    }

    public void setDebitCredit(Integer debitCredit) {
        this.debitCredit = debitCredit;
    }

    public String getChargeItemCode() {
        return chargeItemCode;
    }

    public void setChargeItemCode(String chargeItemCode) {
        this.chargeItemCode = chargeItemCode;
    }
}