package com.sfbest.financial.db.entity.gfd;

import java.io.Serializable;

/**
 * Created by 01061941 on 2017/3/27.
 */
public class GfdOrderActiveProductMoneyUseMessage implements Serializable {

    private static final long serialVersionUID = -9195936331138278004L;

    private Integer id;

    private Integer orderId;

    private Integer parentOrderId;

    private Integer orderProductId;

    private Integer activeId;

    private Integer activeCode;

    private Integer platformShareMoney;

    private Integer merchantShareMoney;

    private Integer addTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getParentOrderId() {
        return parentOrderId;
    }

    public void setParentOrderId(Integer parentOrderId) {
        this.parentOrderId = parentOrderId;
    }

    public Integer getOrderProductId() {
        return orderProductId;
    }

    public void setOrderProductId(Integer orderProductId) {
        this.orderProductId = orderProductId;
    }

    public Integer getActiveId() {
        return activeId;
    }

    public void setActiveId(Integer activeId) {
        this.activeId = activeId;
    }

    public void setActiveCode(Integer activeCode) {
        this.activeCode = activeCode;
    }
    public Integer getActiveCode() {
        return activeCode;
    }

    public Integer getPlatformShareMoney() {
        return platformShareMoney;
    }

    public void setPlatformShareMoney(Integer platformShareMoney) {
        this.platformShareMoney = platformShareMoney;
    }

    public Integer getMerchantShareMoney() {
        return merchantShareMoney;
    }

    public void setMerchantShareMoney(Integer merchantShareMoney) {
        this.merchantShareMoney = merchantShareMoney;
    }

    public Integer getAddTime() {
        return addTime;
    }

    public void setAddTime(Integer addTime) {
        this.addTime = addTime;
    }

}
