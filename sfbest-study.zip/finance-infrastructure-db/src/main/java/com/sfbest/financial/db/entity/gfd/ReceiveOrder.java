package com.sfbest.financial.db.entity.gfd;

import java.io.Serializable;

/**
 * Created by 603513 on 2017/2/24.
 */
public class ReceiveOrder implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 75882776632821719L;
    private Integer id;
    /**
     *
     */
    private Integer orderId;  // 订单ID
    private String orderSn;  // 订单sn
    private String branchCode;  //门店编码
    private String branchName;   // 门店名称
    private String payEmpCode;  // 收款人 7月26号后特食这里存的收款人姓名 和店长姓名
    private String branchManagerCode; // 门店店长   特食这里存的收款人工号 和店长工号
    private String branchManagerName; // 店长姓名   特食退款的时候这里存的原路和非原路
    private String merchantNumber; // 商家编号


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderSn() {
        return orderSn;
    }

    public void setOrderSn(String orderSn) {
        this.orderSn = orderSn;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getPayEmpCode() {
        return payEmpCode;
    }

    public void setPayEmpCode(String payEmpCode) {
        this.payEmpCode = payEmpCode;
    }

    public String getBranchManagerCode() {
        return branchManagerCode;
    }

    public void setBranchManagerCode(String branchManagerCode) {
        this.branchManagerCode = branchManagerCode;
    }

    public String getBranchManagerName() {
        return branchManagerName;
    }

    public void setBranchManagerName(String branchManagerName) {
        this.branchManagerName = branchManagerName;
    }

    public String getMerchantNumber() {
        return merchantNumber;
    }

    public void setMerchantNumber(String merchantNumber) {
        this.merchantNumber = merchantNumber;
    }
}