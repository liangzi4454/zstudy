package com.sfbest.financial.db.entity.gfd;
import java.io.Serializable;

/**
 * 
 * 定时任务时间记录表
 * 
 **/
public class TaskSchedule implements Serializable {

	private static final long serialVersionUID = 981208338720135156L;

	/** 自增ID **/
	private Integer id;

	/** 任务编号 **/
	private String taskKey;

	/** 任务名称 **/
	private String taskName;

	/** 操作时间 **/
	private Integer lastExecTime;

	/** 添加时间 **/
	private Integer addTime;

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return this.id;
	}

	public void setTaskKey(String taskKey) {
		this.taskKey = taskKey;
	}

	public String getTaskKey() {
		return this.taskKey;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskName() {
		return this.taskName;
	}

	public void setLastExecTime(Integer lastExecTime) {
		this.lastExecTime = lastExecTime;
	}

	public Integer getLastExecTime() {
		return this.lastExecTime;
	}

	public void setAddTime(Integer addTime) {
		this.addTime = addTime;
	}

	public Integer getAddTime() {
		return this.addTime;
	}

}
