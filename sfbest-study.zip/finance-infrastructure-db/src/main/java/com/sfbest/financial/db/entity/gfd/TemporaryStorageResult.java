package com.sfbest.financial.db.entity.gfd;

import java.math.BigDecimal;

/**
 * Created by LHY on 2017/3/31.
 */
@Deprecated
public class TemporaryStorageResult {
    private BigDecimal amount;
    private Double tax;
    private String chargeItemCode;
    private int mouldId;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public String getChargeItemCode() {
        return chargeItemCode;
    }

    public void setChargeItemCode(String chargeItemCode) {
        this.chargeItemCode = chargeItemCode;
    }

    public int getMouldId() {
        return mouldId;
    }

    public void setMouldId(int mouldId) {
        this.mouldId = mouldId;
    }
}