package com.sfbest.financial.db.entity.gshop;

public class GShopProductInWh {
    private Integer inId;

    private Integer supplierId;

    private String supplierNumber;

    private Integer purchaseId;

    private String purchaseNumber;

    private String inNumber;

    private Integer warehouseId;

    private String warehouse;

    private Integer total;

    private Integer getTime;

    private Integer predictTime;

    private Integer extendedDay;

    private Boolean isEmpty;

    private Byte isCount;

    private Boolean purchaseType;

    private Boolean cooperationMode;

    private Integer purchaseTotal;

    private Integer predictTotal;

    private Integer inTax;

    private Integer addTime;

    private Integer basicId;

    private Boolean isCert;

    public Integer getInId() {
        return inId;
    }

    public void setInId(Integer inId) {
        this.inId = inId;
    }

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierNumber() {
        return supplierNumber;
    }

    public void setSupplierNumber(String supplierNumber) {
        this.supplierNumber = supplierNumber == null ? null : supplierNumber.trim();
    }

    public Integer getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(Integer purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getPurchaseNumber() {
        return purchaseNumber;
    }

    public void setPurchaseNumber(String purchaseNumber) {
        this.purchaseNumber = purchaseNumber == null ? null : purchaseNumber.trim();
    }

    public String getInNumber() {
        return inNumber;
    }

    public void setInNumber(String inNumber) {
        this.inNumber = inNumber == null ? null : inNumber.trim();
    }

    public Integer getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Integer warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse == null ? null : warehouse.trim();
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getGetTime() {
        return getTime;
    }

    public void setGetTime(Integer getTime) {
        this.getTime = getTime;
    }

    public Integer getPredictTime() {
        return predictTime;
    }

    public void setPredictTime(Integer predictTime) {
        this.predictTime = predictTime;
    }

    public Integer getExtendedDay() {
        return extendedDay;
    }

    public void setExtendedDay(Integer extendedDay) {
        this.extendedDay = extendedDay;
    }

    public Boolean getIsEmpty() {
        return isEmpty;
    }

    public void setIsEmpty(Boolean isEmpty) {
        this.isEmpty = isEmpty;
    }

    public Byte getIsCount() {
        return isCount;
    }

    public void setIsCount(Byte isCount) {
        this.isCount = isCount;
    }

    public Boolean getPurchaseType() {
        return purchaseType;
    }

    public void setPurchaseType(Boolean purchaseType) {
        this.purchaseType = purchaseType;
    }

    public Boolean getCooperationMode() {
        return cooperationMode;
    }

    public void setCooperationMode(Boolean cooperationMode) {
        this.cooperationMode = cooperationMode;
    }

    public Integer getPurchaseTotal() {
        return purchaseTotal;
    }

    public void setPurchaseTotal(Integer purchaseTotal) {
        this.purchaseTotal = purchaseTotal;
    }

    public Integer getPredictTotal() {
        return predictTotal;
    }

    public void setPredictTotal(Integer predictTotal) {
        this.predictTotal = predictTotal;
    }

    public Integer getInTax() {
        return inTax;
    }

    public void setInTax(Integer inTax) {
        this.inTax = inTax;
    }

    public Integer getAddTime() {
        return addTime;
    }

    public void setAddTime(Integer addTime) {
        this.addTime = addTime;
    }

    public Integer getBasicId() {
        return basicId;
    }

    public void setBasicId(Integer basicId) {
        this.basicId = basicId;
    }

    public Boolean getIsCert() {
        return isCert;
    }

    public void setIsCert(Boolean isCert) {
        this.isCert = isCert;
    }

    @Override
    public String toString() {
        return "GShopProductInWh{" +
                "inId=" + inId +
                ", supplierId=" + supplierId +
                ", supplierNumber='" + supplierNumber + '\'' +
                ", purchaseId=" + purchaseId +
                ", purchaseNumber='" + purchaseNumber + '\'' +
                ", inNumber='" + inNumber + '\'' +
                ", warehouseId=" + warehouseId +
                ", warehouse='" + warehouse + '\'' +
                ", total=" + total +
                ", getTime=" + getTime +
                ", predictTime=" + predictTime +
                ", extendedDay=" + extendedDay +
                ", isEmpty=" + isEmpty +
                ", isCount=" + isCount +
                ", purchaseType=" + purchaseType +
                ", cooperationMode=" + cooperationMode +
                ", purchaseTotal=" + purchaseTotal +
                ", predictTotal=" + predictTotal +
                ", inTax=" + inTax +
                ", addTime=" + addTime +
                ", basicId=" + basicId +
                ", isCert=" + isCert +
                '}';
    }
}