package com.sfbest.financial.db.entity.gshop;

import java.util.Date;

public class GShopProductOutWh {
    private Integer outId;

    private Integer supplierId;

    private String supplierNumber;

    private Integer returnId;

    private String returnNumber;

    private String outNumber;

    private Integer warehouseId;

    private String warehouse;

    private Integer total;

    private Integer outTime;

    private Boolean isEmpty;

    private Boolean isCount;

    private Integer inTax;

    private Integer basicId;

    private Date modifiedTime;

    public Integer getOutId() {
        return outId;
    }

    public void setOutId(Integer outId) {
        this.outId = outId;
    }

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierNumber() {
        return supplierNumber;
    }

    public void setSupplierNumber(String supplierNumber) {
        this.supplierNumber = supplierNumber == null ? null : supplierNumber.trim();
    }

    public Integer getReturnId() {
        return returnId;
    }

    public void setReturnId(Integer returnId) {
        this.returnId = returnId;
    }

    public String getReturnNumber() {
        return returnNumber;
    }

    public void setReturnNumber(String returnNumber) {
        this.returnNumber = returnNumber == null ? null : returnNumber.trim();
    }

    public String getOutNumber() {
        return outNumber;
    }

    public void setOutNumber(String outNumber) {
        this.outNumber = outNumber == null ? null : outNumber.trim();
    }

    public Integer getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Integer warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse == null ? null : warehouse.trim();
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getOutTime() {
        return outTime;
    }

    public void setOutTime(Integer outTime) {
        this.outTime = outTime;
    }

    public Boolean getIsEmpty() {
        return isEmpty;
    }

    public void setIsEmpty(Boolean isEmpty) {
        this.isEmpty = isEmpty;
    }

    public Boolean getIsCount() {
        return isCount;
    }

    public void setIsCount(Boolean isCount) {
        this.isCount = isCount;
    }

    public Integer getInTax() {
        return inTax;
    }

    public void setInTax(Integer inTax) {
        this.inTax = inTax;
    }

    public Integer getBasicId() {
        return basicId;
    }

    public void setBasicId(Integer basicId) {
        this.basicId = basicId;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    @Override
    public String toString() {
        return "GShopProductOutWh{" +
                "outId=" + outId +
                ", supplierId=" + supplierId +
                ", supplierNumber='" + supplierNumber + '\'' +
                ", returnId=" + returnId +
                ", returnNumber='" + returnNumber + '\'' +
                ", outNumber='" + outNumber + '\'' +
                ", warehouseId=" + warehouseId +
                ", warehouse='" + warehouse + '\'' +
                ", total=" + total +
                ", outTime=" + outTime +
                ", isEmpty=" + isEmpty +
                ", isCount=" + isCount +
                ", inTax=" + inTax +
                ", basicId=" + basicId +
                ", modifiedTime=" + modifiedTime +
                '}';
    }
}