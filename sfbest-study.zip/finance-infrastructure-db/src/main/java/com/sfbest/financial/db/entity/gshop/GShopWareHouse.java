package com.sfbest.financial.db.entity.gshop;

public class GShopWareHouse {
    private Short warehouseId;

    private String warehouseName;

    private String warehouseSn;

    private String warehouseAdd;

    private String warehousePhone;

    private String warehouseFax;

    private Boolean isRun;

    private Boolean isVirtual;

    private Byte sort;

    private String warehousePerson;

    private String province;

    private String city;

    private String area;

    private Boolean warehouseType;

    private Short parentId;

    public Short getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Short warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getWarehouseName() {
        return warehouseName;
    }

    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName == null ? null : warehouseName.trim();
    }

    public String getWarehouseSn() {
        return warehouseSn;
    }

    public void setWarehouseSn(String warehouseSn) {
        this.warehouseSn = warehouseSn == null ? null : warehouseSn.trim();
    }

    public String getWarehouseAdd() {
        return warehouseAdd;
    }

    public void setWarehouseAdd(String warehouseAdd) {
        this.warehouseAdd = warehouseAdd == null ? null : warehouseAdd.trim();
    }

    public String getWarehousePhone() {
        return warehousePhone;
    }

    public void setWarehousePhone(String warehousePhone) {
        this.warehousePhone = warehousePhone == null ? null : warehousePhone.trim();
    }

    public String getWarehouseFax() {
        return warehouseFax;
    }

    public void setWarehouseFax(String warehouseFax) {
        this.warehouseFax = warehouseFax == null ? null : warehouseFax.trim();
    }

    public Boolean getIsRun() {
        return isRun;
    }

    public void setIsRun(Boolean isRun) {
        this.isRun = isRun;
    }

    public Boolean getIsVirtual() {
        return isVirtual;
    }

    public void setIsVirtual(Boolean isVirtual) {
        this.isVirtual = isVirtual;
    }

    public Byte getSort() {
        return sort;
    }

    public void setSort(Byte sort) {
        this.sort = sort;
    }

    public String getWarehousePerson() {
        return warehousePerson;
    }

    public void setWarehousePerson(String warehousePerson) {
        this.warehousePerson = warehousePerson == null ? null : warehousePerson.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public Boolean getWarehouseType() {
        return warehouseType;
    }

    public void setWarehouseType(Boolean warehouseType) {
        this.warehouseType = warehouseType;
    }

    public Short getParentId() {
        return parentId;
    }

    public void setParentId(Short parentId) {
        this.parentId = parentId;
    }

    @Override
    public String toString() {
        return "GShopWareHouse{" +
                "warehouseId=" + warehouseId +
                ", warehouseName='" + warehouseName + '\'' +
                ", warehouseSn='" + warehouseSn + '\'' +
                ", warehouseAdd='" + warehouseAdd + '\'' +
                ", warehousePhone='" + warehousePhone + '\'' +
                ", warehouseFax='" + warehouseFax + '\'' +
                ", isRun=" + isRun +
                ", isVirtual=" + isVirtual +
                ", sort=" + sort +
                ", warehousePerson='" + warehousePerson + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", area='" + area + '\'' +
                ", warehouseType=" + warehouseType +
                ", parentId=" + parentId +
                '}';
    }
}