package com.sfbest.financial.db.entity.gshop;

/**
* 物资出入库数据中间表
* @Author:01237177 
* @date:2017/3/6
*/
public class GshopAccountInOut {
    /** 供货商ID */
    private Integer supplierId;
    /** 供货商编号 */
    private String supplierNumber;
    /** 出入库单表ID */
    private Integer checkId ;
    /** 出入库单编号 */
    private String  checkNumber;
    /** 出入库单签收时间 */
    private Long checkTime;
    /** 实际收货金额 */
    private Integer total;
    /** 1.正常2.空进 */
    private Integer isEmpty;
    /** 进项税 */
    private Double inTax;
    /** 采购单ID */
    private Integer purchaseId;
    /** 采购单编号 */
    private String purchaseNumber;
    /** 合同表id */
    private Integer basicId;
    /** 合同编号 */
    private String contractNumber;
    /** 结算方式:
     * 1.A按照月采购总额结算,
     * 2.E按照销售成本结算,
     * 3.F按照销售金额返点结算,
     * 4.D按照订购总额结算,
     * 5.自营,
     * 6.B按照半月采购总额结算,
     * 7.C按照到货总额结算
     * */
    private Integer cooperationMode;
    /** 仓库名称 */
    private String warehouseName;
    /** 是否海外直采: 0否,1是 */
    private Integer isOverseas;

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierNumber() {
        return supplierNumber;
    }

    public void setSupplierNumber(String supplierNumber) {
        this.supplierNumber = supplierNumber;
    }

    public Integer getCheckId() {
        return checkId;
    }

    public void setCheckId(Integer checkId) {
        this.checkId = checkId;
    }

    public String getCheckNumber() {
        return checkNumber;
    }

    public void setCheckNumber(String checkNumber) {
        this.checkNumber = checkNumber;
    }

    public Long getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Long checkTime) {
        this.checkTime = checkTime;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getIsEmpty() {
        return isEmpty;
    }

    public void setIsEmpty(Integer isEmpty) {
        this.isEmpty = isEmpty;
    }

    public Double getInTax() {
        return inTax;
    }

    public void setInTax(Double inTax) {
        this.inTax = inTax;
    }

    public Integer getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(Integer purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getPurchaseNumber() {
        return purchaseNumber;
    }

    public void setPurchaseNumber(String purchaseNumber) {
        this.purchaseNumber = purchaseNumber;
    }

    public Integer getBasicId() {
        return basicId;
    }

    public void setBasicId(Integer basicId) {
        this.basicId = basicId;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public Integer getCooperationMode() {
        return cooperationMode;
    }

    public void setCooperationMode(Integer cooperationMode) {
        this.cooperationMode = cooperationMode;
    }

    public String getWarehouseName() {
        return warehouseName;
    }

    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName;
    }

    public Integer getIsOverseas() {
        return isOverseas;
    }

    public void setIsOverseas(Integer isOverseas) {
        this.isOverseas = isOverseas;
    }
}
