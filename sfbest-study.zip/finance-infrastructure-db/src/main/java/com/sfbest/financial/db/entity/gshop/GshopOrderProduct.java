package com.sfbest.financial.db.entity.gshop;

import java.io.Serializable;

/**
 * Created by 01061941 on 2017/3/27.
 */
public class GshopOrderProduct implements Serializable {

    private static final long serialVersionUID = 5818745162795497595L;
    /****/
    private Integer id;

    /**父id(商品是礼包中单品,存储父商品id,如果是针对商品赠品,存主商品id)**/
    private Integer parentId;

    /**订单id**/
    private Integer orderId;

    /**商品id**/
    private Integer productId;

    /**仓库ID**/
    private Integer warehouseId;

    /**商品名称**/
    private String productName;

    /**商品编号**/
    private String productSn;

    /**商品重量（单位：克）**/
    private Integer weight;

    /**订购数量，如果是礼包商品=礼包数*商品数（每个礼包）**/
    private Integer productNum;

    /**实销数量（销售数量-退货数量）**/
    private Integer sellNum;

    /**商品参与的优惠活动id(主商品和赠品均为code-id|code-id格式)**/
    private String activeId;

    /**1:优选商品  3产地直采商品 4.商家平台**/
    private Integer businessModel;

    /**商品类型（0：普通商品;1：礼包;2：礼篮;3：赠品; 4:时令商品;5:加价购赠品;6:n元m件;7:礼品袋赠品)**/
    private String productType;

    /**库存类型（1:现货;2:预订;3:虚库;4:预售）**/
    private Integer stockType;

    /**0:未评论 1:1星 2:2星 3:3星 4:4星 5:5星**/
    private Integer commentsRank;

    /**商品返现金额 单位 分**/
    private Integer returnMoney;

    /**商品进价(产地直发商品专用)**/
    private Integer inPrice;

    /**单价(商品原价)**/
    private Integer productPrice;

    /**单价*数量与小计差额**/
    private Integer difference;

    /**商品实销价格 单位 分**/
    private Integer sellPrice;

    /**商品赠送积分值(单位:百个)**/
    private Integer integral;

    /**配送该商品对应的物流单号**/
    private String shippingSn;

    /**速运配送条件值**/
    private String sfshipping;

    /**空运配送条件值**/
    private String sfairline;

    /**订单商品状态， 5缺货**/
    private Integer status;

    /**添加时间**/
    private Integer addTime;

    /**用户对此订单商品评分时间（修改评分时不动）**/
    private Integer commentsTime;

    /**订单商品状态值:0待审批 1 新品 2 预上架 3正常 4预删除 5删除 6强行删除**/
    private Integer productStatus;

    /**订单商品关联ID，暂用：如果商品是预售商品，存取预售商品管理表ID**/
    private Integer linkId;

    /**否是晒单 0:否 1:是**/
    private Integer isSun;

    /**DM单号**/
    private String dmCode;

    /**使用的优惠券id**/
    private Integer couponId;

    /**外部ID(天猫，京东等)**/
    private String outerId;

    /**满减分摊金额(拆单),单位分**/
    private Integer fullReduceMoney;

    /**优惠劵分摊金额(拆单),单位分**/
    private Integer couponMoney;

    /**商家编号:自营默认10001**/
    private Integer merchantNumber;

    private Integer businessType;
    /** 下单立减活动分摊总金额（单位:分）**/
    private int orderMinusFee;

    public Integer getBusinessType() {
        return businessType;
    }

    public void setBusinessType(Integer businessType) {
        this.businessType = businessType;
    }

    public void setId(Integer id){
        this.id = id;
    }

    public Integer getId(){
        return this.id;
    }

    public void setParentId(Integer parentId){
        this.parentId = parentId;
    }

    public Integer getParentId(){
        return this.parentId;
    }

    public void setOrderId(Integer orderId){
        this.orderId = orderId;
    }

    public Integer getOrderId(){
        return this.orderId;
    }

    public void setProductId(Integer productId){
        this.productId = productId;
    }

    public Integer getProductId(){
        return this.productId;
    }

    public void setWarehouseId(Integer warehouseId){
        this.warehouseId = warehouseId;
    }

    public Integer getWarehouseId(){
        return this.warehouseId;
    }

    public void setProductName(String productName){
        this.productName = productName;
    }

    public String getProductName(){
        return this.productName;
    }

    public void setProductSn(String productSn){
        this.productSn = productSn;
    }

    public String getProductSn(){
        return this.productSn;
    }

    public void setWeight(Integer weight){
        this.weight = weight;
    }

    public Integer getWeight(){
        return this.weight;
    }

    public void setProductNum(Integer productNum){
        this.productNum = productNum;
    }

    public Integer getProductNum(){
        return this.productNum;
    }

    public void setSellNum(Integer sellNum){
        this.sellNum = sellNum;
    }

    public Integer getSellNum(){
        return this.sellNum;
    }

    public void setActiveId(String activeId){
        this.activeId = activeId;
    }

    public String getActiveId(){
        return this.activeId;
    }

    public void setBusinessModel(Integer businessModel){
        this.businessModel = businessModel;
    }

    public Integer getBusinessModel(){
        return this.businessModel;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public void setStockType(Integer stockType){
        this.stockType = stockType;
    }

    public Integer getStockType(){
        return this.stockType;
    }

    public void setCommentsRank(Integer commentsRank){
        this.commentsRank = commentsRank;
    }

    public Integer getCommentsRank(){
        return this.commentsRank;
    }

    public void setReturnMoney(Integer returnMoney){
        this.returnMoney = returnMoney;
    }

    public Integer getReturnMoney(){
        return this.returnMoney;
    }

    public void setInPrice(Integer inPrice){
        this.inPrice = inPrice;
    }

    public Integer getInPrice(){
        return this.inPrice;
    }

    public void setProductPrice(Integer productPrice){
        this.productPrice = productPrice;
    }

    public Integer getProductPrice(){
        return this.productPrice;
    }

    public void setDifference(Integer difference){
        this.difference = difference;
    }

    public Integer getDifference(){
        return this.difference;
    }

    public void setSellPrice(Integer sellPrice){
        this.sellPrice = sellPrice;
    }

    public Integer getSellPrice(){
        return this.sellPrice;
    }

    public void setIntegral(Integer integral){
        this.integral = integral;
    }

    public Integer getIntegral(){
        return this.integral;
    }

    public void setShippingSn(String shippingSn){
        this.shippingSn = shippingSn;
    }

    public String getShippingSn(){
        return this.shippingSn;
    }

    public void setSfshipping(String sfshipping){
        this.sfshipping = sfshipping;
    }

    public String getSfshipping(){
        return this.sfshipping;
    }

    public void setSfairline(String sfairline){
        this.sfairline = sfairline;
    }

    public String getSfairline(){
        return this.sfairline;
    }

    public void setStatus(Integer status){
        this.status = status;
    }

    public Integer getStatus(){
        return this.status;
    }

    public void setAddTime(Integer addTime){
        this.addTime = addTime;
    }

    public Integer getAddTime(){
        return this.addTime;
    }

    public void setCommentsTime(Integer commentsTime){
        this.commentsTime = commentsTime;
    }

    public Integer getCommentsTime(){
        return this.commentsTime;
    }

    public void setProductStatus(Integer productStatus){
        this.productStatus = productStatus;
    }

    public Integer getProductStatus(){
        return this.productStatus;
    }

    public void setLinkId(Integer linkId){
        this.linkId = linkId;
    }

    public Integer getLinkId(){
        return this.linkId;
    }

    public void setIsSun(Integer isSun){
        this.isSun = isSun;
    }

    public Integer getIsSun(){
        return this.isSun;
    }

    public void setDmCode(String dmCode){
        this.dmCode = dmCode;
    }

    public String getDmCode(){
        return this.dmCode;
    }

    public void setCouponId(Integer couponId){
        this.couponId = couponId;
    }

    public Integer getCouponId(){
        return this.couponId;
    }

    public void setOuterId(String outerId){
        this.outerId = outerId;
    }

    public String getOuterId(){
        return this.outerId;
    }

    public void setFullReduceMoney(Integer fullReduceMoney){
        this.fullReduceMoney = fullReduceMoney;
    }

    public Integer getFullReduceMoney(){
        return this.fullReduceMoney;
    }

    public void setCouponMoney(Integer couponMoney){
        this.couponMoney = couponMoney;
    }

    public Integer getCouponMoney(){
        return this.couponMoney;
    }

    public void setMerchantNumber(Integer merchantNumber){
        this.merchantNumber = merchantNumber;
    }

    public Integer getMerchantNumber(){
        return this.merchantNumber;
    }

    public int getOrderMinusFee() {
        return orderMinusFee;
    }

    public void setOrderMinusFee(int orderMinusFee) {
        this.orderMinusFee = orderMinusFee;
    }
}
