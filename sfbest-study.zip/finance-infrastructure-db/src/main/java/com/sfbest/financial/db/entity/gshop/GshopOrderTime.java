package com.sfbest.financial.db.entity.gshop;

import java.io.Serializable;
import java.util.Date;

public class GshopOrderTime implements Serializable {

    private static final long serialVersionUID = -7804658247163908867L;

    private Integer id;

    private Integer orderId;

    private String orderSn;

    private Integer orderAddTime;

    private Integer orderSplitTime;

    private Integer orderDownsendTime;

    private Integer orderSendoutTime;

    private Integer orderReceiveTime;

    private Integer orderRefuseTime;

    private Integer orderCancelTime;

    private Integer orderTruncTime;

    private Integer orderPredictTime;

    private Integer orderExactSendtime;

    private Integer orderExactDeliverytime;

    private Integer createTime;

    private Date modifiedTime;

    private Boolean isDeleted;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderSn() {
        return orderSn;
    }

    public void setOrderSn(String orderSn) {
        this.orderSn = orderSn == null ? null : orderSn.trim();
    }

    public Integer getOrderAddTime() {
        return orderAddTime;
    }

    public void setOrderAddTime(Integer orderAddTime) {
        this.orderAddTime = orderAddTime;
    }

    public Integer getOrderSplitTime() {
        return orderSplitTime;
    }

    public void setOrderSplitTime(Integer orderSplitTime) {
        this.orderSplitTime = orderSplitTime;
    }

    public Integer getOrderDownsendTime() {
        return orderDownsendTime;
    }

    public void setOrderDownsendTime(Integer orderDownsendTime) {
        this.orderDownsendTime = orderDownsendTime;
    }

    public Integer getOrderSendoutTime() {
        return orderSendoutTime;
    }

    public void setOrderSendoutTime(Integer orderSendoutTime) {
        this.orderSendoutTime = orderSendoutTime;
    }

    public Integer getOrderReceiveTime() {
        return orderReceiveTime;
    }

    public void setOrderReceiveTime(Integer orderReceiveTime) {
        this.orderReceiveTime = orderReceiveTime;
    }

    public Integer getOrderRefuseTime() {
        return orderRefuseTime;
    }

    public void setOrderRefuseTime(Integer orderRefuseTime) {
        this.orderRefuseTime = orderRefuseTime;
    }

    public Integer getOrderCancelTime() {
        return orderCancelTime;
    }

    public void setOrderCancelTime(Integer orderCancelTime) {
        this.orderCancelTime = orderCancelTime;
    }

    public Integer getOrderTruncTime() {
        return orderTruncTime;
    }

    public void setOrderTruncTime(Integer orderTruncTime) {
        this.orderTruncTime = orderTruncTime;
    }

    public Integer getOrderPredictTime() {
        return orderPredictTime;
    }

    public void setOrderPredictTime(Integer orderPredictTime) {
        this.orderPredictTime = orderPredictTime;
    }

    public Integer getOrderExactSendtime() {
        return orderExactSendtime;
    }

    public void setOrderExactSendtime(Integer orderExactSendtime) {
        this.orderExactSendtime = orderExactSendtime;
    }

    public Integer getOrderExactDeliverytime() {
        return orderExactDeliverytime;
    }

    public void setOrderExactDeliverytime(Integer orderExactDeliverytime) {
        this.orderExactDeliverytime = orderExactDeliverytime;
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
}