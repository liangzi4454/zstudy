package com.sfbest.financial.db.entity.gshop;

import java.io.Serializable;

/**
 * Created by 01061941 on 2017/2/27.
 */
public class GshopRefundVoucher implements Serializable {

    private static final long serialVersionUID = 6798063478003782571L;

    private Integer id;

    private String vouType;

    private Integer resourceId;

    private String resourceSn;

    private Integer userId;

    private String consignee;

    private String mobile;

    private Integer returnDirection;

    private Integer integral;

    private Integer shippingFee;

    private Integer sfshippingFee;

    private Integer couponMoney;

    private Integer balance;

    private String giftCard;

    private Integer giftCardMoney;

    private Integer cash;

    private String bankDesc;

    private String note;

    private Integer adminId;

    private String isAuditing;

    private Integer actTime;

    private Integer status;

    private String refuseReason;

    private Integer addTime;

    private Integer orderType;

    private Integer refundStatus;

    private Integer giftStatus;

    private Integer balanceStatus;

    private Integer isDeal;

    private String storeManagerCode;

    private String storeManagerName;

    private String storeCode;

    private Integer confirmPaymentTime;

    private Integer sfRefundIntegral;

    private Integer sfbestRefundIntegralT;

    private Integer sfbestRefundIntegralT1;

    private Integer sfRefundIntegralMoney;

    private Integer sfbestRefundIntegralTMoney;

    private Integer orderId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVouType() {
        return vouType;
    }

    public void setVouType(String vouType) {
        this.vouType = vouType;
    }

    public Integer getResourceId() {
        return resourceId;
    }

    public void setResourceId(Integer resourceId) {
        this.resourceId = resourceId;
    }

    public String getResourceSn() {
        return resourceSn;
    }

    public void setResourceSn(String resourceSn) {
        this.resourceSn = resourceSn;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getConsignee() {
        return consignee;
    }

    public void setConsignee(String consignee) {
        this.consignee = consignee;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getReturnDirection() {
        return returnDirection;
    }

    public void setReturnDirection(Integer returnDirection) {
        this.returnDirection = returnDirection;
    }

    public Integer getIntegral() {
        return integral;
    }

    public void setIntegral(Integer integral) {
        this.integral = integral;
    }

    public Integer getShippingFee() {
        return shippingFee;
    }

    public void setShippingFee(Integer shippingFee) {
        this.shippingFee = shippingFee;
    }

    public Integer getSfshippingFee() {
        return sfshippingFee;
    }

    public void setSfshippingFee(Integer sfshippingFee) {
        this.sfshippingFee = sfshippingFee;
    }

    public Integer getCouponMoney() {
        return couponMoney;
    }

    public void setCouponMoney(Integer couponMoney) {
        this.couponMoney = couponMoney;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public String getGiftCard() {
        return giftCard;
    }

    public void setGiftCard(String giftCard) {
        this.giftCard = giftCard;
    }

    public Integer getGiftCardMoney() {
        return giftCardMoney;
    }

    public void setGiftCardMoney(Integer giftCardMoney) {
        this.giftCardMoney = giftCardMoney;
    }

    public Integer getCash() {
        return cash;
    }

    public void setCash(Integer cash) {
        this.cash = cash;
    }

    public String getBankDesc() {
        return bankDesc;
    }

    public void setBankDesc(String bankDesc) {
        this.bankDesc = bankDesc;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getAdminId() {
        return adminId;
    }

    public void setAdminId(Integer adminId) {
        this.adminId = adminId;
    }

    public String getIsAuditing() {
        return isAuditing;
    }

    public void setIsAuditing(String isAuditing) {
        this.isAuditing = isAuditing;
    }

    public Integer getActTime() {
        return actTime;
    }

    public void setActTime(Integer actTime) {
        this.actTime = actTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRefuseReason() {
        return refuseReason;
    }

    public void setRefuseReason(String refuseReason) {
        this.refuseReason = refuseReason;
    }

    public Integer getAddTime() {
        return addTime;
    }

    public void setAddTime(Integer addTime) {
        this.addTime = addTime;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public Integer getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(Integer refundStatus) {
        this.refundStatus = refundStatus;
    }

    public Integer getGiftStatus() {
        return giftStatus;
    }

    public void setGiftStatus(Integer giftStatus) {
        this.giftStatus = giftStatus;
    }

    public Integer getBalanceStatus() {
        return balanceStatus;
    }

    public void setBalanceStatus(Integer balanceStatus) {
        this.balanceStatus = balanceStatus;
    }

    public Integer getIsDeal() {
        return isDeal;
    }

    public void setIsDeal(Integer isDeal) {
        this.isDeal = isDeal;
    }

    public String getStoreManagerCode() {
        return storeManagerCode;
    }

    public void setStoreManagerCode(String storeManagerCode) {
        this.storeManagerCode = storeManagerCode;
    }

    public String getStoreManagerName() {
        return storeManagerName;
    }

    public void setStoreManagerName(String storeManagerName) {
        this.storeManagerName = storeManagerName;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public Integer getConfirmPaymentTime() {
        return confirmPaymentTime;
    }

    public void setConfirmPaymentTime(Integer confirmPaymentTime) {
        this.confirmPaymentTime = confirmPaymentTime;
    }

    public Integer getSfRefundIntegral() {
        return sfRefundIntegral;
    }

    public void setSfRefundIntegral(Integer sfRefundIntegral) {
        this.sfRefundIntegral = sfRefundIntegral;
    }

    public Integer getSfbestRefundIntegralT() {
        return sfbestRefundIntegralT;
    }

    public void setSfbestRefundIntegralT(Integer sfbestRefundIntegralT) {
        this.sfbestRefundIntegralT = sfbestRefundIntegralT;
    }

    public Integer getSfbestRefundIntegralT1() {
        return sfbestRefundIntegralT1;
    }

    public void setSfbestRefundIntegralT1(Integer sfbestRefundIntegralT1) {
        this.sfbestRefundIntegralT1 = sfbestRefundIntegralT1;
    }

    public Integer getSfRefundIntegralMoney() {
        return sfRefundIntegralMoney;
    }

    public void setSfRefundIntegralMoney(Integer sfRefundIntegralMoney) {
        this.sfRefundIntegralMoney = sfRefundIntegralMoney;
    }

    public Integer getSfbestRefundIntegralTMoney() {
        return sfbestRefundIntegralTMoney;
    }

    public void setSfbestRefundIntegralTMoney(Integer sfbestRefundIntegralTMoney) {
        this.sfbestRefundIntegralTMoney = sfbestRefundIntegralTMoney;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }
}
