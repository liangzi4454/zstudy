package com.sfbest.financial.db.entity.gshop;

import java.io.Serializable;

/**
 * Created by 01061941 on 2017/2/27.
 */
public class GshopRefundVoucherExt implements Serializable {

    private static final long serialVersionUID = -2917088005072395941L;

    private Integer id;

    private Integer refundId;

    private Integer returnType;

    private String customName;

    private String customTel;

    private String customBank;

    private String customBankNo;

    private Integer status;

    private Integer addTime;

    private String companyCode;

    private String companyName;

    private String remark;
    
    private String pathName;
    

    public String getPathName() {
		return pathName;
	}

	public void setPathName(String pathName) {
		this.pathName = pathName;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRefundId() {
        return refundId;
    }

    public void setRefundId(Integer refundId) {
        this.refundId = refundId;
    }

    public Integer getReturnType() {
        return returnType;
    }

    public void setReturnType(Integer returnType) {
        this.returnType = returnType;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public String getCustomTel() {
        return customTel;
    }

    public void setCustomTel(String customTel) {
        this.customTel = customTel;
    }

    public String getCustomBank() {
        return customBank;
    }

    public void setCustomBank(String customBank) {
        this.customBank = customBank;
    }

    public String getCustomBankNo() {
        return customBankNo;
    }

    public void setCustomBankNo(String customBankNo) {
        this.customBankNo = customBankNo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getAddTime() {
        return addTime;
    }

    public void setAddTime(Integer addTime) {
        this.addTime = addTime;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
