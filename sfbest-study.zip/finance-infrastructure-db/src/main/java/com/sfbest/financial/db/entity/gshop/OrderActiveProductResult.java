package com.sfbest.financial.db.entity.gshop;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by 01061941 on 2017/3/24.
 */
public class OrderActiveProductResult implements Serializable {

    private static final long serialVersionUID = -899256067028878885L;

    /****/
    private Integer id;

    /**父id(商品是礼包中单品,存储父商品id,如果是针对商品赠品,存主商品id)**/
    private Integer parentId;

    /**订单id**/
    private Integer orderId;

    /**商品id**/
    private Integer productId;

    /**实销数量（销售数量-退货数量）**/
    private Integer sellNum;
    /**订购数量，如果是礼包商品=礼包数*商品数(每个礼包)**/
    private Integer productNum;

    /**单价(商品原价)**/
    private Integer productPrice;

    /**商品实销价格 单位 分**/
    private Integer sellPrice;

    /**商品类型（0：普通商品;1：礼包;2：礼篮;3：赠品; 4:时令商品;5:加价购赠品;6:n元m件;7:礼品袋赠品)**/
    private String productType;

    /**单价*数量与小计差额**/
    private Integer difference;
    /**商品参与的优惠活动id(主商品和赠品均为code-id|code-id格式)**/

    private Integer activeId;

    /**满减分摊金额(拆单),单位分**/
    private Integer fullReduceMoney = 0;

    private Integer orderParentId;
    /** 平台分摊比例 */
    private BigDecimal platform = new BigDecimal(0);

    private Integer activeType;//优惠活动范围类型；1:商品;2:订单;3:商品集

    private Integer preferValue = 0;//优惠值（金额/分；积分/百个）

    private Integer orderProductId;//订单商品id（单品优惠活动主商品id）

    private Integer hasGift;//是否有赠品（0：没有；1有）

    /** 商家分摊比例 */
    private BigDecimal merchantForm = new BigDecimal(0);

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Integer productPrice) {
        this.productPrice = productPrice;
    }

    public Integer getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(Integer sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getDifference() {
        return difference;
    }

    public void setDifference(Integer difference) {
        this.difference = difference;
    }

    public Integer getActiveId() {
        return activeId;
    }

    public void setActiveId(Integer activeId) {
        this.activeId = activeId;
    }

    public Integer getFullReduceMoney() {
        return fullReduceMoney;
    }

    public void setFullReduceMoney(Integer fullReduceMoney) {
        this.fullReduceMoney = fullReduceMoney;
    }

    public Integer getOrderParentId() {
        return orderParentId;
    }

    public void setOrderParentId(Integer orderParentId) {
        this.orderParentId = orderParentId;
    }

    public Integer getActiveType() {
        return activeType;
    }

    public void setActiveType(Integer activeType) {
        this.activeType = activeType;
    }

    public Integer getPreferValue() {
        return preferValue;
    }

    public void setPreferValue(Integer preferValue) {
        this.preferValue = preferValue;
    }

    public Integer getOrderProductId() {
        return orderProductId;
    }

    public void setOrderProductId(Integer orderProductId) {
        this.orderProductId = orderProductId;
    }

    public Integer getHasGift() {
        return hasGift;
    }

    public void setHasGift(Integer hasGift) {
        this.hasGift = hasGift;
    }

    public Integer getSellNum() {
        return sellNum;
    }

    public void setSellNum(Integer sellNum) {
        this.sellNum = sellNum;
    }

    public BigDecimal getPlatform() {
        return platform;
    }

    public void setPlatform(BigDecimal platform) {
        this.platform = platform;
    }

    public Integer getProductNum() {
        return productNum;
    }

    public void setProductNum(Integer productNum) {
        this.productNum = productNum;
    }

    public BigDecimal getMerchantForm() {
        return merchantForm;
    }

    public void setMerchantForm(BigDecimal merchantForm) {
        this.merchantForm = merchantForm;
    }
}
