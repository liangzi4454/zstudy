package com.sfbest.financial.db.entity.gshop.query;

import java.io.Serializable;

/**
 * Created by 01061941 on 2017/2/28.
 */
public class GshopRefundVoucherParam implements Serializable {

    private static final long serialVersionUID = -452520398291381445L;

    private Integer id; //退款单id
    private String resourceSn;//单据编号

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getResourceSn() {
        return resourceSn;
    }

    public void setResourceSn(String resourceSn) {
        this.resourceSn = resourceSn;
    }
}
