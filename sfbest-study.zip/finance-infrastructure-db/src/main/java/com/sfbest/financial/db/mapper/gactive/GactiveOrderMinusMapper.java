package com.sfbest.financial.db.mapper.gactive;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by 01061941 on 2017/3/27.
 */
@Mapper
public interface GactiveOrderMinusMapper {
    /**
     * 获取下单立减分摊比例
     * @param activeId 活动ID
     * @return
     */
    public Map<String, BigDecimal> queryCostSharingByActiveId(@Param("activeId") Integer activeId);
}
