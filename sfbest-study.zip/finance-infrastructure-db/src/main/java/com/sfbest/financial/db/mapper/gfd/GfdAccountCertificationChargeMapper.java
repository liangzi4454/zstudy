package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountCertificationCharge;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 凭证中间业务数据配置
 */
@Mapper
public interface GfdAccountCertificationChargeMapper {

    int deleteByPrimaryKey(Integer id);

    int insertSelective(GfdAccountCertificationCharge record);

    GfdAccountCertificationCharge selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(GfdAccountCertificationCharge record);

    String queryChargeItemCodes(String className);

    /**
     * 根据名称判断当前是否已经存在该数据
     * @param name
     * @param id
     * @return
     */
    int queryCountByName(@Param("name")String name, @Param("id")int id);
    /**
     * 分页查询数量
     * @return
     */
    int queryForListCount();
    /**
     * 分页查询
     * @param startIndex
     * @param endIndex
     * @return
     */
    List<GfdAccountCertificationCharge> queryForList(@Param("startIndex") int startIndex, @Param("endIndex") int endIndex);
}