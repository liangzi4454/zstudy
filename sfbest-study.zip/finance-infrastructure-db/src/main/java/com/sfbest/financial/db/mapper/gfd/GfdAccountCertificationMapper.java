package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 *  处理物资出入库,采购盘点等做账的中间表数据
 */
@Mapper
public interface GfdAccountCertificationMapper {
    /**
     *
     * @param record
     * @return
     */
    int insertSelective(GfdAccountCertification record);
    /**
     *
     * @param record
     * @return
     */
    int insertBatch(List<GfdAccountCertification> record);
    /**
     *
     * @param id
     * @return
     */
    GfdAccountCertification queryByPrimaryKey(Integer id);

    /**
     * 查询所有数据
     * @return
     */
    List<GfdAccountCertification> queryAll();
    /**
     * 根据billCode查询所有数据
     * @param billCode
     * @return
     */
    List<GfdAccountCertification> queryAllByBillCode(String billCode);

    /**
     * 查询数量
     * @return
     */
    int queryForListCount(Map<String, Object> upMap);

    /**
     * 分页查询
     * @param startIndex 开始页
     * @param endIndex 结束页
     * @return
     */
    List<GfdAccountCertification> queryForList(Map<String, Object> upMap);
}