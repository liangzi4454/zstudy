package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountChargeItem;
import com.sfbest.financial.db.entity.gfd.TemporaryStorageResult;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 费用类型模板处理类
 */
@Mapper
public interface GfdAccountChargeItemMapper {
    /**
     * 删除数据
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 插入数据
     * @param item
     * @return
     */
    int insertSelective(GfdAccountChargeItem item);

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    GfdAccountChargeItem selectByPrimaryKey(Integer id);

    /**
     * 更新数据
     * @param item
     * @return
     */
    int updateByPrimaryKeySelective(GfdAccountChargeItem item);

    /**
     * 查询所有数据
     * @return
     */
    List<GfdAccountChargeItem> queryAll();
    /**
     * 根据外键查询所有跟模板头关联的数据
     * @param mouldId
     * @return
     */
    List<GfdAccountChargeItem> queryAllByMouldId(int mouldId);

    /**
     * 根据chargeId编码判断费用类型是否已经被别的模板使用
     * @param chargeId
     * @param mouldId
     * @return
     */
    int queryCountByChargeId(@Param("chargeId")int chargeId, @Param("mouldId")int mouldId);

    /**
     *
     * @param chargeId
     * @return
     */
    GfdAccountChargeItem queryAllByChargeId(int chargeId);

    /**
     * 当同一个费用类型只能被一个模板使用的时候调用该方法返回一个费用类型ID
     * @param list
     * @return
     */
    List<Integer> queryMouldIdByChargeItemCode(List<String> list);
    /**
     * 根据charge_item_code(费用类型编码)关联gfd_account_charge_item和gfd_account_charge查询模板id
     * @param list
     * @return
     */
    @Deprecated
    List<TemporaryStorageResult> queryAllByChargeItemCode(List<String> list);
    /**
     * 根据两个外键判断该费用类型是否已经被使用
     * @param id
     * @param mouldId
     * @param chargeId
     * @return
     */
    int queryCountExist(@Param("id")int id, @Param("mouldId")int mouldId, @Param("chargeId")List<Integer> chargeId);

    int queryChargeIdCount(int chargeId);
}