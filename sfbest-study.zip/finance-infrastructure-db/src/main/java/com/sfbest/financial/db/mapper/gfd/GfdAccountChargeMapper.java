package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountCharge;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 费用类型模板处理类
 */
@Mapper
public interface GfdAccountChargeMapper {
    /**
     * 删除数据
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 插入数据
     * @param item
     * @return
     */
    int insertSelective(GfdAccountCharge item);

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    GfdAccountCharge selectByPrimaryKey(Integer id);

    /**
     * 更新数据
     * @param item
     * @return
     */
    int updateByPrimaryKeySelective(GfdAccountCharge item);
    /**
     * 分页查询数量
     * @return
     */
    int queryForListCount();
    /**
     * 分页查询
     * @param startIndex
     * @param endIndex
     * @return
     */
    List<GfdAccountCharge> queryForList(@Param("startIndex") int startIndex, @Param("endIndex") int endIndex);
    /**
     * 查询所有数据
     * @return
     */
    List<GfdAccountCharge> queryAll();
    /**
     * 根据条件查询重复数据数量:添加和修改时使用
     * @param item
     * @return
     */
    int queryCount(GfdAccountCharge item);

    /**
     * 查询费用类型: 生成凭证的时候使用
     * @param chargeItemCode
     * @return
     */
    int queryByChargeItemCode(String chargeItemCode);

    /**
     * 凭证模板选择费用类型时调用
     * @param name
     * @return
     */
    List<GfdAccountCharge> queryAllByName(String name);

    /**
     * 根据id查询对应的code值
     * @param id
     * @return
     */
    String queryChargeItemCodeById(Integer id);
}