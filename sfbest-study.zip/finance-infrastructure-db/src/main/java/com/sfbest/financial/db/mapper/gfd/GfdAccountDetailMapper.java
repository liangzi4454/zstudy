package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface GfdAccountDetailMapper {
    /**
     * 根据id查询单条数据
     * @param id
     * @return
     */
    GfdAccountDetail queryByPrimaryKey(Integer id);

    /**
     * 通过凭证头的headerSn查询到与之关联的所有凭证体信息
     * @param headerSn
     * @return
     */
    List<GfdAccountDetail> queryAllByHeaderSn(String headerSn);

    /**
     * 插入数据
     * @param gfdAccountDetail
     * @return
     */
    int insertSelective(GfdAccountDetail gfdAccountDetail);

    /**
     * 批量插入
     * @param list
     * @return
     */
    int insertBatch(List<GfdAccountDetail> list);
}