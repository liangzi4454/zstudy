package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 *  处理总账基本信息
 */
@Mapper
public interface GfdAccountHeaderMapper {

    GfdAccountHeader queryByPrimaryKey(Integer id);

    List<GfdAccountHeader> queryAll();

    int insertSelective(GfdAccountHeader record);
    /**
     * 判断bill_id相等的数量
     * @param billId
     * @return
     */
    int queryCountByBillId(String billId);

    /**
     * 查询数量
     * @param upMap 查询条件
     * @return
     */
    int queryForListCount(Map<String , Object> upMap);

    /**
     * 分页查询
     * @param upMap 查询条件
     * @return
     */
    List<GfdAccountHeader> queryForList(Map<String , Object> upMap);

    /**
     * 根据headerSn查询唯一凭证信息
     * @param list 凭证唯一编码
     * @return 凭证头信息
     */
    List<GfdAccountHeader> queryByHeaderSn(List<String> list);
    /**
     * 根据凭证的创建时间查询出凭证头信息
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return
     */
    List<GfdAccountHeader> queryByCreateTime(@Param("startTime")long startTime, @Param("endTime")long endTime);
    /**
     * 批量更新凭证的处理状态
     * @param list 凭证编号集合
     * @param status 状态
     * @return
     * @throws Exception
     */
    int updateDealStatusByVoucherIds(@Param("list")List<String> list, @Param("status")Integer status);

    /**
     * 批量更新NC返回数据
     * @param voucherList
     * @return
     */
    int updateDealStatusBatch(List voucherList);
}