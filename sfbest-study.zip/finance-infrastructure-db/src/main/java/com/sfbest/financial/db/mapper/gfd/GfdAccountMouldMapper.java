package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountMould;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GfdAccountMouldMapper {
    /**
     * 删除数据
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 插入数据
     * @param record
     * @return
     */
    int insertSelective(GfdAccountMould record);

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    GfdAccountMould selectByPrimaryKey(Integer id);

    /**
     * 更新单条数据
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(GfdAccountMould record);

    /**
     * 根据条件查询多条数据
     * @param gfdAccountMould
     * @return
     */
    List<GfdAccountMould> selectBySelective(GfdAccountMould gfdAccountMould);

    /**
     * 根据名称判断当前是否已经存在该数据
     * @param name
     * @param id
     * @return
     */
    int queryCountByName(@Param("name")String name, @Param("id")int id);

    /**
     * 查询借的数量
     * @param id
     * @return
     */
    int queryDebitNumber(int id);

    /**
     * 查询贷的数量
     * @param id
     * @return
     */
    int queryCreditNumber(int id);
    /**
     * 分页查询数量
     * @return
     */
    int queryForListCount();
    /**
     * 分页查询
     * @param startIndex
     * @param endIndex
     * @return
     */
    List<GfdAccountMould> queryForList(@Param("startIndex") int startIndex, @Param("endIndex") int endIndex);
}