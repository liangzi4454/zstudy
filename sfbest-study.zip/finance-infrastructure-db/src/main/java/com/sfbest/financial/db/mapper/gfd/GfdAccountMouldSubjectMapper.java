package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountMouldSubject;
import com.sfbest.financial.db.entity.gfd.GfdAccountMouldSubjectVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 模板体信息处理类
 * Created by LHY on 2017/3/22.
 */
@Mapper
public interface GfdAccountMouldSubjectMapper {
    /**
     * 删除数据
     * @param id 主键
     * @return
     */
    int deleteByPrimaryKey(Integer id);
    /**
     * 插入数据
     * @param record 数据
     * @return
     */
    int insertSelective(GfdAccountMouldSubject record);
    /**
     * 根据主键查询单挑数据
     * @param id
     * @return
     */
    GfdAccountMouldSubject selectByPrimaryKey(Integer id);
    /**
     * 更新数据
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(GfdAccountMouldSubject record);

    /**
     * 根据根据凭证头信息查询凭证体信息
     * @param mouldId
     * @return
     */
    List<GfdAccountMouldSubject> queryAll(Integer mouldId);

    /**
     * 根据分录id查询数量,删除的时候使用
     * @param mouldId
     * @return
     */
    int queryCount(Integer mouldId);

    /**
     * 根据分录id和借贷类型,判断当前分录下借贷的数量
     * @param mouldId
     * @param debitCredit
     * @return
     */
    int queryDebitCreditNumber(@Param("mouldId") int mouldId, @Param("debitCredit") int debitCredit, @Param("id") int id);
    /**
     * 根据名称判断当前是否已经存在该数据
     * @param subjectCode
     * @param id
     * @return
     */
    int queryCountBySubjectCode(@Param("subjectCode")String subjectCode, @Param("id")int id, @Param("mouldId") int mouldId);

    /**
     *
     * @param mouldId
     * @param chargeItemCode
     * @return
     */
    @Deprecated
    List<GfdAccountMouldSubjectVO> queryAllByChargeItemCodeAndMouldId(@Param("mouldId")int mouldId, @Param("chargeItemCode")String chargeItemCode);
    /**
     * 分页查询数量
     * @param mouldId
     * @return
     */
    int queryForListCount(int mouldId);
    /**
     * 分页查询
     * @param mouldId
     * @param startIndex
     * @param endIndex
     * @return
     */
    List<GfdAccountMouldSubject> queryForList(@Param("mouldId") int mouldId, @Param("startIndex") int startIndex, @Param("endIndex") int endIndex);
}