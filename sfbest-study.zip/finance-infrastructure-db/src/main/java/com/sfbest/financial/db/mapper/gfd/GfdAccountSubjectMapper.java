package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdAccountSubject;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GfdAccountSubjectMapper {

    int deleteByPrimaryKey(Integer id);

    int insertSelective(GfdAccountSubject gfdAccountSubject);

    GfdAccountSubject selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(GfdAccountSubject gfdAccountSubject);

    List<GfdAccountSubject> selectBySelective(GfdAccountSubject gfdAccountSubject);

    /**
     * 根据EntrySubjectCode查询当前数据是否已经存在
     * @param subjectCode
     * @return
     */
    int queryCountBySubjectCode(@Param("subjectCode")String subjectCode, @Param("id")int id);
    /**
     * 查询所有的数据
     * @return
     */
    List<GfdAccountSubject> queryAll();

    /**
     * 分页查询数量
     * @return
     */
    int queryForListCount();
    /**
     * 分页查询
     * @param startIndex 开始行
     * @param endIndex 结束行
     * @return
     */
    List<GfdAccountSubject> queryForList(@Param("startIndex") int startIndex, @Param("endIndex") int endIndex);
}