package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdOrderActiveProductMoneyUseMessage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * Created by 01061941 on 2017/3/27.
 */
@Mapper
public interface GfdOrderActiveProductMoneyUseMessageMapper {

    void insertOrderActiveProductMoneyUseMessage(GfdOrderActiveProductMoneyUseMessage order);

    int queryOrderActiveProductMoneyUseMessageCount(@Param("parentOrderId") int parentOrderId, @Param("orderId") int orderId, @Param("orderProductId") int orderProductId, @Param("activeId") int activeId);
}
