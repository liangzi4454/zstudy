package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdZadminEmail;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface GfdZadminEmailMapper {
    /**
     * 删除数据
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);
    /**
     * 插入数据
     * @param record
     * @return
     */
    int insertSelective(GfdZadminEmail record);
    /**
     * 查询数据
     * @param id
     * @return
     */
    GfdZadminEmail selectByPrimaryKey(Integer id);
    /**
     * 更新数据
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(GfdZadminEmail record);
    /**
     * 查询数据量
     * @return
     */
    int queryForListCount();
    /**
     * 分页查询数据
     * @param startIndex 起始页
     * @param endIndex 结束页
     * @return
     */
    List<GfdZadminEmail> queryForList(@Param("startIndex")int startIndex, @Param("endIndex")int endIndex);
    /**
     * 根据code查询邮件地址
     * @param code
     * @return
     */
    List<String> queryEmailByCode(String code);
}