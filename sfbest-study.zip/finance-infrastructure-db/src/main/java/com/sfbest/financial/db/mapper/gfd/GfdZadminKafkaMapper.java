package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 *  处理kafka主题信息等数据
 */
@Mapper
public interface GfdZadminKafkaMapper {
    /**
     *
     * @param id
     * @return
     */
    GfdZadminKafka queryByPrimaryKey(Integer id);
    /**
     *
     * @param record
     * @return
     */
    int insertSelective(GfdZadminKafka record);
    /**
     *
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(GfdZadminKafka record);

    /**
     * 查询所有数据
     * @return
     */
    List<GfdZadminKafka> queryAll();

    /**
     * 查询数据量
     * @return
     */
    int queryForListCount();
    /**
     * 分页查询数据
     * @param startIndex 起始页
     * @param endIndex 结束页
     * @return
     */
    List<GfdZadminKafka> queryForList(@Param("startIndex")int startIndex, @Param("endIndex")int endIndex);
    /**
     * 删除数据
     * @param id
     * @return
     */
    int deleteByPrimaryKey(int id);

    /**
     * 判断数据是否存在:在添加和更新的时候调用
     * @param kafka
     * @return
     */
    int queryExistCount(GfdZadminKafka kafka);
    /**
     * 查询可运行的数据
     * @return
     */
    List<GfdZadminKafka> queryAllRunnable();
}