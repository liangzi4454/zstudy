package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.ReceiveOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * Created by 603513 on 2017/2/24.
 */
@Mapper
public interface ReceiveOrderMapper {

    @Select("SELECT * FROM gfd_receive_order  limit 10")
    public List<ReceiveOrder> queryForId();

    public int insertReceive(ReceiveOrder order);
}
