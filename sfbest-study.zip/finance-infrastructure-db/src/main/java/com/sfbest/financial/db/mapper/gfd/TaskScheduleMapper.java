package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.entity.gfd.TaskSchedule;
import org.apache.ibatis.annotations.Param;


/**
 * 
 * TaskScheduleMapper数据库操作接口类
 * 
 **/

public interface TaskScheduleMapper {

	/**
	 * 查询（根据任务编号查询）
	 *
	 * @author 738803 董玉帅
	 * @created 2015年6月16日 下午5:31:15
	 *
	 * @param taskKey
	 * @return
	 */
	TaskSchedule query(@Param("taskKey") String taskKey);

	/**
	 * 添加 （匹配有值的字段）
	 *
	 * @author 738803 董玉帅
	 * @created 2015年6月16日 下午5:31:24
	 *
	 * @param record
	 * @return
	 */
	int save(TaskSchedule record);

	/**
	 * 修改 （匹配有值的字段）
	 *
	 * @author 738803 董玉帅
	 * @created 2015年6月16日 下午5:31:30
	 *
	 * @param record
	 * @return
	 */
	int update(TaskSchedule record);
}