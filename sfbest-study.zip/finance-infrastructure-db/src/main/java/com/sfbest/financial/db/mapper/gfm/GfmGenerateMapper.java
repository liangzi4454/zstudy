package com.sfbest.financial.db.mapper.gfm;

import org.apache.ibatis.annotations.Mapper;

/**
 * 根据传入的code值生成当天有次序的编码;
 * 例如: 今天的日期是20170307,传入的code=FMS,返回值为FMS20170307100001,顺序递增;
 * Created by LHY on 2017/3/7.
 */
@Mapper
public interface GfmGenerateMapper {
    String getCode(String code);
}