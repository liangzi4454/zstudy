package com.sfbest.financial.db.mapper.gshop;

import com.sfbest.financial.db.entity.gshop.GShopWareHouse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface GShopWareHouseMapper {
    int removeAll();

    GShopWareHouse selectByPrimaryKey(Short warehouseId);

    List<GShopWareHouse> selectByPage();

    int updateByPrimaryKeySelective(GShopWareHouse record);

    int updateByPrimaryKey(GShopWareHouse record);
}