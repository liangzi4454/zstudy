package com.sfbest.financial.db.mapper.gshop;

import com.sfbest.financial.db.entity.gshop.GshopAccountInOut;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 查询入库单表和仓库退货单表,做凭证的基础数据
 */
@Mapper
public interface GshopAccountInOutMapper {
    /**
     * 根据结束时间，获取出入库数据包括(海外直采出库,代销商出入库,经销商出入库单据)
     * @param endTime
     * @return
     */
    List<GshopAccountInOut> queryMaterialsInOut(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 查询海外直采出库单据
     * @param startTime
     * @param endTime
     * @return
     */
    List<GshopAccountInOut> queryOverseaAccount(@Param("startTime") long startTime, @Param("endTime") long endTime);

    /**
     * 查询代销商出入库单据
     * @param startTime
     * @param endTime
     * @return
     */
    List<GshopAccountInOut> queryAgentAccount(@Param("startTime") long startTime, @Param("endTime") long endTime);

    /**
     * 查询经销商出入库单据
     * @param startTime
     * @param endTime
     * @return
     */
    List<GshopAccountInOut> queryDealerAccount(@Param("startTime") long startTime, @Param("endTime") long endTime);
}