package com.sfbest.financial.db.mapper.gshop;

import com.sfbest.financial.db.entity.gshop.GshopOrder;
import com.sfbest.financial.db.entity.gshop.GshopOrderProduct;
import com.sfbest.financial.db.entity.gshop.OrderActiveProductResult;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by 01061941 on 2017/3/24.
 */
@Mapper
public interface GshopOrderMapper {

    GshopOrder selectByPrimaryKey(Integer orderId);

    List<GshopOrder> queryPresellOrderByAddTime(@Param("beginTime")Integer beginTime,@Param("endTime")Integer endTime);

    /**
     * 查询所有订单活动中的限时抢购商品(10015)
     * @param orderId
     * @param activeCode
     * @return
     */
    public List<OrderActiveProductResult> queryFlashSale(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 查询所有订单活动中的加价购商品(10016)
     * @param orderId
     * @param activeCode
     * @return
     */
    public List<OrderActiveProductResult> queryAdditional(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 查询所有订单活动中的N/M件活动商品(10018) 但是查询活动是从gshop_order_product表中product_type='6'开始算
     * @param orderId
     * @param activeCode
     * @return
     */
    public List<OrderActiveProductResult> queryNMActive(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 查询所有订单活动中的满减商品(10008)
     * @param orderId
     * @param activeCode
     * @return
     */
    List<OrderActiveProductResult> queryFullReduce(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 查询所有订单活动中的首单立减商品(10022)
     * @param orderId
     * @param activeCode
     * @return
     */
    List<OrderActiveProductResult> queryDownTheFirstSingle(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     *  查询大礼包,当前大礼包没有active_code，没有active_id，所有分摊都是"深电"一家承担
     * @param orderId
     * @param activeCode
     * @return
     */
    public List<OrderActiveProductResult> queryGiftPacks(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 单品直降
     * @param orderId
     * @param activeCode
     * @return
     */
    List<OrderActiveProductResult> querySingleProductStraightDown(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 买赠10004
     * @param orderId
     * @param activeCode
     * @return
     */
    List<OrderActiveProductResult> queryBuyOneGetGiftsFree(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 预售活动10025
     * @param orderId
     * @param activeCode
     * @return
     */
    List<OrderActiveProductResult> queryPreSellActive(@Param("orderId")Integer orderId, @Param("activeCode")Integer activeCode);
    /**
     * 方法作用:查询商品满减信息;<br/>
     * 业务逻辑:一个订单( o )有两个活动(A, B),一个订单( o )有四个商品(P1, P2, P3, P4),一个活动有两个商品(A:P1,P2; B:P3,P4);
     *          此时我们就需要查询出其对应关系,
     * 涉及表结构:gshop_order_product、gshop_order_active_product;<br/>
     * @param orderId 订单id
     * @param activeId 活动id
     * @return
     */
    List<GshopOrderProduct> queryOrderProductListByActiveId(@Param("orderId")Integer orderId, @Param("activeId")Integer activeId);
    List<GshopOrderProduct> queryOrderProductListByActiveId4SDLJ(@Param("orderId")Integer orderId, @Param("activeId")Integer activeId);

}
