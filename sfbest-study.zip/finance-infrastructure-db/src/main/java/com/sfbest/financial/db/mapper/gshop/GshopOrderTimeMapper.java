package com.sfbest.financial.db.mapper.gshop;

import com.sfbest.financial.db.entity.gshop.GshopOrderTime;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GshopOrderTimeMapper {

    GshopOrderTime selectByPrimaryKey(Integer id);

    List<GshopOrderTime> queryActivityOrderBySplitTime(@Param("beginTime")Integer beginTime, @Param("endTime")Integer endTime);
}