package com.sfbest.financial.db.mapper.gshop;

import com.sfbest.financial.db.entity.gshop.GshopRefundVoucherExt;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * Created by 01061941 on 2017/2/27.
 */
@Mapper
public interface GshopRefundVoucherExtMapper {

    /**
     *查询退款单EXT
     * @param refundId
     * @return
     */
    GshopRefundVoucherExt queryRefundVoucherExt(@Param("refundId")Integer refundId);

    /**
     * 插入退款EXT
     * @param gshopRefundVoucherExt
     * @return
     */
    Integer insertRefundExt(GshopRefundVoucherExt gshopRefundVoucherExt);

    /**
     * 更新退款EXT
     * @param gshopRefundVoucherExt
     * @return
     */
    Integer updateRefundExt(GshopRefundVoucherExt gshopRefundVoucherExt);

}
