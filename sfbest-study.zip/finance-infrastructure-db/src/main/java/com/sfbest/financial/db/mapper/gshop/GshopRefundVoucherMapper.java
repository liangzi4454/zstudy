package com.sfbest.financial.db.mapper.gshop;

import com.sfbest.financial.db.entity.gshop.GshopRefundVoucher;
import com.sfbest.financial.db.entity.gshop.query.GshopRefundVoucherParam;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * Created by 01061941 on 2017/2/27.
 */
@Mapper
public interface GshopRefundVoucherMapper {

    /**
     * @param gshopRefundVoucherParam
     * @return
     */
    List<GshopRefundVoucher> selectGshopRefundVoucherList(GshopRefundVoucherParam gshopRefundVoucherParam);

    /**
     * 更新退款单状态
     * @param gshopRefundVoucher
     * @return
     */
    Integer updateGshopRefundVoucherById(GshopRefundVoucher gshopRefundVoucher);

}
