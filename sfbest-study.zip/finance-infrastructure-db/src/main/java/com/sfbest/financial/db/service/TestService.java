package com.sfbest.financial.db.service;

import com.sfbest.financial.db.entity.gfd.ReceiveOrder;
import com.sfbest.financial.db.mapper.gfd.ReceiveOrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by 603513 on 2017/2/27.
 */
@Service
public class TestService {

    @Autowired
    ReceiveOrderMapper mapper;


    @Transactional(value="gfdTransactionManager")
    public void insertReceive(){
        ReceiveOrder o=new ReceiveOrder();
        o.setOrderId(1);
        mapper.insertReceive(o);
       // throw new RuntimeException();
    }
}
