package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.Application;
import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by LHY on 2017/3/9.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class GfdAccountCertificationMapperTest {
    @Resource
    private GfdAccountCertificationMapper gfdAccountCertificationMapper;

    @Resource
    private GfdAccountHeaderMapper gfdAccountHeaderMapper;

    @Resource
    private GfdAccountDetailMapper gfdAccountDetailMapper;



    @Test
    public void testInsertSelective() throws Exception {
        GfdAccountCertification account = new GfdAccountCertification();
        account.setBillCode("FMS20170309104942");
        account.setInvoiceCode(account.getBillCode());
        account.setCustomerCode("C000010003");
        account.setVipCode(account.getCustomerCode());
        account.setGlDt(1489038299L);
        account.setBillStartDt(1489038299l);
        account.setBillEndDt(1489038299l);
        account.setBillPeriod(1489038299l);
        account.setUniqueId("FMS201703091049410729375723868");
        account.setChargeItemCode("HCRKPZ-PPPP");
        account.setCreateTime(Integer.valueOf(String.valueOf(new Date().getTime()/1000L)));
        gfdAccountCertificationMapper.insertSelective(account);
    }

    @Test
    public void testInsertBatch() throws Exception {
        GfdAccountHeader gah=new GfdAccountHeader();
        gah.setAccountType("1");
        gah.setMakingDate(new Date());
        gfdAccountHeaderMapper.insertSelective(gah);

    }

    @Test
    public void testQueryByPrimaryKey() throws Exception {
        GfdAccountCertification account = gfdAccountCertificationMapper.queryByPrimaryKey(5831);
        System.out.println(account.getChargeItemCode());
    }

    @Test
    public void testUpdateDealStatusByVoucherIds() throws Exception {
        List<String> voucherIds = new ArrayList<String>();
        voucherIds.add("811170414536236");
        voucherIds.add("811170414739111");
        gfdAccountHeaderMapper.updateDealStatusByVoucherIds(voucherIds, 2);
    }
}