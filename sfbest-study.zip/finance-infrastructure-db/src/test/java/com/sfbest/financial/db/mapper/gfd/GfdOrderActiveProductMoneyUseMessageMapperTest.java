package com.sfbest.financial.db.mapper.gfd;

import com.alibaba.fastjson.JSONObject;
import com.sfbest.financial.db.Application;
import com.sfbest.financial.db.entity.gfd.GfdOrderActiveProductMoneyUseMessage;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by 01061941 on 2017/3/27.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class GfdOrderActiveProductMoneyUseMessageMapperTest {

    @Autowired
    GfdOrderActiveProductMoneyUseMessageMapper gfdOrderActiveProductMoneyUseMessageMapper;

    @Test
    public void queryOrderActiveProductMoneyUseMessageCount(){
        int ss= gfdOrderActiveProductMoneyUseMessageMapper.queryOrderActiveProductMoneyUseMessageCount(0,889413040,51340432,312758);
        System.out.println(JSONObject.toJSONString(ss));
    }

    @Test
    public void insertOrderActiveProductMoneyUseMessage(){
        GfdOrderActiveProductMoneyUseMessage order=new GfdOrderActiveProductMoneyUseMessage();
        order.setParentOrderId(0);
        order.setOrderId(889413040);
        order.setOrderProductId(51340432);
        order.setActiveId(312758);
        order.setActiveCode(10015);
        gfdOrderActiveProductMoneyUseMessageMapper.insertOrderActiveProductMoneyUseMessage(order);
        System.out.println("OK");
    }
}
