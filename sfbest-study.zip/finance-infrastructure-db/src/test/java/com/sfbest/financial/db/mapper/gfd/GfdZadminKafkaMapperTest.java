package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.Application;
import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Created by LHY on 2017/3/9.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class GfdZadminKafkaMapperTest {
    @Resource
    private GfdZadminKafkaMapper gfdZadminKafkaMapper;
    @Test
    public void testQueryByPrimaryKey() throws Exception {
        GfdZadminKafka kafka = gfdZadminKafkaMapper.queryByPrimaryKey(1);
        System.out.println(kafka.getClassName());
    }

    @Test
    public void testInsertSelective() throws Exception {
        GfdZadminKafka gfdZadminKafka = new GfdZadminKafka();
        gfdZadminKafka.setClassName("com.sfbest.financial.db.entity.gfd.GfdZadminKafka");
        gfdZadminKafka.setCreateTime(Integer.valueOf(String.valueOf(new Date().getTime()/1000L)));
        gfdZadminKafka.setGroupId("test1");
        gfdZadminKafka.setNum(3);
        gfdZadminKafka.setTopic("test1");
        gfdZadminKafka.setStatus(0);
        gfdZadminKafka.setIsDelete(0);
        gfdZadminKafkaMapper.insertSelective(gfdZadminKafka);
    }

    @Test
    public void testUpdateByPrimaryKeySelective() throws Exception {
        GfdZadminKafka gfdZadminKafka = new GfdZadminKafka();
        gfdZadminKafka.setId(1);
        gfdZadminKafka.setClassName("com.sfbest.financial.db.entity.gfd.GfdZadminKafka");
        gfdZadminKafka.setCreateTime(Integer.valueOf(String.valueOf(new Date().getTime()/1000L)));
        gfdZadminKafka.setGroupId("test2");
        gfdZadminKafka.setNum(1);
        gfdZadminKafka.setTopic("test2");
        gfdZadminKafka.setStatus(0);
        gfdZadminKafka.setIsDelete(0);
        gfdZadminKafkaMapper.updateByPrimaryKeySelective(gfdZadminKafka);
    }

    @Test
    public void testQueryAll() throws Exception {
        List<GfdZadminKafka> list = gfdZadminKafkaMapper.queryAll();
        for(GfdZadminKafka kafka: list) {
            System.out.println(kafka.getClassName());
        }
    }
    @Test
    public void queryForList() {
        List<GfdZadminKafka> list = gfdZadminKafkaMapper.queryForList(0, 2);
        for(GfdZadminKafka kafka: list) {
            System.out.println(kafka.getClassName());
        }
    }
}