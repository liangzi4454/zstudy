/*
package com.sfbest.financial.db.mapper.gfd;

import com.sfbest.financial.db.Application;
import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;
import com.sfbest.financial.db.service.TestService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class ReceiveOrderMapperTest  {

    @Autowired
    ReceiveOrderMapper receiveOrderMapper;

    @Autowired
    GfdZadminKafkaMapper gfdZadminKafkaMapper;

    @Autowired
    TestService service;

    @Test
    public void testQ(){
        System.out.println(receiveOrderMapper.queryForId());
    }

    @Test
    public void testGshop(){
        GfdZadminKafka gk = gfdZadminKafkaMapper.queryByPrimaryKey(1);
        gk.setId(0);
        gk.setGroupId("kkkk");
        int num=gfdZadminKafkaMapper.insertSelective(gk);
        System.out.println("------"+num);
        gfdZadminKafkaMapper.deleteByPrimaryKey(1);
        gk.setId(2);
        gk.setGroupId("3333");
        gfdZadminKafkaMapper.updateByPrimaryKeySelective(gk);
    }


    @Test
    public void testServie(){

        System.out.println(receiveOrderMapper.queryForId());
        service.insertReceive();
    }


}*/
