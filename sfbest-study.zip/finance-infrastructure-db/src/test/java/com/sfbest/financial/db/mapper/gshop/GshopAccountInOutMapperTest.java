package com.sfbest.financial.db.mapper.gshop;

import com.sfbest.financial.db.Application;
import com.sfbest.financial.db.entity.gshop.GshopAccountInOut;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.List;

/**
 * Created by LHY on 2017/3/9.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class GshopAccountInOutMapperTest {
    @Resource
    private GshopAccountInOutMapper gshopAccountInOutMapper;
    @Test
    public void testQueryMaterialsInOut() throws Exception {
        List<GshopAccountInOut> list = gshopAccountInOutMapper.queryMaterialsInOut("", "2017-03-20");

        for(GshopAccountInOut account: list) {
            System.out.println("basic_id======"+account.getBasicId());
        }
    }
}