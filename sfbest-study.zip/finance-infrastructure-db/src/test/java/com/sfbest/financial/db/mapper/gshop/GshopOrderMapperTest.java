package com.sfbest.financial.db.mapper.gshop;

import com.alibaba.fastjson.JSONObject;
import com.sfbest.financial.db.Application;
import com.sfbest.financial.db.entity.gshop.OrderActiveProductResult;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * Created by 01061941 on 2017/3/27.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class GshopOrderMapperTest {

    @Autowired
    GshopOrderMapper gshopOrderMapper;

    @Test
    public void queryFlashSale(){

        List<OrderActiveProductResult> ss= gshopOrderMapper.queryFlashSale(51340432,10015);
        System.out.println(JSONObject.toJSONString(ss));

    }
}
