package com.sfbest.financial.db.mapper.gshop;

import com.alibaba.fastjson.JSONObject;
import com.sfbest.financial.db.Application;
import com.sfbest.financial.db.entity.gshop.GshopRefundVoucher;
import com.sfbest.financial.db.entity.gshop.query.GshopRefundVoucherParam;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * Created by 01061941 on 2017/2/27.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class GshopRefundVoucherMapperTest {

    @Autowired
    GshopRefundVoucherMapper gshopRefundVoucherMapper;

    @Test
    public void selectGshopRefundVoucherList(){

        GshopRefundVoucherParam gshopRefundVoucherParam=new GshopRefundVoucherParam();
        gshopRefundVoucherParam.setId(3679);
        List<GshopRefundVoucher> ss= gshopRefundVoucherMapper.selectGshopRefundVoucherList(gshopRefundVoucherParam);
        System.out.println(JSONObject.toJSONString(ss));

    }
}
