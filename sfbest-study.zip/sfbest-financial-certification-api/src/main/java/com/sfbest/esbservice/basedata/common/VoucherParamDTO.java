package com.sfbest.esbservice.basedata.common;

import java.io.Serializable;

/**
 * Created by LHY on 2017/4/20.
 */
public class VoucherParamDTO implements Serializable {

    private static final long serialVersionUID = 3032194797236696237L;

    private String voucherId;

    private String voucherStatus;	// 凭证处理状态：1发送成功，2发送失败，3处理成功，4处理失败

    private String remarks;

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getVoucherStatus() {
        return voucherStatus;
    }

    public void setVoucherStatus(String voucherStatus) {
        this.voucherStatus = voucherStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
