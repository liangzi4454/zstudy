package com.sfbest.financial.certification;

import com.sfbest.esbservice.basedata.common.VoucherParamDTO;

import java.util.List;

/**
 * <pre>
 * 该方法的调用方式是如下这样回调:
 * NC服务器调用 -> sfbest-esbservice-nc服务(FinanceServiceApiService#syncVoucherStatusFromNC) -> (sfbest-financial-certification)FinanceServiceApiService#syncVoucherStatusFromNC
 * </pre>
 * Created by LHY on 2017/5/17.
 */
public interface FinanceServiceApiService {
    String syncVoucherStatusFromNC(List<VoucherParamDTO> voucherList);
}