package com.sfbest.financial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * 该类为主类(主程序),这是系统的入口，不能改动;从该类路径一下,所有的包以及子包进行自动扫描;
 * EnableAutoConfiguration 调用配置
 * Created by LHY on 2017/2/28.
 */
@SpringBootApplication
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}