package com.sfbest.financial;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * Created by LHY on 2017/5/17.
 */
@Configuration
@ImportResource(locations={"classpath*:/META-INF/sfbest/spring/applicationContext.xml"})
public class ApplicationContext {

}