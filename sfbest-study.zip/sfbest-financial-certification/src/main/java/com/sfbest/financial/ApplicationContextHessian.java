package com.sfbest.financial;

import com.sfbest.financial.certification.FinanceServiceApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.caucho.HessianServiceExporter;

/**
 * 对外发布hessian服务
 * Created by LHY on 2017/5/22.
 */
@Configuration
public class ApplicationContextHessian {

    @Autowired
    private FinanceServiceApiService financeServiceApiService;

    /**
     * Spring使用HessianServiceExporter，将一个常规bean导出成Hessian服务
     * @return
     */
    @Bean(name = "/hessian/api/financeServiceList")
    public HessianServiceExporter exportFinanceServiceApiService() {
        HessianServiceExporter exporter = new HessianServiceExporter();
        exporter.setService(financeServiceApiService);
        exporter.setServiceInterface(FinanceServiceApiService.class);
        return exporter;
    }
}