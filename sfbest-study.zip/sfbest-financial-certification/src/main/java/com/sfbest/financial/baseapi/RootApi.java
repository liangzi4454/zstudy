package com.sfbest.financial.baseapi;

/**
 * Created by LHY on 2017/3/13.
 */
public interface RootApi {

}