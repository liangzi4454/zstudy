package com.sfbest.financial.basecom.baseclass;

import com.sfbest.financial.basehelper.FormatHelper;
import com.sfbest.financial.basehelper.IoHelper;
import com.sfbest.financial.util.PropertiesLoader;
import org.apache.commons.logging.LogFactory;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 打印日志和返回日志消息
 * Created by LHY on 2017/3/27.
 */
public abstract class BaseClass {
    private static ConcurrentHashMap<String, String> threadMap = new ConcurrentHashMap<String, String>();
    private String message = "";

    private String getProperties(String code, String... info) {
        PropertiesLoader loader = new PropertiesLoader();
        if(threadMap!=null && threadMap.get(code)!=null) {
            return FormatHelper.formatString(threadMap.get(code), info);
        }
        IoHelper ioHelper = new IoHelper();
        ioHelper.copyResources("classpath*:META-INF/sfbest/info/*.properties", "info/", "/sfbest/info/");
        threadMap = loader.loadMap("info/");
        return FormatHelper.formatString(threadMap.get(code), info);
    }

    private String cLog(int code) {
        return " [" + code + "] ";
    }

    private String getInfo(int code, String... info) {
        return getProperties(String.valueOf(code), info);
    }

    /** 以下三个方法通过调用配置文件中的日志模板数据并加入参数信息 记录到日志文件**/
    protected String logInfo(int code, String... param) {
        message = getInfo(code, param);
        LogFactory.getLog(getClass()).info(cLog(code)  + " ===> " + message);
        return message;
    }
    protected String logError(int code, String... param) {
        message = getInfo(code, param);
        LogFactory.getLog(getClass()).error(cLog(code)  + " ===> " + message);
        return message;
    }
    protected String logDebug(int code, String... param) {
        message = getInfo(code, param);
        LogFactory.getLog(getClass()).debug(cLog(code)  + " ===> " + message);
        return message;
    }
    protected String logInfo(String param) {
        LogFactory.getLog(getClass()).info(" ===> " + param);
        return param;
    }
    protected String logError(String param) {
        LogFactory.getLog(getClass()).error(" ===> " + param);
        return message;
    }
}