package com.sfbest.financial.basecom.baseclass;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerContext;
import org.quartz.SchedulerException;
import org.springframework.context.ApplicationContext;

public abstract class BaseJob extends BaseClass implements Job {
	protected ApplicationContext getApplicationContext(JobExecutionContext jobCtx) {
		SchedulerContext schedulerContext;
		try {
			schedulerContext = jobCtx.getScheduler().getContext();
		} catch (SchedulerException e) {
            logError("未获取到SchedulerContext实例");
			return null;
		}
		return schedulerContext == null ? null : (ApplicationContext) schedulerContext.get("applicationContextKey");
	}
	abstract public void execute(JobExecutionContext arg0) throws JobExecutionException;
}
