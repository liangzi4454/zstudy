package com.sfbest.financial.basecom.baseface;

/**
 * Created by LHY on 2017/4/21.
 */
public interface BaseResult {
    int getCode();
    String getMessage();
}
