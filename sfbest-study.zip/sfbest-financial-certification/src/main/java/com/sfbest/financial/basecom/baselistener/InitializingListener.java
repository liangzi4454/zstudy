package com.sfbest.financial.basecom.baselistener;

/**
 * Created by LHY on 2017/5/16.
 */
public interface InitializingListener {
    void destroy() throws Exception;
    void initial() throws Exception;
}
