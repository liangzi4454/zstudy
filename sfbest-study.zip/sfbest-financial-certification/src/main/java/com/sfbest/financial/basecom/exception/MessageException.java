package com.sfbest.financial.basecom.exception;

import com.sfbest.financial.certification.email.GfdZadminEmailService;
import com.sfbest.financial.util.MessageProxy;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringBeanUtils;

/**
 * 根据异常信息发送邮件
 * Created by LHY on 2017/5/17.
 */
public class MessageException extends RootException {
    public MessageException(String code) {
        super(code);
    }

    protected void execute(String code) {
        ConfigurationLoader loader = new ConfigurationLoader();
        MessageProxy proxy = SpringBeanUtils.getBean(MessageProxy.class);
        GfdZadminEmailService gfdZadminEmailService = SpringBeanUtils.getBean(GfdZadminEmailService.class);
        proxy.sendEmail(gfdZadminEmailService.queryEmailByCode(loader.load(code)), "凭证中间件消息异常", getMessage());
    }
}