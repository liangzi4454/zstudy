package com.sfbest.financial.basecom.exception;

/**
 * Created by LHY on 2017/5/17.
 */
public abstract class RootException extends Exception {
    /**
     * 异常编码
     * @param code
     */
    public RootException(String code) {
        this.execute(code);
    }

    protected abstract void execute(String code);
}