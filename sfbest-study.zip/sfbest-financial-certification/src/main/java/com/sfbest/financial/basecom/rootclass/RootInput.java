package com.sfbest.financial.basecom.rootclass;

import com.sfbest.financial.basecom.baseface.BaseInput;

/**
 * 输入参数
 * 
 * @author srnpr
 * 
 */
public class RootInput implements BaseInput {

	/**
	 * 版本标记 默认值为1 该参数用于扩展使用
	 */
	private int version = 1;

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
}
