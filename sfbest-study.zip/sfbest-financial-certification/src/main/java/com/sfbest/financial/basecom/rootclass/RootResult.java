package com.sfbest.financial.basecom.rootclass;

import com.sfbest.financial.basecom.baseface.BaseResult;

/**
 * 返回执行结果
 * 
 * @author srnpr
 * 
 */
public class RootResult implements BaseResult {

	/**
	 * 返回标记 如果该标记为1则表明返回结果正确 否则都是错误消息
	 */
	private int code = 1;

	/**
	 * 返回消息 一般用于返回错误描述或者操作提示
	 */
	private String message = "";

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
