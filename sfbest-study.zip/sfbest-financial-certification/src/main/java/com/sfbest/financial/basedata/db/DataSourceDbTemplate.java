package com.sfbest.financial.basedata.db;

import javax.sql.DataSource;

/**
 * Created by LHY on 2017/4/26.
 */

public class DataSourceDbTemplate extends DbTemplate {
    public DataSourceDbTemplate(DataSource dataSource) {
        super(dataSource);
    }
}
