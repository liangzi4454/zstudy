package com.sfbest.financial.basedata.db;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;

/**
 * Created by LHY on 2017/4/26.
 */
public class DbTemplate extends NamedParameterJdbcTemplate {
    public DbTemplate(DataSource dataSource) {
        super(upJdbcTemplate(dataSource));
    }
    private static JdbcOperations upJdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
