package com.sfbest.financial.baseface;

import com.sfbest.financial.basehelper.StringHelper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by LHY on 2017/3/13.
 */
public class PageData<T> {
    /** 表头字段 **/
    private List<T> pageHeader;
    /** 查询数据 **/
    private List<T> pageData;
    /** 分页信息 **/
    private PageInfo pageInfo = new PageInfo();
    /** 查询参数 **/
    private Map<String, Object> queryMap = new HashMap<String, Object>();

    public List<T> getPageHeader() {
        return pageHeader;
    }

    public void setPageHeader(List<T> pageHeader) {
        this.pageHeader = pageHeader;
    }

    public List<T> getPageData() {
        return pageData;
    }

    public void setPageData(List<T> pageData) {
        this.pageData = pageData;
    }

    public PageInfo getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(PageInfo pageInfo) {
        this.pageInfo = pageInfo;
    }

    public Map<String, Object> getQueryMap() {
        return queryMap;
    }

    public void setQueryMap(Map<String, Object> queryMap) {
        /*for (Map.Entry<String, Object> entry : queryMap.entrySet()) {
            if ("startTime".equals(entry.getKey()) || "endTime".equals(entry.getKey())) {
                if (entry.getValue()!=null) {
                    queryMap.put(entry.getKey(), TimeHelper.second2TimeStr(Integer.valueOf(entry.getValue().toString())));
                }
            }
        }*/
        this.queryMap = StringHelper.upQueryMap(queryMap);
    }
}