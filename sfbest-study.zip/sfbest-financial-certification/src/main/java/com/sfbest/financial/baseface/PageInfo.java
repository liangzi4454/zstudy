package com.sfbest.financial.baseface;

/**
 * 分页信息
 * Created by LHY on 2017/3/13.
 */
public class PageInfo {
    /** 开始页 **/
    private int firstPage;
    /** 上一页 **/
    private int previousPage;
    /** 下一页 **/
    private int nextPageNo;
    /** 最后页 **/
    private int lastPage;
    /** 总页数 **/
    private int totalPage;
    /** 查询记录数 **/
    private int totalRecords;
    /** 每页多少条数据 **/
    private int pageSize = 10;
    /** 第几页 **/
    private int pageNo = 1;
    /** 数据库查询使用: 开始行 **/
    private int startIndex;
    /** 数据库查询使用: 结束行**/
    private int endIndex;

    /**
     * 取得首页
     * @return
     */
    public int getFirstPage() {
        return 1;
    }

    /**
     * 上一页
     * @return
     */
    public int getPreviousPage() {
        if (pageNo <= 1) {
            return 1;
        }
        return pageNo - 1;
    }

    /**
     * 下一页
     * @return
     */
    public int getNextPage() {
        if (pageNo >= getLastPage()) {
            return getLastPage();
        }
        return pageNo + 1;
    }

    /**
     * 取得尾页
     * @return
     */
    public int getLastPage() {
        return getTotalPage();
    }

    /**
     * 总页数
     * @return
     */
    public int getTotalPage() {
        return (totalRecords + pageSize - 1) / pageSize;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getStartIndex() {
        return (getPageNo()-1)*getPageSize();
    }

    public int getEndIndex() {
        return getPageNo()*getPageSize();
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }

    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }
}