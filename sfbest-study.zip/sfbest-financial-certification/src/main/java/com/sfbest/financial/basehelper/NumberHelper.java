package com.sfbest.financial.basehelper;

import java.math.BigDecimal;

public class NumberHelper {
	/**
	 * 精确到小数点后两位
	 */
	public static double roundDouble(double value) {
		return value < 0 ? -Math.round(Math.abs(value) * 100 ) / 100.0 : Math.round(value* 100 ) / 100.0;
	}

    public static double roundNumber(Number n){
        if(n==null){
            return 0.0;
        }
        return roundDouble(n.doubleValue());
    }

    /**
     * 分转元,保留小数点后2位
     * @param value
     * @return
     */
    public static BigDecimal fen2yuan(int value) {
        return new BigDecimal(value/100d).setScale(2, BigDecimal.ROUND_HALF_UP);
    }
}
