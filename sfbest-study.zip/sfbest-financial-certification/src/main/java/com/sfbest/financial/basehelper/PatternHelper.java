package com.sfbest.financial.basehelper;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 日期模板
 * Created by LHY on 2017/3/10.
 */
public final class PatternHelper {
    /** 时间戳正则表达式 **/
    private static final String timestamp = "\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$";

    /**
     * 判断日期参数是否是:年月日 时分秒
     * @param timestamp
     * @return
     */
    public static boolean timestamp(String timestamp) {
        Pattern p = Pattern.compile(timestamp);
        Matcher m = p.matcher(timestamp);
        return m.matches();
    }
}