package com.sfbest.financial.basehelper;

import com.alibaba.fastjson.JSON;
import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * 字符串帮助类
 * Created by LHY on 2017/3/7.
 */
public class StringHelper {
    /**
     * 根据给定的长度生产一个随机的字符串: 字母+数字
     * @param length 随机数的长度
     * @return
     */
    public static String currentRandomString(int length) {
        if (length < 0) {
            return "0";
        }
        String number = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num"; // 输出字母还是数字
            if ("char".equals(charOrNum)) { // 字符串
                number += getCharacter();
            } else if ("num".equals(charOrNum)) { // 数字
                number += String.valueOf(random.nextInt(10));
            }
        }
        return number;
    }

    /**
     * 随机生成一个英文字母
     * @return
     */
    public static String getCharacter() {
        Random rand = new Random();
        final int A = 'A', Z = 'F';
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1; i++) {
            while (sb.length() < 1) {
                int number = rand.nextInt(Z + 1);
                if (number >= A) {
                    sb.append((char) number);
                }
            }
        }
        return sb.toString();
    }

    /**
     * 根据给定的长度生成一个随机数字
     * @param length 生产随机数的长度
     * @return
     */
    public static String currentRandomNumber(int length) {
        if (length < 0) {
            return "0";
        }
        String number = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            number += String.valueOf(random.nextInt(10));
        }
        return number;
    }

    /**
     * Json字符串转换为Map对象
     * @param json
     * @return
     */
    public static Map<String,Object> json2Map(String json) {
        return JSON.parseObject(json, Map.class);
    }

    /**
     * Object对象转换为Json字符串
     * @param obj
     * @return
     */
    public static String obj2String(Object obj){
        return JSON.toJSONString(obj);
    }

    /**
     * 临时处理查询的参数
     * @param map
     * @return
     * @throws Exception
     */
    public static Map<String, Object> upMap(Map<String, String[]> map) throws Exception {
        Map<String, Object> upMap = new HashMap<String, Object>();
        for (Map.Entry<String, String[]> entry : map.entrySet()) {
            if ("startTime".equals(entry.getKey()) || "endTime".equals(entry.getKey())) {
                if (StringUtils.isNotEmpty(entry.getValue()[0])) {
                    upMap.put(entry.getKey(), TimeHelper.currentTimeSecond(entry.getValue()[0]));
                }
            } else {
                upMap.put(entry.getKey(), entry.getValue()[0]);
            }
        }
        return upMap;
    }

    /**
     * 临时处理查询的返回的参数
     * @param queryMap
     * @return
     */
    public static Map<String, Object> upQueryMap(Map<String, Object> queryMap) {
        for (Map.Entry<String, Object> entry : queryMap.entrySet()) {
            if ("startTime".equals(entry.getKey()) || "endTime".equals(entry.getKey())) {
                if (entry.getValue()!=null) {
                    queryMap.put(entry.getKey(), TimeHelper.second2TimeStr(Integer.valueOf(entry.getValue().toString())));
                }
            }
        }
        return queryMap;
    }
}