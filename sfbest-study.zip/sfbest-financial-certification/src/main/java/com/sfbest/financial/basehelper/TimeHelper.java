package com.sfbest.financial.basehelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by LHY on 2017/3/1.
 */
public class TimeHelper {
    /**
     * 获取当前时间
     *
     * @return
     */
    public static String upDateTime() {
        return upDateTime(new Date(), "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * 减小时
     * @return
     */
    public static String minusDate(int hour) {
        Date d = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateMinusOneHours = df.format(new Date(d.getTime() - hour * (60 * 60 * 1000)));
        return dateMinusOneHours;
    }

    /**
     * 将指定日期增加执行参数
     * @param date
     * @param iAmount
     * @return
     */
    public static String upDateTimeAdd(Date date, int iAmount) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, iAmount);
        return upDateTime(cal.getTime(), "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * 返回当前时间增加指定的时间格式
     * @param sExp d结尾表示天数
     * @return
     */
    public static String upDateTimeAdd(String sExp) {
        String sEndType = sExp.substring(sExp.length() - 1);
        int iExp = Integer.valueOf(sExp.substring(0, sExp.length() - 1));
        String sExpString = "";
        if (sEndType.equals("d")) {
            sExpString = upDateTimeAdd(new Date(), iExp);
        } else {
            sExpString = upDateTime();
        }
        return sExpString;
    }
    /**
     * 时间格式化
     * @param dDate
     * @param sPattern
     * @return
     */
    public static String upDateTime(Date dDate, String sPattern) {
        SimpleDateFormat sFormat = new SimpleDateFormat(sPattern);
        return sFormat.format(dDate);
    }
    /**
     * 时间格式化
     * @param sPattern
     * @return
     */
    public static String upDateTime(String sPattern) {
        SimpleDateFormat sFormat = new SimpleDateFormat(sPattern);
        return sFormat.format(new Date());
    }
    /**
     * 获取16进制表示的当前时间
     * @return
     */
    public static String upDateHex() {
        return Integer.toHexString(Integer.valueOf(upDateTime("yyMMdd")));
    }

    /**
     *
     * @param sDateTime
     * @return
     * @throws ParseException
     */
    public static Date parseDate(String sDateTime) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.parse(sDateTime);
    }

    /**
     * 获得当前日期,精确到秒
     * @return
     */
    public static int currentTimeSecond() {
        return Long.valueOf(System.currentTimeMillis() / 1000L).intValue();
    }
    /**
     * 获得当前日期,精确到秒
     * @return
     */
    public static long currentTimeLong() {
        return System.currentTimeMillis() / 1000L;
    }

    /**
     * 根据传入时间参数转化为int类型
     * @param time
     * @return
     * @throws ParseException
     */
    public static int currentTimeSecond(String time) throws ParseException {
        return Long.valueOf(parseDate(time).getTime() / 1000L).intValue();
    }
    /**
     * 根据传入时间参数转化为long类型
     * @param time
     * @return
     * @throws ParseException
     */
    public static long currentTimeLong(String time) throws ParseException {
        return parseDate(time).getTime();
    }

    /**
     * int日期转字符串
     * @param second
     * @return
     */
    public static String second2TimeStr(int second) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date(second*1000L);
        return sdf.format(date);
    }
}