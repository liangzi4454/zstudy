package com.sfbest.financial.baseweb;

import org.apache.commons.lang.ClassUtils;
/**
 * 页面调用函数类 该类一向传递给页面调用
 * Created by LHY on 2017/3/17.
 */
public class RootMethod {
    public static RootMethod rootMethod = new RootMethod();
    /**
     * 普通java类反射实例化对象,不适用于枚举类型
     * @param sClassName
     * @return
     */
    public Object upClass(String sClassName) {
        Object oReturn = null;
        try {
            oReturn = ClassUtils.getClass(sClassName).newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return oReturn;
    }
}