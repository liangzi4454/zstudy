package com.sfbest.financial.certification.account;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertificationCharge;

/**
 * Created by LHY on 2017/6/7.
 */
public interface GfdAccountCertificationChargeService {
    String deleteByPrimaryKey(Integer id);

    String insertSelective(GfdAccountCertificationCharge record);

    GfdAccountCertificationCharge selectByPrimaryKey(Integer id);

    String updateByPrimaryKeySelective(GfdAccountCertificationCharge record);

    /**
     * 分页查询
     * @param pageInfo
     * @return
     */
    PageData<GfdAccountCertificationCharge> queryForList(PageInfo pageInfo);
}