package com.sfbest.financial.certification.account;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;

import java.util.List;
import java.util.Map;

/**
 * Created by LHY on 2017/3/23.
 */
public interface GfdAccountCertificationService {
    /**
     * 查询所有数据
     * @return
     */
    List<GfdAccountCertification> queryAll();

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    GfdAccountCertification queryByPrimaryKey(Integer id);
    /**
     * 分页查询
     * @param pageInfo
     * @return
     */
    PageData<GfdAccountCertification> queryForList(Map<String, Object> upMap, PageInfo pageInfo);
}