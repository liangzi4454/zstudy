package com.sfbest.financial.certification.account;

import com.sfbest.financial.db.entity.gfd.GfdAccountChargeItem;

import java.util.List;

/**
 * 费用类型模板处理类
 * Created by LHY on 2017/3/23.
 */
public interface GfdAccountChargeItemService {
    /**
     * 删除数据
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 插入数据
     * @param item
     * @return
     */
    int insertSelective(GfdAccountChargeItem item);

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    GfdAccountChargeItem selectByPrimaryKey(Integer id);

    /**
     * 更新数据
     * @param item
     * @return
     */
    int updateByPrimaryKeySelective(GfdAccountChargeItem item);

    /**
     * 查询所有数据
     * @return
     */
    List<GfdAccountChargeItem> queryAll();

    /**
     * 根据两个外键判断该费用类型是否已经被使用
     * @param id
     * @param mouldId
     * @param chargeId
     * @return
     */
    String queryCountExist(int id, int mouldId, List<Integer> chargeId);
}
