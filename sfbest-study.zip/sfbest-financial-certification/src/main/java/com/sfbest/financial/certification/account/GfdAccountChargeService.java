package com.sfbest.financial.certification.account;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdAccountCharge;

import java.util.List;

/**
 * Created by LHY on 2017/3/27.
 */
public interface GfdAccountChargeService {
    /**
     * 删除数据
     * @param id
     * @return
     */
    String deleteByPrimaryKey(Integer id);

    /**
     * 插入数据
     * @param item
     * @return
     */
    String insertSelective(GfdAccountCharge item);

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    GfdAccountCharge selectByPrimaryKey(Integer id);

    /**
     * 更新数据
     * @param item
     * @return
     */
    String updateByPrimaryKeySelective(GfdAccountCharge item);

    /**
     * 分页查询
     * @param pageInfo
     * @return
     */
    PageData<GfdAccountCharge> queryForList(PageInfo pageInfo);
    /**
     * 查询所有数据
     * @return
     */
    List<GfdAccountCharge> queryAll();
    /**
     * 凭证模板选择费用类型时调用
     * @param name
     * @return
     */
    List<GfdAccountCharge> queryAllByName(String name);
}