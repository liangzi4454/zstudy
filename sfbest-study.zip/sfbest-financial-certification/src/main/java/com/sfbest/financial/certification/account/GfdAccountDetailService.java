package com.sfbest.financial.certification.account;
import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;

import java.util.List;

/**
 * 总账分录信息
 * User: 01237177
 * Date: 2017/3/11
 * Time: 14:29
 */
public interface GfdAccountDetailService {
    /**
     * 通过凭证头的headerSn查询到与之关联的所有凭证体信息
     * @param headerSn
     * @return
     */
    List<GfdAccountDetail> queryAllByHeaderSn(String headerSn);
    /**
     * 插入数据
     * @param gfdAccountDetail
     * @return
     */
    int insertSelective(GfdAccountDetail gfdAccountDetail);
}
