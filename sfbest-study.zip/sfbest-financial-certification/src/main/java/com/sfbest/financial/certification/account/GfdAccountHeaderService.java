package com.sfbest.financial.certification.account;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;
import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import java.util.List;
import java.util.Map;

/**
 * 获取凭证信息
 */
public interface GfdAccountHeaderService {

    List<GfdAccountHeader> queryAll();

    int insertSelective(GfdAccountHeader record);

    /**
     * 判断bill_id相等的数量
     * @param billId
     * @return
     */
    int queryCountByBillId(String billId);

    /**
     * 分页查询
     * @param upMap 查询条件
     * @param pageInfo 分页信息
     * @return
     */
    PageData<GfdAccountHeader> queryForList(Map<String , Object> upMap, PageInfo pageInfo);

    /**
     * 根据headerSn查询唯一凭证信息
     * @param headerSn 凭证唯一编码
     * @return 凭证头信息
     */
    List<GfdAccountHeader> queryByHeaderSn(List<String> headerSn);

    /**
     * 根据凭证的创建时间查询出凭证头以及凭证体信息
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return
     */
    Map<GfdAccountHeader, List<GfdAccountDetail>> queryByCreateTime(long startTime, long endTime);
    /**
     * 批量更新凭证的处理状态
     * @param voucherIds 凭证编号集合
     * @param status 状态
     * @return
     * @throws Exception
     */
    int updateDealStatusByVoucherIds(List<String> voucherIds, int status);

    /**
     * 更新NC返回来的数据
     * @param voucherList
     * @return
     */
    int updateDealStatusBatch(List voucherList);
}
 