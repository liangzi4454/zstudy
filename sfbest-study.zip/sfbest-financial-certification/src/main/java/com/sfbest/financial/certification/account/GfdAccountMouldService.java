package com.sfbest.financial.certification.account;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdAccountMould;

import java.util.List;


public interface GfdAccountMouldService {
    /**
     * 删除数据
     * @param id
     * @return
     */
    String deleteByPrimaryKey(Integer id);

    /**
     * 插入数据
     * @param gfdAccountMould
     * @return
     */
    String insertSelective(GfdAccountMould gfdAccountMould);

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    GfdAccountMould selectByPrimaryKey(Integer id);

    /**
     * 更新单条数据
     * @param gfdAccountMould
     * @return
     */
    String updateByPrimaryKeySelective(GfdAccountMould gfdAccountMould);

    /**
     * 根据条件查询对应的数据列表
     * @param gfdAccountMould
     * @return
     */
    List<GfdAccountMould> selectBySelective(GfdAccountMould gfdAccountMould);
    /**
     * 分页查询
     * @param pageInfo
     * @return
     */
    PageData<GfdAccountMould> queryForList(PageInfo pageInfo);
}