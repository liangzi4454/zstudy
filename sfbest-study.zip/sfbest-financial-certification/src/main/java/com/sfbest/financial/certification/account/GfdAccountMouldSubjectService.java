package com.sfbest.financial.certification.account;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdAccountMouldSubject;

import java.util.List;

/**
 * Created by LHY on 2017/3/22.
 */
public interface GfdAccountMouldSubjectService {
    /**
     * 删除数据
     * @param id 主键
     * @return
     */
    String deleteByPrimaryKey(Integer id);
    /**
     * <pre>
     * 每次插入借贷新数据的时候都要判断当前是否已经超过了借贷数量
     * 返回结果: 0借的数量超过规定数量,1贷的数量超过规定数量,2创建的非借贷数据,3创建成功,-1创建失败
     * </pre>
     * @param subject 数据
     * @return
     */
    String insertSelective(GfdAccountMouldSubject subject);
    /**
     * 根据主键查询单挑数据
     * @param id
     * @return
     */
    GfdAccountMouldSubject selectByPrimaryKey(Integer id);
    /**
     * 更新数据
     * @param subject
     * @return
     */
    String updateByPrimaryKeySelective(GfdAccountMouldSubject subject);
    /**
     * 根据凭证分录表的主键查询信息
     * @param mouldId
     * @return
     */
    List<GfdAccountMouldSubject> queryAll(Integer mouldId);
    /**
     * 分页查询
     * @param mouldId
     * @param pageInfo
     * @return
     */
    PageData<GfdAccountMouldSubject> queryForList(int mouldId, PageInfo pageInfo);
}
