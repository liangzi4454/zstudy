package com.sfbest.financial.certification.account;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdAccountSubject;

import java.util.List;


public interface GfdAccountSubjectService {

    String deleteByPrimaryKey(Integer id);

    String insertSelective(GfdAccountSubject gfdAccountEntry);

    GfdAccountSubject selectByPrimaryKey(Integer id);

    String updateByPrimaryKeySelective(GfdAccountSubject gfdAccountSubject);

    List<GfdAccountSubject> queryAll();

    /**
     * 分页查询
     * @param pageInfo 分页信息
     * @return
     */
    PageData<GfdAccountSubject> queryForList(PageInfo pageInfo);
}