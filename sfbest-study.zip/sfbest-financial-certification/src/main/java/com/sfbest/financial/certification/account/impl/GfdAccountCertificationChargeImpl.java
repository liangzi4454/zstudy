package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.account.GfdAccountCertificationChargeService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertificationCharge;
import com.sfbest.financial.db.mapper.gfd.GfdAccountCertificationChargeMapper;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 *
 * Created by LHY on 2017/6/7.
 */
@Component
public class GfdAccountCertificationChargeImpl extends BaseClass implements GfdAccountCertificationChargeService {

    @Resource
    private GfdAccountCertificationChargeMapper gfdAccountCertificationChargeMapper;

    public String deleteByPrimaryKey(Integer id) {
        GfdAccountCertificationCharge object = gfdAccountCertificationChargeMapper.selectByPrimaryKey(id);
        if(object==null) {
            return logInfo(9220008);
        }
        gfdAccountCertificationChargeMapper.deleteByPrimaryKey(id);
        return logInfo(9210004);
    }

    public String insertSelective(GfdAccountCertificationCharge record) {
        int count = gfdAccountCertificationChargeMapper.queryCountByName(record.getClassName(), 0);
        if(count>0) {
            return logInfo(9210001);
        }
        record.setCreateTime(TimeHelper.currentTimeSecond());
        gfdAccountCertificationChargeMapper.insertSelective(record);
        return logInfo(9210002);
    }

    public GfdAccountCertificationCharge selectByPrimaryKey(Integer id) {
        return gfdAccountCertificationChargeMapper.selectByPrimaryKey(id);
    }

    public String updateByPrimaryKeySelective(GfdAccountCertificationCharge record) {
        int count = gfdAccountCertificationChargeMapper.queryCountByName(record.getClassName(), record.getId());
        if(count>0) {
            return logInfo(9210001);
        }
        gfdAccountCertificationChargeMapper.updateByPrimaryKeySelective(record);
        return logInfo(9210003);
    }

    public PageData<GfdAccountCertificationCharge> queryForList(PageInfo pageInfo) {
        int totalRecords = gfdAccountCertificationChargeMapper.queryForListCount();
        List<GfdAccountCertificationCharge> list = gfdAccountCertificationChargeMapper.queryForList(pageInfo.getStartIndex(), pageInfo.getEndIndex());
        PageData<GfdAccountCertificationCharge> pageData = new PageData<GfdAccountCertificationCharge>();
        pageData.setPageData(list);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        return pageData;
    }
}