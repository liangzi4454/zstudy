package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.account.GfdAccountCertificationService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;
import com.sfbest.financial.db.mapper.gfd.GfdAccountCertificationMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Created by LHY on 2017/3/23.
 */
@Service
public class GfdAccountCertificationServiceImpl implements GfdAccountCertificationService {
    @Resource
    private GfdAccountCertificationMapper gfdAccountCertificationMapper;
    /**
     * 查询所有数据
     * @return
     */
    public List<GfdAccountCertification> queryAll() {
        return gfdAccountCertificationMapper.queryAll();
    }

    public GfdAccountCertification queryByPrimaryKey(Integer id) {
        return gfdAccountCertificationMapper.queryByPrimaryKey(id);
    }
    /**
     * 分页查询
     * @param pageInfo
     * @return
     */
    public PageData<GfdAccountCertification> queryForList(Map<String, Object> upMap, PageInfo pageInfo) {
        upMap.put("startIndex", pageInfo.getStartIndex());
        upMap.put("endIndex", pageInfo.getEndIndex());
        int totalRecords = gfdAccountCertificationMapper.queryForListCount(upMap);
        List<GfdAccountCertification> list = gfdAccountCertificationMapper.queryForList(upMap);
        PageData<GfdAccountCertification> pageData = new PageData<GfdAccountCertification>();
        pageData.setPageData(list);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        pageData.setQueryMap(upMap);
        return pageData;
    }
}