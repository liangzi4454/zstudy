package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.certification.account.GfdAccountChargeItemService;
import com.sfbest.financial.db.entity.gfd.GfdAccountChargeItem;
import com.sfbest.financial.db.mapper.gfd.GfdAccountChargeItemMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by LHY on 2017/3/23.
 */
@Service
public class GfdAccountChargeItemServiceImpl extends BaseClass implements GfdAccountChargeItemService {
    @Resource
    private GfdAccountChargeItemMapper gfdAccountChargeItemMapper;

    public int deleteByPrimaryKey(Integer id) {
        return gfdAccountChargeItemMapper.deleteByPrimaryKey(id);
    }

    public int insertSelective(GfdAccountChargeItem item) {
        return gfdAccountChargeItemMapper.insertSelective(item);
    }

    public GfdAccountChargeItem selectByPrimaryKey(Integer id) {
        return gfdAccountChargeItemMapper.selectByPrimaryKey(id);
    }

    public int updateByPrimaryKeySelective(GfdAccountChargeItem item) {
        return gfdAccountChargeItemMapper.updateByPrimaryKeySelective(item);
    }

    public List<GfdAccountChargeItem> queryAll() {
        return gfdAccountChargeItemMapper.queryAll();
    }
    /**
     * 根据两个外键判断该费用类型是否已经被使用
     * @param id
     * @param mouldId
     * @param chargeId
     * @return
     */
    public String queryCountExist(int id, int mouldId, List<Integer> chargeId) {
        int count = gfdAccountChargeItemMapper.queryCountExist(id, mouldId, chargeId);
        if(count>0) {
            return logInfo(9220007);
        }
        return "";
    }
}