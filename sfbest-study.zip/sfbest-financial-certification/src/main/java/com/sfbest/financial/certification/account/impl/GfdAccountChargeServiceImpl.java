package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.account.GfdAccountChargeService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCharge;
import com.sfbest.financial.db.mapper.gfd.GfdAccountChargeItemMapper;
import com.sfbest.financial.db.mapper.gfd.GfdAccountChargeMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by LHY on 2017/3/27.
 */
@Service
public class GfdAccountChargeServiceImpl extends BaseClass implements GfdAccountChargeService {
    @Resource
    private GfdAccountChargeMapper gfdAccountChargeMapper;
    @Resource
    private GfdAccountChargeItemMapper gfdAccountChargeItemMapper;
    /**
     * 删除数据
     * @param id
     * @return
     */
    public String deleteByPrimaryKey(Integer id) {
        int count = gfdAccountChargeItemMapper.queryChargeIdCount(id);
        if(count>0) {
            return logInfo(9210008);
        }
        gfdAccountChargeMapper.deleteByPrimaryKey(id);
        return logInfo(9210004);
    }

    /**
     * 插入数据
     * @param charge
     * @return 0 有重复数据,1 成功
     */
    public String insertSelective(GfdAccountCharge charge) {
        charge.setId(0);
        charge.setCreateTime(TimeHelper.currentTimeSecond());
        int count = gfdAccountChargeMapper.queryCount(charge);
        if(count>0) {
            return logInfo(9210001);
        }
        gfdAccountChargeMapper.insertSelective(charge);
        return logInfo(9210002);
    }

    /**
     * 查询单条数据
     * @param id
     * @return
     */
    public GfdAccountCharge selectByPrimaryKey(Integer id) {
        return gfdAccountChargeMapper.selectByPrimaryKey(id);
    }

    /**
     * 更新数据
     * @param charge
     * @return 0 有重复数据,1 成功
     */
    public String updateByPrimaryKeySelective(GfdAccountCharge charge) {
        int count = gfdAccountChargeMapper.queryCount(charge);
        if(count>0) {
            return logInfo(9210001);
        }
        gfdAccountChargeMapper.updateByPrimaryKeySelective(charge);
        return logInfo(9210003);
    }
    /**
     * 分页查询
     * @param pageInfo
     * @return
     */
    public PageData<GfdAccountCharge> queryForList(PageInfo pageInfo) {
        int totalRecords = gfdAccountChargeMapper.queryForListCount();
        List<GfdAccountCharge> list = gfdAccountChargeMapper.queryForList(pageInfo.getStartIndex(), pageInfo.getEndIndex());
        PageData<GfdAccountCharge> pageData = new PageData<GfdAccountCharge>();
        pageData.setPageData(list);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        return pageData;
    }
    /**
     * 查询所有数据
     * @return
     */
    public List<GfdAccountCharge> queryAll() {
        return gfdAccountChargeMapper.queryAll();
    }
    /**
     * 凭证模板选择费用类型时调用
     * @param name
     * @return
     */
    public List<GfdAccountCharge> queryAllByName(String name) {
        return gfdAccountChargeMapper.queryAllByName(name);
    }
}