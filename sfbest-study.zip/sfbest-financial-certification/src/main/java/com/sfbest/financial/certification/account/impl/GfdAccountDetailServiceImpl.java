package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.certification.account.GfdAccountDetailService;
import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;
import com.sfbest.financial.db.mapper.gfd.GfdAccountDetailMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 凭证信息
 */
@Service
public class GfdAccountDetailServiceImpl implements GfdAccountDetailService {
    @Resource
    private GfdAccountDetailMapper gfdAccountDetailMapper;

    /**
     * 通过凭证头的headerSn查询到与之关联的所有凭证体信息
     * 根据headerSn查询一组凭证体信息
     * @param headerSn 凭证唯一编码
     * @return 一组凭证体信息
     */
    public List<GfdAccountDetail> queryAllByHeaderSn(String headerSn) {
        return gfdAccountDetailMapper.queryAllByHeaderSn(headerSn);
    }
    /**
     * 插入数据
     * @param gfdAccountDetail
     * @return
     */
    public int insertSelective(GfdAccountDetail gfdAccountDetail) {
        return gfdAccountDetailMapper.insertSelective(gfdAccountDetail);
    }
}