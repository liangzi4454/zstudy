package com.sfbest.financial.certification.account.impl;

import com.alibaba.fastjson.JSON;
import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.account.GfdAccountHeaderService;
import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;
import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import com.sfbest.financial.db.mapper.gfd.GfdAccountDetailMapper;
import com.sfbest.financial.db.mapper.gfd.GfdAccountHeaderMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 总账基本信息
 * User: 01237177
 * Date: 2017/3/11
 * Time: 16:30
 */
@SuppressWarnings("all")
@Service
public class GfdAccountHeaderServiceImpl implements GfdAccountHeaderService {

    @Resource
    private GfdAccountHeaderMapper gfdAccountHeaderMapper;
    @Resource
    private GfdAccountDetailMapper gfdAccountDetailMapper;

    /**
     * 插入查询所有
     * @return
     */
    public List<GfdAccountHeader> queryAll() {
       return gfdAccountHeaderMapper.queryAll();
    }

    /**
     * 插入操作
     * @param gfdAccountHeader
     * @return
     */
    public int insertSelective(GfdAccountHeader gfdAccountHeader){
        return gfdAccountHeaderMapper.insertSelective(gfdAccountHeader);
    }

    public int queryCountByBillId(String billId) {
        return gfdAccountHeaderMapper.queryCountByBillId(billId);
    }

    /**
     * 分页查询
     * @param upMap 查询条件
     * @param pageInfo 分页信息
     * @return
     */
    public PageData<GfdAccountHeader> queryForList(Map<String , Object> upMap, PageInfo pageInfo) {
        upMap.put("startIndex", pageInfo.getStartIndex());
        upMap.put("endIndex", pageInfo.getEndIndex());
        int totalRecords = gfdAccountHeaderMapper.queryForListCount(upMap);
        List<GfdAccountHeader> list = gfdAccountHeaderMapper.queryForList(upMap);
        PageData<GfdAccountHeader> pageData = new PageData<GfdAccountHeader>();
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        pageData.setPageData(list);
        pageData.setQueryMap(upMap);
        return pageData;
    }
    /**
     * 根据headerSn查询唯一凭证信息
     * @param headerSn 凭证唯一编码
     * @return 凭证头信息
     */
    public  List<GfdAccountHeader> queryByHeaderSn(List<String> headerSn) {
        return gfdAccountHeaderMapper.queryByHeaderSn(headerSn);
    }
    /**
     * 根据凭证的创建时间查询出凭证头以及凭证体信息
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return
     */
    public Map<GfdAccountHeader, List<GfdAccountDetail>> queryByCreateTime(long startTime, long endTime) {
        Map<GfdAccountHeader, List<GfdAccountDetail>> map = new HashMap<GfdAccountHeader, List<GfdAccountDetail>>();
        List<GfdAccountHeader> list = gfdAccountHeaderMapper.queryByCreateTime(startTime, endTime);
        for(GfdAccountHeader header: list) {
            List<GfdAccountDetail> detail = gfdAccountDetailMapper.queryAllByHeaderSn(header.getHeaderSn());
            map.put(header, detail);
        }
        return map;
    }
    /**
     * 批量更新凭证的处理状态
     * @param voucherIds 凭证编号集合
     * @param status 状态
     * @return
     * @throws Exception
     */
    public int updateDealStatusByVoucherIds(List<String> voucherIds, int status) {
        return gfdAccountHeaderMapper.updateDealStatusByVoucherIds(voucherIds, status);
    }

    public int updateDealStatusBatch(List voucherList) {
        return gfdAccountHeaderMapper.updateDealStatusBatch(voucherList);
    }
}