package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.certification.account.GfdAccountMouldService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCharge;
import com.sfbest.financial.db.entity.gfd.GfdAccountChargeItem;
import com.sfbest.financial.db.entity.gfd.GfdAccountMould;
import com.sfbest.financial.db.mapper.gfd.GfdAccountChargeItemMapper;
import com.sfbest.financial.db.mapper.gfd.GfdAccountChargeMapper;
import com.sfbest.financial.db.mapper.gfd.GfdAccountMouldMapper;
import com.sfbest.financial.db.mapper.gfd.GfdAccountMouldSubjectMapper;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * 模板业务类
 * Created by LHY on 2017/3/23.
 */
@Service
public class GfdAccountMouldServiceImpl extends BaseClass implements GfdAccountMouldService {

    @Resource
    private GfdAccountMouldMapper gfdAccountMouldMapper;
    @Resource
    private GfdAccountMouldSubjectMapper gfdAccountMouldSubjectMapper;
    @Resource
    private GfdAccountChargeItemMapper gfdAccountChargeItemMapper;
    @Resource
    private GfdAccountChargeMapper gfdAccountChargeMapper;

    /**
     * 分页查询
     * @param pageInfo
     * @return
     */
    public PageData<GfdAccountMould> queryForList(PageInfo pageInfo) {
        int totalRecords = gfdAccountMouldMapper.queryForListCount();
        List<GfdAccountMould> list = gfdAccountMouldMapper.queryForList(pageInfo.getStartIndex(), pageInfo.getEndIndex());
        for(GfdAccountMould mould: list) {
            List<GfdAccountChargeItem> chargeItems = gfdAccountChargeItemMapper.queryAllByMouldId(mould.getId());
            if(!CollectionUtils.isEmpty(chargeItems)) {
                for(GfdAccountChargeItem item: chargeItems) {
                    item.setChargeItemCode(gfdAccountChargeMapper.queryChargeItemCodeById(item.getChargeId()));
                }
                mould.setChargeItems(chargeItems);
            }
        }
        PageData<GfdAccountMould> pageData = new PageData<GfdAccountMould>();
        pageData.setPageData(list);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        return pageData;
    }

    public List<GfdAccountMould> selectBySelective(GfdAccountMould gfdAccountMould) {
        List<GfdAccountMould> list = gfdAccountMouldMapper.selectBySelective(gfdAccountMould);
        for(GfdAccountMould mould: list) {
            List<GfdAccountChargeItem> chargeItems = gfdAccountChargeItemMapper.queryAllByMouldId(mould.getId());
            if(!CollectionUtils.isEmpty(chargeItems)) {
                for(GfdAccountChargeItem item: chargeItems) {
                    item.setChargeItemCode(gfdAccountChargeMapper.queryChargeItemCodeById(item.getChargeId()));
                }
                mould.setChargeItems(chargeItems);
            }
        }
        return list;
    }

    /**
     * 删除模板头信息
     * @param id
     * @return 0 请先删除模板体信息 1 成功
     */
    public String deleteByPrimaryKey(Integer id) {
        int count = gfdAccountMouldSubjectMapper.queryCount(id);
        if(count>0) {
            return logInfo(9220008);
        }
        //删除原来的关联关系
        List<GfdAccountChargeItem> chargeItemCodes = gfdAccountChargeItemMapper.queryAllByMouldId(id);
        for(GfdAccountChargeItem item: chargeItemCodes) {
            gfdAccountChargeItemMapper.deleteByPrimaryKey(item.getId());
        }
        gfdAccountMouldMapper.deleteByPrimaryKey(id);
        return logInfo(9210004);
    }

    /**
     * 保存模板头信息的时候和费用类型一起关联保存
     * @param gfdAccountMould
     * @return
     */
    public String insertSelective(GfdAccountMould gfdAccountMould) {
        //判断名称是否重名
        int count = gfdAccountMouldMapper.queryCountByName(gfdAccountMould.getMouldName(), 0);
        if(count>0) {
            return logInfo(9210001);
        }
        //判断费用类型是否存在
        String chargeIds = gfdAccountMould.getChargeIds();
        if(StringUtils.isEmpty(chargeIds)) {
            return logInfo(9220001);
        }
        String[] chargeId = chargeIds.split(",");
        for(String id: chargeId) {
            GfdAccountCharge charge = gfdAccountChargeMapper.selectByPrimaryKey(Integer.valueOf(id));
            if (charge == null) {
                return logInfo(9220001);
            }
        }
        //建立关联关系保存数据
        gfdAccountMould.setCreateTime(TimeHelper.currentTimeSecond());
        gfdAccountMouldMapper.insertSelective(gfdAccountMould);
        for(String id: chargeId) {
            GfdAccountChargeItem item = new GfdAccountChargeItem();
            item.setChargeId(Integer.valueOf(id));
            item.setMouldId(gfdAccountMould.getId());
            item.setCreateTime(TimeHelper.currentTimeSecond());
            gfdAccountChargeItemMapper.insertSelective(item);
        }
        return logInfo(9210002);
    }

    public GfdAccountMould selectByPrimaryKey(Integer id) {
        String chargeId = "";
        List<GfdAccountChargeItem> chargeItemCodes = gfdAccountChargeItemMapper.queryAllByMouldId(id);
        for(GfdAccountChargeItem item: chargeItemCodes) {
            chargeId += item.getChargeId()+",";
        }
        GfdAccountMould gfdAccountMould = gfdAccountMouldMapper.selectByPrimaryKey(id);
        if(StringUtils.isNotEmpty(chargeId)) {
            chargeId = chargeId.substring(0, chargeId.lastIndexOf(","));
            gfdAccountMould.setChargeIds(chargeId);
        }
        gfdAccountMould.setChargeItems(chargeItemCodes);
        return gfdAccountMould;
    }

    /**
     * 更新模板的时候先将关联关系删除，然后重新创建该关联关系
     * @param gfdAccountMould
     * @return
     */
    public String updateByPrimaryKeySelective(GfdAccountMould gfdAccountMould) {
        //判断名称是否重名
        int count = gfdAccountMouldMapper.queryCountByName(gfdAccountMould.getMouldName(), gfdAccountMould.getId());
        if(count>0) {
            return logInfo(9210001);
        }
        String chargeIds = gfdAccountMould.getChargeIds();
        if(StringUtils.isEmpty(chargeIds)) {
            return logInfo(9220001);
        }
        String[] chargeId = chargeIds.split(",");
        for(String id: chargeId) {
            GfdAccountCharge charge = gfdAccountChargeMapper.selectByPrimaryKey(Integer.valueOf(id));
            if (charge == null) {
                return logInfo(9220001);
            }
        }
        //删除原来的关联关系
        List<GfdAccountChargeItem> chargeItemCodes = gfdAccountChargeItemMapper.queryAllByMouldId(gfdAccountMould.getId());
        for(GfdAccountChargeItem item: chargeItemCodes) {
            gfdAccountChargeItemMapper.deleteByPrimaryKey(item.getId());
        }
        //重新建立关联关系保存数据
        gfdAccountMouldMapper.updateByPrimaryKeySelective(gfdAccountMould);
        for(String id: chargeId) {
            GfdAccountChargeItem item = new GfdAccountChargeItem();
            item.setChargeId(Integer.valueOf(id));
            item.setMouldId(gfdAccountMould.getId());
            item.setCreateTime(TimeHelper.currentTimeSecond());
            gfdAccountChargeItemMapper.insertSelective(item);
        }
        return logInfo(9210003);
    }
}