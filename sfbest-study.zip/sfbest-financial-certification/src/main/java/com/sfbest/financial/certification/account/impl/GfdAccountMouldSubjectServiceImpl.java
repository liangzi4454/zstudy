package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.certification.account.GfdAccountMouldSubjectService;
import com.sfbest.financial.db.entity.gfd.GfdAccountMouldSubject;
import com.sfbest.financial.db.mapper.gfd.GfdAccountMouldMapper;
import com.sfbest.financial.db.mapper.gfd.GfdAccountMouldSubjectMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by LHY on 2017/3/23.
 */
@Service
public class GfdAccountMouldSubjectServiceImpl extends BaseClass implements GfdAccountMouldSubjectService {
    @Resource
    private GfdAccountMouldSubjectMapper gfdAccountMouldSubjectMapper;
    @Resource
    private GfdAccountMouldMapper gfdAccountMouldMapper;

    public String deleteByPrimaryKey(Integer id) {
        gfdAccountMouldSubjectMapper.deleteByPrimaryKey(id);
        return logInfo(9210004);
    }
    /**
     * <pre>
     * 每次插入借贷新数据的时候都要判断当前是否已经超过了借贷数量
     * 返回结果: 1借的数量超过规定数量,2贷的数量超过规定数量,3创建的非借贷数据,4创建成功,-1创建失败
     * </pre>
     * @param subject 数据
     * @return
     */
    public String insertSelective(GfdAccountMouldSubject subject) {
        int count = gfdAccountMouldSubjectMapper.queryCountBySubjectCode(subject.getSubjectCode(), 0, subject.getMouldId());
        if(count>0) {
            return logInfo(9220003);
        }
        int entryId = subject.getMouldId();
        int debitCredit = subject.getDebitCredit();
        if(debitCredit==0) {
            int debitNumber = gfdAccountMouldSubjectMapper.queryDebitCreditNumber(entryId, subject.getDebitCredit(), 0);
            int number = gfdAccountMouldMapper.queryDebitNumber(entryId);
            if(debitNumber>=number) {
                return logInfo(9220004);
            }
        } else if(debitCredit==1) {
            int creditNumber = gfdAccountMouldSubjectMapper.queryDebitCreditNumber(entryId, subject.getDebitCredit(), 0);
            int number = gfdAccountMouldMapper.queryCreditNumber(entryId);
            if(creditNumber>=number) {
                return logInfo(9220005);
            }
        } else {
            return logInfo(9220006);
        }
        subject.setCreateTime(TimeHelper.currentTimeSecond());
        int result = gfdAccountMouldSubjectMapper.insertSelective(subject);
        return result==1?logInfo(9210002):logInfo(9210006);
    }

    public GfdAccountMouldSubject selectByPrimaryKey(Integer id) {
        return gfdAccountMouldSubjectMapper.selectByPrimaryKey(id);
    }

    public String updateByPrimaryKeySelective(GfdAccountMouldSubject subject) {
        int count = gfdAccountMouldSubjectMapper.queryCountBySubjectCode(subject.getSubjectCode(), subject.getId(), subject.getMouldId());
        if(count>0) {
            return logInfo(9220003);
        }
        int entryId = subject.getMouldId();
        int debitCredit = subject.getDebitCredit();
        if(debitCredit==0) {
            int debitNumber = gfdAccountMouldSubjectMapper.queryDebitCreditNumber(entryId, subject.getDebitCredit(), subject.getId());
            int number = gfdAccountMouldMapper.queryDebitNumber(entryId);
            if(debitNumber>=number) {
                return logInfo(9220004);
            }
        } else if(debitCredit==1) {
            int creditNumber = gfdAccountMouldSubjectMapper.queryDebitCreditNumber(entryId, subject.getDebitCredit(), subject.getId());
            int number = gfdAccountMouldMapper.queryCreditNumber(entryId);
            if(creditNumber>=number) {
                return logInfo(9220005);
            }
        } else {
            return logInfo(9220006);
        }
        int result = gfdAccountMouldSubjectMapper.updateByPrimaryKeySelective(subject);
        return result==1?logInfo(9210003):logInfo(9210006);
    }

    public List<GfdAccountMouldSubject> queryAll(Integer mouldId) {
        return gfdAccountMouldSubjectMapper.queryAll(mouldId);
    }
    /**
     * 分页查询
     * @param mouldId
     * @param pageInfo
     * @return
     */
    public PageData<GfdAccountMouldSubject> queryForList(int mouldId, PageInfo pageInfo) {
        int totalRecords = gfdAccountMouldSubjectMapper.queryForListCount(mouldId);
        List<GfdAccountMouldSubject> list = gfdAccountMouldSubjectMapper.queryForList(mouldId, pageInfo.getStartIndex(), pageInfo.getEndIndex());
        PageData<GfdAccountMouldSubject> pageData = new PageData<GfdAccountMouldSubject>();
        pageData.setPageData(list);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        return pageData;
    }
}