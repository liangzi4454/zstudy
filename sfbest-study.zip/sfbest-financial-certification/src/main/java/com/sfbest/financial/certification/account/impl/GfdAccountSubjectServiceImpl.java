package com.sfbest.financial.certification.account.impl;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.account.GfdAccountSubjectService;
import com.sfbest.financial.db.entity.gfd.GfdAccountSubject;
import com.sfbest.financial.db.mapper.gfd.GfdAccountSubjectMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class GfdAccountSubjectServiceImpl extends BaseClass implements GfdAccountSubjectService {

    @Resource
    private GfdAccountSubjectMapper gfdAccountSubjectMapper;

    public String deleteByPrimaryKey(Integer id){
        gfdAccountSubjectMapper.deleteByPrimaryKey(id);
        return logInfo(9210004);
    }

    /**
     * 根据entrySubjectCode判断当前表中是否有重复的数据,若有重复数据则返回0
     * @param gfdAccountSubject
     * @return
     */
    public String insertSelective(GfdAccountSubject gfdAccountSubject){
        int count = gfdAccountSubjectMapper.queryCountBySubjectCode(gfdAccountSubject.getSubjectCode(), 0);
        if(count>0) {
            return logInfo(9210001);
        }
        gfdAccountSubject.setCreateTime(TimeHelper.currentTimeSecond());
        gfdAccountSubjectMapper.insertSelective(gfdAccountSubject);
        return logInfo(9210002);
    }

    public GfdAccountSubject selectByPrimaryKey(Integer id){
        return gfdAccountSubjectMapper.selectByPrimaryKey(id);
    }

    public String updateByPrimaryKeySelective(GfdAccountSubject gfdAccountSubject) {
        int count = gfdAccountSubjectMapper.queryCountBySubjectCode(gfdAccountSubject.getSubjectCode(), gfdAccountSubject.getId());
        if(count>0) {
            return logInfo(9210001);
        }
        gfdAccountSubjectMapper.updateByPrimaryKeySelective(gfdAccountSubject);
        return logInfo(9210003);
    }

    public List<GfdAccountSubject> queryAll() {
        return gfdAccountSubjectMapper.queryAll();
    }
    /**
     * 分页查询
     * @param pageInfo 分页信息
     * @return
     */
    public PageData<GfdAccountSubject> queryForList(PageInfo pageInfo) {
        int totalRecords = gfdAccountSubjectMapper.queryForListCount();
        List<GfdAccountSubject> data = gfdAccountSubjectMapper.queryForList(pageInfo.getStartIndex(), pageInfo.getEndIndex());
        PageData<GfdAccountSubject> pageData = new PageData<GfdAccountSubject>();
        pageData.setPageData(data);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        return pageData;
    }
}