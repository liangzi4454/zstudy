package com.sfbest.financial.certification.email;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdZadminEmail;

import java.util.List;

/**
 * Created by LHY on 2017/4/24.
 */
public interface GfdZadminEmailService {
    /**
     * 删除数据
     * @param id
     * @return
     */
    String deleteByPrimaryKey(Integer id);
    /**
     * 插入数据
     * @param record
     * @return
     */
    String insertSelective(GfdZadminEmail record);
    /**
     * 查询数据
     * @param id
     * @return
     */
    GfdZadminEmail selectByPrimaryKey(Integer id);
    /**
     * 更新数据
     * @param record
     * @return
     */
    String updateByPrimaryKeySelective(GfdZadminEmail record);
    /**
     * 分页查询数据
     * @param pageInfo 分页信息
     * @return
     */
    PageData<GfdZadminEmail> queryForList(PageInfo pageInfo);
    /**
     * 根据code查询邮件地址
     * @param code
     * @return
     */
    List<String> queryEmailByCode(String code);
}
