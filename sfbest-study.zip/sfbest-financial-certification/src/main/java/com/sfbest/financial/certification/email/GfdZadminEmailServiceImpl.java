package com.sfbest.financial.certification.email;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.db.entity.gfd.GfdZadminEmail;
import com.sfbest.financial.db.mapper.gfd.GfdZadminEmailMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 邮件系统管理
 * Created by LHY on 2017/4/24.
 */
@Service
public class GfdZadminEmailServiceImpl extends BaseClass implements GfdZadminEmailService{
    @Resource
    private GfdZadminEmailMapper gfdZadminEmailMapper;

    public String deleteByPrimaryKey(Integer id) {
        gfdZadminEmailMapper.deleteByPrimaryKey(id);
        return logInfo(9210004);
    }

    public String insertSelective(GfdZadminEmail record) {
        record.setCreateTime(TimeHelper.currentTimeSecond());
        gfdZadminEmailMapper.insertSelective(record);
        return logInfo(9210002);
    }

    public GfdZadminEmail selectByPrimaryKey(Integer id) {
        return gfdZadminEmailMapper.selectByPrimaryKey(id);
    }

    public String updateByPrimaryKeySelective(GfdZadminEmail record) {
        gfdZadminEmailMapper.updateByPrimaryKeySelective(record);
        return logInfo(9210003);
    }
    /**
     * 分页查询数据
     * @param pageInfo 分页信息
     * @return
     */
    public PageData<GfdZadminEmail> queryForList(PageInfo pageInfo) {
        int totalRecords = gfdZadminEmailMapper.queryForListCount();
        List<GfdZadminEmail> data = gfdZadminEmailMapper.queryForList(pageInfo.getStartIndex(), pageInfo.getEndIndex());
        PageData<GfdZadminEmail> pageData = new PageData<GfdZadminEmail>();
        pageData.setPageData(data);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        return pageData;
    }
    /**
     * 根据code查询邮件地址
     * @param code
     * @return
     */
    public List<String> queryEmailByCode(String code) {
        return gfdZadminEmailMapper.queryEmailByCode(code);
    }
}