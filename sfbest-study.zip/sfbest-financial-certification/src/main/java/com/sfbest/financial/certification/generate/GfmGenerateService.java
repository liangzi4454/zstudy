package com.sfbest.financial.certification.generate;

/**
 *
 * Created by LHY on 2017/3/10.
 */
public interface GfmGenerateService {
    /**
     * 根据传入的code值生成当天有次序的编码;
     * 例如: 今天的日期是20170307,传入的code=FMS,返回值为FMS20170307100001,顺序递增;
     * @param code 业务代码,
     * @return 时间戳
     */
    String getCode(String code);

    /**
     * 根据传入的code值生成当天有次序的编码;并以传入的参数座位前缀
     * @param code 业务代码,
     * @return code + 时间戳
     */
    String getCodeWithPrefix(String code);
}
