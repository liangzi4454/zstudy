package com.sfbest.financial.certification.generate.impl;

import com.sfbest.financial.certification.generate.GfmGenerateService;
import com.sfbest.financial.db.mapper.gfm.GfmGenerateMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by LHY on 2017/3/10.
 */
@Service
public class GfmGenerateServiceImpl implements GfmGenerateService {
    @Resource
    private GfmGenerateMapper gfmGenerateMapper;
    @Override
    public String getCode(String code) {
        return gfmGenerateMapper.getCode(code);
    }

    @Override
    public String getCodeWithPrefix(String code) {
        return code+getCode(code);
    }
}
