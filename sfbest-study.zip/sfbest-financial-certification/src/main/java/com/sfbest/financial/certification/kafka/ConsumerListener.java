package com.sfbest.financial.certification.kafka;

import com.sfbest.financial.basecom.baselistener.InitializingListener;
import com.sfbest.financial.util.kafka.IKafkaMessage;
import com.sfbest.financial.baseweb.RootMethod;
import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;
import com.sfbest.financial.util.kafka.KafkaConsumerGroup;

import javax.annotation.Resource;
import java.util.List;

/**
 * 启动kafka监听器,监听消费者
 * Created by LHY on 2017/5/16.
 */
public class ConsumerListener implements InitializingListener {
    @Resource
    private KafkaService kafkaService;

    public void destroy() throws Exception {

    }

    public void initial() throws Exception {
        List<GfdZadminKafka> list =  kafkaService.queryAllRunnable();
        for(GfdZadminKafka kafka: list) {
            String topic = kafka.getTopic();
            String groupId = kafka.getGroupId();
            String className = kafka.getClassName();
            int consumerNum = kafka.getNum();
            if(topic!=null && groupId!=null && className!=null && consumerNum>0) {
                Object object = RootMethod.rootMethod.upClass(className);
                if(object instanceof IKafkaMessage) {
                    KafkaConsumerGroup kafkaConsumerGroup = new KafkaConsumerGroup(consumerNum, groupId, topic, className);
                    kafkaConsumerGroup.start();
                }
            }
        }
    }
}