package com.sfbest.financial.certification.kafka;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 01237177
 * Date: 2017/3/8
 * Time: 17:20
 */
public interface KafkaService {
    /**
     *
     * @param gfdZadminKafka
     * @return
     */
    String insert(GfdZadminKafka gfdZadminKafka);
    /**
     *
     * @param gfdZadminKafka
     * @return
     */
    String update(GfdZadminKafka gfdZadminKafka);
    /**
     *
     * @param pk
     * @return
     */
    GfdZadminKafka query(int pk);
    /**
     *
     * @return
     */
    List<GfdZadminKafka> queryAll();
    /**
     * 分页查询数据
     * @param pageInfo 分页信息
     * @return
     */
    PageData<GfdZadminKafka> queryForList(PageInfo pageInfo);

    /**
     * 删除数据
     * @param id
     * @return
     */
    String deleteByPrimaryKey(int id);

    /**
     * 查询可运行的数据
     * @return
     */
    List<GfdZadminKafka> queryAllRunnable();

    /**
     * 启动消费者线程
     * @param id
     * @return
     */
    String start(int id) throws Exception;

    /**
     * 停止消费者线程
     * @param id
     * @return
     */
    String stop(int id) throws Exception;
}