package com.sfbest.financial.certification.kafka.impl;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.kafka.KafkaService;
import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;
import com.sfbest.financial.db.mapper.gfd.GfdZadminKafkaMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 01237177
 * Date: 2017/3/8
 * Time: 17:24
 */
@Service
public class KafkaServiceImpl extends BaseClass implements KafkaService {
    @Resource
    private GfdZadminKafkaMapper gfdZadminKafkaMapper;

    /**
     * 插入kafka记录
     * @param gfdZadminKafka
     * @return
     */
    public String insert(GfdZadminKafka gfdZadminKafka) {
        gfdZadminKafka.setId(0);
        gfdZadminKafka.setCreateTime(TimeHelper.currentTimeSecond());
        int count = gfdZadminKafkaMapper.queryExistCount(gfdZadminKafka);
        if(count>0) {
            return logInfo(9210001);
        }
        gfdZadminKafkaMapper.insertSelective(gfdZadminKafka);
        return logInfo(9210002);
    }
    /**
     * 更新kafka记录
     * @param gfdZadminKafka
     * @return
     */
    public String update(GfdZadminKafka gfdZadminKafka) {
        int count = gfdZadminKafkaMapper.queryExistCount(gfdZadminKafka);
        if(count>0) {
            return logInfo(9210001);
        }
        gfdZadminKafkaMapper.updateByPrimaryKeySelective(gfdZadminKafka);
        return logInfo(9210003);
    }
    /**
     * 通过id删除kafka记录
     * @param pk
     * @return
     */
    public GfdZadminKafka query(int pk) {
        return gfdZadminKafkaMapper.queryByPrimaryKey(pk);
    }

    /**
     * 查询所有记录
     * @return
     */
    public List<GfdZadminKafka> queryAll(){
        return gfdZadminKafkaMapper.queryAll();
    }

    /**
     * 分页查询数据
     * @param pageInfo 分页信息
     * @return
     */
    public PageData<GfdZadminKafka> queryForList(PageInfo pageInfo) {
        int totalRecords = gfdZadminKafkaMapper.queryForListCount();
        List<GfdZadminKafka> data = gfdZadminKafkaMapper.queryForList(pageInfo.getStartIndex(), pageInfo.getEndIndex());
        PageData<GfdZadminKafka> pageData = new PageData<GfdZadminKafka>();
        pageData.setPageData(data);
        pageInfo.setTotalRecords(totalRecords);
        pageData.setPageInfo(pageInfo);
        return pageData;
    }
    /**
     * 删除数据
     * @param id
     * @return
     */
    public String deleteByPrimaryKey(int id) {
        gfdZadminKafkaMapper.deleteByPrimaryKey(id);
        return logInfo(9210004);
    }

    /**
     * 查询可运行的数据
     * @return
     */
    public List<GfdZadminKafka> queryAllRunnable() {
        return gfdZadminKafkaMapper.queryAllRunnable();
    }
    /**
     * 执行消费者线程
     * @param id
     * @return
     */
    public String start(int id) throws Exception {
        GfdZadminKafka kafka = gfdZadminKafkaMapper.queryByPrimaryKey(id);

        /*String topic = kafka.getTopic();
        String groupId = kafka.getGroupId();
        String className = kafka.getClassName();
        int consumerNum = kafka.getNum();
        if(topic!=null && groupId!=null && className!=null && consumerNum>0) {
            Object object = RootMethod.rootMethod.upClass(className);
            if(object instanceof IKafkaMessage) {
                KafkaConsumerGroup kafkaConsumerGroup = new KafkaConsumerGroup(consumerNum, groupId, topic, className);
                kafkaConsumerGroup.start();
            }
        }*/

        kafka.setStatus(1);
        gfdZadminKafkaMapper.updateByPrimaryKeySelective(kafka);
        return logInfo(10001);
    }

    /**
     * 停止消费者线程
     * @param id
     * @return
     */
    public String stop(int id) throws Exception {
        GfdZadminKafka kafka = gfdZadminKafkaMapper.queryByPrimaryKey(id);
//        KafkaConsumerGroup kafkaConsumerGroup = new KafkaConsumerGroup();
//        kafkaConsumerGroup.stop(kafka.getClassName());
        kafka.setStatus(0);
        gfdZadminKafkaMapper.updateByPrimaryKeySelective(kafka);
        return logInfo(10002);
    }
}