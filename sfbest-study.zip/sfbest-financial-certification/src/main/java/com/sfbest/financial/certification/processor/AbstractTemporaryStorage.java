package com.sfbest.financial.certification.processor;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.basehelper.NumberHelper;
import com.sfbest.financial.basehelper.StringHelper;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.processor.util.AccountInOutConstant;
import com.sfbest.financial.certification.generate.GfmGenerateService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;
import com.sfbest.financial.db.entity.gshop.GshopAccountInOut;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Resource;
import java.util.Set;

/**
 * 模板方法类
 * Created by LHY on 2017/3/7.
 */
public abstract class AbstractTemporaryStorage extends BaseClass implements TemporaryStorage {
    @Resource
    private GfmGenerateService gfmGenerateService;

    /**
     * 公共方法,将公共的业务抽象出来
     * @param gshopAccountInOut 数据来源
     */
    public final String createTemporaryStorage(GshopAccountInOut gshopAccountInOut) throws Exception {
        String billCode = gfmGenerateService.getCodeWithPrefix(AccountInOutConstant.BILL_CODE);

        Set<String> chargeItemCodes = this.getChargeItems();
        if(CollectionUtils.isEmpty(chargeItemCodes)) {
            throw new Exception(logInfo("费用编码不存在"));
        }

        for(String chargeItemCode: chargeItemCodes) {
            GfdAccountCertification gfdAccountCertification = new GfdAccountCertification();
            gfdAccountCertification.setBillCode(billCode);
            gfdAccountCertification.setInvoiceCode(gfdAccountCertification.getBillCode());
            gfdAccountCertification.setVipCode("C0000" + gshopAccountInOut.getSupplierNumber());
            gfdAccountCertification.setVipZoneCode(AccountInOutConstant.VIP_ZONE_CODE);
            gfdAccountCertification.setPaymentTerm(AccountInOutConstant.PAYMENT_TERM);
            gfdAccountCertification.setVktyp(AccountInOutConstant.VKTYP);
            gfdAccountCertification.setBillVersionNo(AccountInOutConstant.BILL_VERSION_NO);
            gfdAccountCertification.setAmount(NumberHelper.fen2yuan(gshopAccountInOut.getTotal()));
            gfdAccountCertification.setCurrencyCode(AccountInOutConstant.CURRENCY_CODE);
            gfdAccountCertification.setSourceSys(AccountInOutConstant.BILL_CODE);
            gfdAccountCertification.setUniqueId(gfdAccountCertification.getBillCode()+ StringHelper.currentRandomNumber(13));
            gfdAccountCertification.setTax(gshopAccountInOut.getInTax());
            gfdAccountCertification.setGlDt(gshopAccountInOut.getCheckTime());
            gfdAccountCertification.setSupplierNumber(gshopAccountInOut.getSupplierNumber());
            gfdAccountCertification.setIoNumber(gshopAccountInOut.getCheckNumber());

            gfdAccountCertification.setPaymentDueDt(gshopAccountInOut.getCheckTime());
            gfdAccountCertification.setStartDt(gfdAccountCertification.getGlDt());
            gfdAccountCertification.setEndDt(gfdAccountCertification.getGlDt());

            gfdAccountCertification.setBillStartDt(gshopAccountInOut.getCheckTime());
            gfdAccountCertification.setBillEndDt(gshopAccountInOut.getCheckTime());
            gfdAccountCertification.setBillPeriod(gshopAccountInOut.getCheckTime());
            gfdAccountCertification.setBillEndInvFlg(AccountInOutConstant.BILL_END_INV_FLG);
            gfdAccountCertification.setCustomerCode(AccountInOutConstant.CUSTOMER_CODE + gshopAccountInOut.getSupplierNumber());
            gfdAccountCertification.setZoneCode(AccountInOutConstant.ZONE_CODE);
            gfdAccountCertification.setBuType(AccountInOutConstant.BU_TYPE);
            gfdAccountCertification.setCreateTime(TimeHelper.currentTimeSecond());
            gfdAccountCertification.setBgCode(AccountInOutConstant.BG_CODE);
            gfdAccountCertification.setDepart(AccountInOutConstant.DEPART);
            gfdAccountCertification.setChargeItemCode(chargeItemCode);
            this.createTemporaryStorage(gfdAccountCertification, gshopAccountInOut);
        }
        return billCode;
    }

    /**
     * 根据全类名获得费用类型
     * @return
     */
    public abstract Set<String> getChargeItems();

    /**
     * 抽象方法, 每个实现类各自完成自己的业务
     * @param gfdAccountCertification 中间结果数据
     * @param gshopAccountInOut 数据来源
     * @return 中间结果数据
     */
    public abstract boolean createTemporaryStorage(GfdAccountCertification gfdAccountCertification, GshopAccountInOut gshopAccountInOut);
}