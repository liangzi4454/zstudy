package com.sfbest.financial.certification.processor;

import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;
import com.sfbest.financial.db.entity.gshop.GshopAccountInOut;
import com.sfbest.financial.db.mapper.gfd.GfdAccountCertificationChargeMapper;
import com.sfbest.financial.db.mapper.gfd.GfdAccountCertificationMapper;
import org.apache.commons.lang.StringUtils;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * Created by LHY on 2017/6/6.
 */
public abstract class FrameworkTemporaryStorage extends AbstractTemporaryStorage implements TemporaryStorage {

    private static final String FRAMEWORK_TEMPORARY_STORAGE_CLASS = FrameworkTemporaryStorage.class.getName();
    private static final String SEPARATOR = ",";

    @Resource
    protected GfdAccountCertificationChargeMapper gfdAccountCertificationChargeMapper;
    @Resource
    protected GfdAccountCertificationMapper gfdAccountCertificationMapper;

    public Set<String> getChargeItems() {
        if(FRAMEWORK_TEMPORARY_STORAGE_CLASS.equals(this.getClass().getSuperclass().getName())) {
            String charItemCodes = gfdAccountCertificationChargeMapper.queryChargeItemCodes(this.getClass().getName());
            if(StringUtils.isEmpty(charItemCodes)) {
                return null;
            }
            Set<String> set = new HashSet<String>();
            String[] str = charItemCodes.split(SEPARATOR);
            for(String code: str) {
                if(!StringUtils.isEmpty(code)) {
                    set.add(code);
                }
            }
            return set;
        }
        return null;
    }

    public boolean createTemporaryStorage(GfdAccountCertification gfdAccountCertification, GshopAccountInOut gshopAccountInOut) {
        gfdAccountCertificationMapper.insertSelective(gfdAccountCertification);
        return true;
    }
}