package com.sfbest.financial.certification.processor;

import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;
import com.sfbest.financial.db.entity.gshop.GshopAccountInOut;

/**
 * 暂估入库接口
 * 暂估入库接口:经销暂估入库和代销暂付入库,还有红冲暂估
 * Created by LHY on 2017/3/6.
 */
public interface TemporaryStorage {
    /**
     * 暂估入库接口
     * @param gfdAccountCertification
     * @param gshopAccountInOut 数据来源
     */
    boolean createTemporaryStorage(GfdAccountCertification gfdAccountCertification, GshopAccountInOut gshopAccountInOut);
}
