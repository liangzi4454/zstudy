package com.sfbest.financial.certification.processor;

import com.sfbest.financial.certification.processor.performer.AgentTemporaryStorage;
import com.sfbest.financial.certification.processor.performer.DealerTemporaryStorage;
import com.sfbest.financial.certification.processor.performer.OverseaTemporaryStorage;
import com.sfbest.financial.certification.processor.performer.RedBlankingTemporaryStorage;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created by LHY on 2017/3/7.
 */
@Component
public class TemporaryStorageTemplate {
    @Resource
    private DealerTemporaryStorage dealerTemporaryStorage;
    @Resource
    private AgentTemporaryStorage agentTemporaryStorage;
    @Resource
    private OverseaTemporaryStorage overseaTemporaryStorage;
    @Resource
    private RedBlankingTemporaryStorage redBlankingTemporaryStorage;

    public DealerTemporaryStorage getDealerTemporaryStorage() {
        return dealerTemporaryStorage;
    }

    public AgentTemporaryStorage getAgentTemporaryStorage() {
        return agentTemporaryStorage;
    }

    public OverseaTemporaryStorage getOverseaTemporaryStorage() {
        return overseaTemporaryStorage;
    }

    public RedBlankingTemporaryStorage getRedBlankingTemporaryStorage() {
        return redBlankingTemporaryStorage;
    }
}