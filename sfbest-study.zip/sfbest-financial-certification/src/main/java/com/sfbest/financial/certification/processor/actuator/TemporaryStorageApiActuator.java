package com.sfbest.financial.certification.processor.actuator;

import com.alibaba.fastjson.JSONObject;
import com.sfbest.esbservice.basedata.common.VoucherParamDTO;
import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.certification.FinanceServiceApiService;
import com.sfbest.financial.certification.account.GfdAccountHeaderService;
import com.sfbest.financial.certification.processor.util.EnumAPIVoucherStatus;
import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 * NC消息回调处理类;
 * 该方法的调用方式是如下:
 * NC服务器调用 -> sfbest-esbservice-nc服务(FinanceServiceApiService#syncVoucherStatusFromNC) -> (sfbest-financial-certification)FinanceServiceApiService#syncVoucherStatusFromNC
 * </pre>
 * Created by LHY on 2017/5/17.
 */
@Component
public class TemporaryStorageApiActuator extends BaseClass implements FinanceServiceApiService {

    @Resource
    private GfdAccountHeaderService gfdAccountHeaderService;

    public String syncVoucherStatusFromNC(List<VoucherParamDTO> voucherList) {
        try {
            if (CollectionUtils.isEmpty(voucherList)) {
                return logInfo("凭证数据返回值为空");
            }
            // 查询出所有需要同步状态的凭证数据
            List<String> voucherIds = new ArrayList<String>();
            for (VoucherParamDTO temp : voucherList) {
                if (StringUtils.isEmpty(temp.getVoucherStatus()) || EnumAPIVoucherStatus.getEnum(Integer.parseInt(temp.getVoucherStatus())) == null) {
                    return logInfo(temp.getVoucherId()+" 凭证状态有误！状态代码: " + temp.getVoucherStatus()+", 错误信息: "+ JSONObject.toJSONString(voucherIds));
                }
                voucherIds.add(temp.getVoucherId());
            }
            List<GfdAccountHeader> headers = gfdAccountHeaderService.queryByHeaderSn(voucherIds);
            if (CollectionUtils.isEmpty(headers)) {
                return logInfo("系统中没有该返回的凭证号！" + JSONObject.toJSONString(voucherIds));
            }
            int result = gfdAccountHeaderService.updateDealStatusBatch(voucherList);
            if (result < 1) {
                return logInfo("同步凭证状态失败！");
            }
            return logInfo("同步状态成功");
        } catch (Exception e) {
            e.printStackTrace();
            return logInfo("接收NC返回结果的接口发生异常: "+e.getMessage());
        }
    }
}