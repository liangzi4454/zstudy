package com.sfbest.financial.certification.processor.actuator;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.basehelper.StringHelper;
import com.sfbest.financial.certification.processor.TemporaryStorageTemplate;
import com.sfbest.financial.db.entity.gshop.GshopAccountInOut;
import com.sfbest.financial.db.mapper.gshop.GshopAccountInOutMapper;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringBeanUtils;
import com.sfbest.financial.util.kafka.KafkaProducerSingleton;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 *      1.查询出入库数据:根据费用类型生成一批数据,该数据为出入库数据和凭证的中间数据,且该数据用于验证出入库,凭证,NC数据之间的正确性;
 *      2.查询方式:
 *      2.1 经销: 1.A按照月采购总额结算, 4.D按照订购总额结算(预付款) 6.B按照半月采购总额结算,7.C按照到货总额结算
 *      2.2 代销: 2.E按照销售成本结算, 3.F按照销售金额返点结算, TODO: 5这种类型暂时没有用到
 *      调用方式:
 *      com.sfbest.financial.certification.processor.zquartz.TemporaryStorageMessageJob 定时调用, 该方式需要在SettlementJob系统中发布,暂时没用
 *      com.sfbest.financial.certification.processor.zamessage.TemporaryStorageMessage kafka消息调用, 该方式需要上一级调用者(生成出入库数据的系统)发送消息调用,暂时没用
 *      com.sfbest.financial.web.VoucherController 手动调用,该方式在本系统中实现
 * </pre>
 * Created by LHY on 2017/5/17.
 */
@Component
public class TemporaryStorageMessageActuator extends BaseClass {
    @Resource
    private TemporaryStorageTemplate temporaryStorageTemplate;

    /**
     * <pre>
     * 1.查询海外直采出库单据
     * 2.查询代销商出入库单据
     * 3.查询经销商出入库单据
     * </pre>
     * @param startTime
     * @param endTime
     * @return
     * @throws Exception
     */
    public String execute(long startTime, long endTime) throws Exception {
        ConfigurationLoader loader = new ConfigurationLoader();
        List<String> result = new ArrayList<String>();
        GshopAccountInOutMapper gshopAccountInOutMapper = SpringBeanUtils.getBean(GshopAccountInOutMapper.class);
        List<GshopAccountInOut> overseaAccountList = gshopAccountInOutMapper.queryOverseaAccount(startTime, endTime);
        result.addAll(this.execute(overseaAccountList, 1));
        List<GshopAccountInOut> agentAccountList = gshopAccountInOutMapper.queryAgentAccount(startTime, endTime);
        result.addAll(this.execute(agentAccountList, 2));
        List<GshopAccountInOut> dealerAccountList = gshopAccountInOutMapper.queryDealerAccount(startTime, endTime);
        result.addAll(this.execute(dealerAccountList, 3));
        if(CollectionUtils.isNotEmpty(result)) {
            KafkaProducerSingleton.getInstance().send(loader.load("tsrm_result"), StringHelper.obj2String(result));
        }
        return logInfo("执行完成");
    }

    /**
     * 1.处理海外直采出库单据
     * 2.处理代销商出入库单据
     * 3.处理经销商出入库单据
     * @param list
     * @param type
     * @return
     */
    public List<String> execute(List<GshopAccountInOut> list, int type) throws Exception {
        List<String> result = new ArrayList<String>(list.size());
        for(GshopAccountInOut gshopAccountInOut: list) {
            String dto = null;
            if(type==1) {
                dto = createOverseaTemporaryStorage(gshopAccountInOut);
            } else if(type==2) {
                dto = createAgentTemporaryStorage(gshopAccountInOut);
            } else if(type==3) {
                dto = createDealerTemporaryStorage(gshopAccountInOut);
            }
            if(StringUtils.isNotEmpty(dto)) {
                result.add(dto);
            }
        }
        return result;
    }

    /**
     * 海外直采
     * @param gshopAccountInOut
     * @return
     */
    private String createOverseaTemporaryStorage(GshopAccountInOut gshopAccountInOut) throws Exception {
        return temporaryStorageTemplate.getOverseaTemporaryStorage().createTemporaryStorage(gshopAccountInOut);
    }

    /**
     * 代理商
     * @param gshopAccountInOut
     * @return
     */
    private String createAgentTemporaryStorage(GshopAccountInOut gshopAccountInOut) throws Exception {
        return temporaryStorageTemplate.getAgentTemporaryStorage().createTemporaryStorage(gshopAccountInOut);
    }

    /**
     * 经销商
     * @param gshopAccountInOut
     * @return
     */
    private String createDealerTemporaryStorage(GshopAccountInOut gshopAccountInOut) throws Exception {
        return temporaryStorageTemplate.getDealerTemporaryStorage().createTemporaryStorage(gshopAccountInOut);
    }
}