package com.sfbest.financial.certification.processor.actuator;

import com.alibaba.fastjson.JSON;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.account.GfdAccountHeaderService;
import com.sfbest.financial.certification.processor.util.VoucherConstant;
import com.sfbest.financial.certification.processor.util.VoucherUtil;
import com.sfbest.financial.certification.processor.zmessage.TemporaryStorageResultMessage;
import com.sfbest.financial.util.DateUtil;
import com.sfbest.financial.db.entity.gfd.*;
import com.sfbest.financial.db.mapper.gfd.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * 根据中间结果集生成实际要发送的数据
 * 功能: 生成凭证
 * <pre>
 *      上一个节点: {@link TemporaryStorageResultMessage#doExecute} 通过kafka接收消息生成凭证
 * </pre>
 * </p>
 * Created by LHY on 2017/3/30.
 */
@Component
public class TemporaryStorageResultMessageActuator {
    @Resource
    private GfdAccountHeaderService gfdAccountHeaderService;
    @Resource
    private GfdAccountHeaderMapper gfdAccountHeaderMapper;
    @Resource
    private GfdAccountDetailMapper gfdAccountDetailMapper;
    @Resource
    private GfdAccountCertificationMapper gfdAccountCertificationMapper;
    @Resource
    private GfdAccountChargeItemMapper gfdAccountChargeItemMapper;
    @Resource
    private GfdAccountMouldMapper gfdAccountMouldMapper;
    @Resource
    private GfdAccountMouldSubjectMapper gfdAccountMouldSubjectMapper;

    /**
     * 1. 生成凭证头和凭证体信息,返回凭证头的唯一编码header_sn
     * 2. 根据一组凭证header_sn建立发往NC的凭证信息，调用NC发送接口发送数据
     * @param value 一组BillCode,格式:JSONArray
     * @return 一组header_sn
     */
    public boolean execute(String value) throws Exception {
        List<String> billCodeList = JSON.parseArray(value, String.class);
        for(String billCode: billCodeList) {
            int count = gfdAccountHeaderService.queryCountByBillId(billCode);
            if(count>0) {
                continue;
            }
            Map<GfdAccountHeader, List<GfdAccountDetail>> voucher = this.executor(billCode);
            if(voucher==null||voucher.size()==0) {
                throw new Exception("凭证生成失败");
            }
            for(Map.Entry<GfdAccountHeader, List<GfdAccountDetail>> entry : voucher.entrySet()) {
                gfdAccountHeaderMapper.insertSelective(entry.getKey());
                for(GfdAccountDetail detail: entry.getValue()) {
                    gfdAccountDetailMapper.insertSelective(detail);
                }
            }
        }
        return true;
    }

    /**
     * <pre>
     *     从中间数据集中查询数据，然后处理成凭证结果数据
     * </pre>
     * <pre>
     * 1. 根据消息中的billCode反向查询中间表(gfd_materials_in_out_account)中的数据,同时得到一组费用类型编码(charge_item_code)
     *    - 通过billCode反向查询的一组中间数据中除了费用类型编码不同外其他都相同,因此组装凭证头和凭证体信息的时候可以取第一条数据
     * 2. 通过费用类型编码找到对应的一条模板数据(模板头)
     * 3. 通过模板信息查询该模板下的一组借贷信息(模板体)
     * 4. 根据中间数据、模板头信息、模板体信息、组装凭证信息,包括一条凭证头和一组凭证体
     * 5. 根据中间数据和模板体信息(计算公式)计算凭证体中的借贷金额
     * 6. 根据以上信息进行验证: 有借必有贷,借贷必相等
     * </pre>
     * @param value 消息数组 billCode
     * @return header_sn
     */
    public Map<GfdAccountHeader, List<GfdAccountDetail>> executor(String value) throws Exception {
        Map<GfdAccountHeader, List<GfdAccountDetail>> result = new HashMap<GfdAccountHeader, List<GfdAccountDetail>>();
        //1.根据billCode反向查询中间表:一个billCode对应一组费用类型编码chargeItemCode,每个chargeItemCode对应自己的金额amount
        List<GfdAccountCertification> billList = gfdAccountCertificationMapper.queryAllByBillCode(value);
        if(CollectionUtils.isEmpty(billList)) {
            throw new Exception("通过单据编码找不到该数据");
        }
        //同一个billCode的一组数据只有chargeItemCode、amount、tax不同,所以除了chargeItemCode、amount、tax之外,其他的数据都取第一条
        GfdAccountCertification one = billList.get(0);
        //计算
        Calculator calculators = new Calculator();
        Map<String, Object> env = new HashMap<String, Object>();
        for(GfdAccountCertification account: billList) {
            Temporary temporary = new Temporary(one.getBillCode(), account.getChargeItemCode(), account.getAmount(), account.getTax());
            env.put(temporary.chargeItemCodes, temporary);
        }
        //区分费用类型编码
        List<String> chargeItemCodeList = new ArrayList<String>();
        for(GfdAccountCertification account: billList) {
            chargeItemCodeList.add(account.getChargeItemCode());
        }
        if(CollectionUtils.isEmpty(chargeItemCodeList)) {
            throw new Exception("费用类型编码不存在");
        }

        //当匹配到多个模板时就会生成多个凭证信息
        List<Integer> mouldIds = gfdAccountChargeItemMapper.queryMouldIdByChargeItemCode(chargeItemCodeList);
        for(Integer mouldId: mouldIds) {
            GfdAccountMould gfdAccountMould = gfdAccountMouldMapper.selectByPrimaryKey(mouldId);
            if(gfdAccountMould==null) {
                throw new Exception("模板头数据不存在");
            }
            //根据模板头ID查询一组模板体信息
            List<GfdAccountMouldSubject> accountMouldSubjectList = gfdAccountMouldSubjectMapper.queryAll(mouldId);
            if(CollectionUtils.isEmpty(accountMouldSubjectList)) {
                throw new Exception("模板体数据不存在");
            }

            //根据中间数据、模板头信息、模板体信息、组装凭证信息(凭证头)
            GfdAccountHeader header = new GfdAccountHeader();
            header.setHeaderSn(VoucherUtil.getVoucherSn(VoucherConstant.SOURCE_FMS, VoucherConstant.HEADER));
            header.setBillId(one.getBillCode());
            header.setCompanyCode(gfdAccountMould.getCompanyCode());
            header.setAccountType("F");
            header.setVoucherType("记账凭证");
            header.setFiscalYear(DateUtil.getCurrentYearStr());
            header.setFiscalMonth(DateUtil.getCurrentMonthStr());
            header.setVoucherId(30);
            header.setAttachmentNum(0);
            header.setMakingDate(new Date());
            header.setMakingMan("999999");
            header.setIsSignature("N");
            header.setPostingDate(new Date());
            header.setSourceSystem(VoucherConstant.SOURCE_FMS);
            header.setProcessNo(VoucherUtil.getProcessNo());
            header.setCreateTime(TimeHelper.currentTimeSecond());

            //一组凭证体
            List<GfdAccountDetail> detailList = new ArrayList<GfdAccountDetail>();
            int entryId = 1;
            for(GfdAccountMouldSubject subject: accountMouldSubjectList) {
                GfdAccountDetail detail = new GfdAccountDetail();
                detail.setDetailSn(VoucherUtil.getVoucherSn(VoucherConstant.SOURCE_FMS, VoucherConstant.LINE));
                detail.setEntryId(entryId);
                detail.setBillDate(new Date());
                detail.setHeaderSn(header.getHeaderSn());
                detail.setBillId(header.getBillId());
                detail.setAccountType(header.getAccountType());
                //按照以上逻辑处理,该bill_type就是错误的
                detail.setBillType(String.valueOf(mouldId));
                detail.setSubjectCode(subject.getSubjectCode());
                detail.setSummary(subject.getSubjectSummary());
                detail.setCurrency(subject.getCurrencySymbol());
                detail.setExchangeRate1(subject.getExRate1());
                detail.setExchangeRate2(subject.getExRate2());

                //处理借贷关系: 原币借方发生额,辅币借方发生额,本币借方发生额
                //处理借贷关系: 原币贷方发生额,辅币贷方发生额,本币贷方发生额
                if(subject.getDebitCredit()==0) {//借
                    detail.setPrimaryDebitAmount(NumberUtils.createBigDecimal(calculators.compute(env, subject.getFormula())));
                    detail.setNaturalDebitCurrency(detail.getPrimaryDebitAmount());
                    detail.setSecondaryDebitAmount(new BigDecimal(0));
                } else if(subject.getDebitCredit()==1) {//贷
                    detail.setPrimaryCreditAmount(new BigDecimal(calculators.compute(env, subject.getFormula())));
                    detail.setNaturalCreditCurrency(detail.getPrimaryCreditAmount());
                    detail.setSecondaryCreditAmount(new BigDecimal(0));
                } else {
                    throw new Exception("借贷有问题");
                }

                //有机必有贷借贷必相等,这里缺少这个判断

                detail.setDebitType(subject.getDebitCredit());
                detail.setProcessNo(header.getProcessNo());
                detail.setCreateTime(TimeHelper.currentTimeSecond());
                detailList.add(detail);
                entryId++;
            }
            result.put(header, detailList);
        }

        return result;
    }

    /**
     * 计算器
     */
    public class Temporary {
        /** billCode唯一值 **/
        String billCode;
        /** 一个billCode对应多个chargeItemCode **/
        String chargeItemCodes;
        /** 计算金额 **/
        BigDecimal amount;
        /** 进项税率 **/
        Double tax;

        public Temporary(String billCode, String chargeItemCodes, BigDecimal amount, Double tax){
            this.billCode=billCode;
            this.chargeItemCodes=chargeItemCodes;
            this.amount=amount;
            this.tax = tax;
        }

        public String getBillCode() {
            return billCode;
        }

        public void setBillCode(String billCode) {
            this.billCode = billCode;
        }

        public String getChargeItemCodes() {
            return chargeItemCodes;
        }

        public void setChargeItemCodes(String chargeItemCodes) {
            this.chargeItemCodes = chargeItemCodes;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        public Double getTax() {
            return tax;
        }

        public void setTax(Double tax) {
            this.tax = tax;
        }
    }

    /**
     * 计算器
     */
    public class Calculator {
        Pattern pattern = Pattern.compile("#\\{(.*?)\\}");
        public String compute(Map<String, Object> env, String expression) {
            Matcher matcher = pattern.matcher(expression);
            if(matcher.matches()) {
                String express = matcher.group(1);
                Expression compiledExp = AviatorEvaluator.compile(express);
                Object object = compiledExp.execute(env);
                return String.valueOf(object);
            }
            return "";
        }
    }
}