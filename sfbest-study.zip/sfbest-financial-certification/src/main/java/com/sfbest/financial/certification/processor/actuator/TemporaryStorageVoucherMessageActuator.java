package com.sfbest.financial.certification.processor.actuator;

import com.alibaba.fastjson.JSONObject;
import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.financial.certification.account.GfdAccountHeaderService;
import com.sfbest.financial.certification.processor.util.VoucherBeanUtils;
import com.sfbest.financial.certification.zcxfapi.HeaderDTO;
import com.sfbest.financial.certification.zcxfapi.IVoucherService;
import com.sfbest.financial.certification.zcxfapi.InterfaceGlHeadersVO;
import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;
import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 发送凭证的接口:
 * 该接口有三种调用方式:
 *      1. 手动发送 com.sfbest.financial.web.VoucherController#execute 该方式正常使用
 *      2. 定时发送 com.sfbest.financial.certification.processor.zquartz.TemporaryStorageVoucherMessageJob#doExecute 该方式正常使用
 *      3. kafka发送 com.sfbest.financial.certification.processor.zamessage.TemporaryStorageVoucherMessage#doExecute 该方式暂时没用
 * <pre>
 * Created by LHY on 2017/4/13.
 */
@SuppressWarnings("all")
@Component
public class TemporaryStorageVoucherMessageActuator extends BaseClass {
    @Resource
    private GfdAccountHeaderService gfdAccountHeaderService;
    @Autowired
    @Qualifier("iVoucherService")
    private IVoucherService iVoucherService;
    /**
     * 1. 组织发送凭证的对象
     * 2. 发送凭证
     * 3. 返回结果，返回状态只表示发送成功或失败，不表示处理是否成功
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @throws Exception
     */
    public String execute(long startTime, long endTime) throws Exception {
        /** 根据时间查询凭证信息 **/
        Map<GfdAccountHeader, List<GfdAccountDetail>> result = gfdAccountHeaderService.queryByCreateTime(startTime, endTime);
        /** 需要发送的凭证 **/
        List<InterfaceGlHeadersVO> voList = new ArrayList<InterfaceGlHeadersVO>();
        /** 组装消息 **/
        for(Map.Entry<GfdAccountHeader, List<GfdAccountDetail>> entry: result.entrySet()) {
            InterfaceGlHeadersVO vo = VoucherBeanUtils.voucherBeanUtils.copyProperties(entry.getKey(), entry.getValue());
            voList.add(vo);
        }
        if(CollectionUtils.isEmpty(voList)) {
            return logInfo("没有查到数据");
        }
        /** 推送成功列表 */
        List<String> sucVoucherIds = new ArrayList<String>();
        /**推送失败列表*/
        List<String> errVoucherIds = new ArrayList<String>();
        /** 发送数据 **/
        logInfo("推送数据到NC的信息: "+ JSONObject.toJSONString(voList));
        List<HeaderDTO> resultList = iVoucherService.setVoucher(voList);
        logInfo("推送数据到NC返回结果: "+ JSONObject.toJSONString(resultList));
        /** 处理发送结果 **/
        for(HeaderDTO dto: resultList) {
            String headerId = dto.getHeaderId();
            String sendFlag = dto.getSendFlg();
            if("1".equals(sendFlag)) {
                sucVoucherIds.add(headerId);
            } else {
                errVoucherIds.add(headerId);
            }
        }
        String message = "";
        /**调用批量接口更新凭证状态*/
        if(sucVoucherIds.size()>0) {
            gfdAccountHeaderService.updateDealStatusByVoucherIds(sucVoucherIds, 1);
            message = logInfo("推送成功: "+ JSONObject.toJSONString(sucVoucherIds));
        }
        if(errVoucherIds.size()>0) {
            gfdAccountHeaderService.updateDealStatusByVoucherIds(errVoucherIds, 2);
            message = logInfo("推送失败: "+ JSONObject.toJSONString(errVoucherIds));
        }
        return message;
    }
}