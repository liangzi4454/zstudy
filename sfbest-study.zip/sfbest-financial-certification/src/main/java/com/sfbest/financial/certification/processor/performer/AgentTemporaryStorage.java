package com.sfbest.financial.certification.processor.performer;

import com.sfbest.financial.certification.processor.FrameworkTemporaryStorage;
import org.springframework.stereotype.Component;

/**
 * <pre>
 * 代销暂估入库
 * 应用场景: 代销商品入库-发票未到
 * 场景编码: DXSPRK-FPWD
 * 单据类型: 代销商品入库单、代销商品退货单
 * 时间节点: 到货入库、退货出库
 * 凭证周期: 按日汇总生成凭证
 * </pre>
 * Created by LHY on 2017/3/6.
 */
@Component
public class AgentTemporaryStorage extends FrameworkTemporaryStorage {

}