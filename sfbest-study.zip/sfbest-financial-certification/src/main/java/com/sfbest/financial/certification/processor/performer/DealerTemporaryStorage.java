package com.sfbest.financial.certification.processor.performer;

import com.sfbest.financial.certification.processor.FrameworkTemporaryStorage;
import org.springframework.stereotype.Component;

/**
 * <pre>
 * 深电(购销)采购业务(无预付款) - 暂估入库
 * 应用场景: 采购入库、发票未到
 * 场景编码: ZGRK-CGRK
 * 单据类型: 采购入库单、采购退货单、采购空入单、采购空出单
 * 时间节点: 到货入库、退货出库
 * 凭证周期: 按日汇总生成凭证
 * </pre>
 * Created by LHY on 2017/3/6.
 */
@Component
public class DealerTemporaryStorage extends FrameworkTemporaryStorage {

}