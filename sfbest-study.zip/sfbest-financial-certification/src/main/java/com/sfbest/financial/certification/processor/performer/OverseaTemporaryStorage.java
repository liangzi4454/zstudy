package com.sfbest.financial.certification.processor.performer;

import com.sfbest.financial.certification.processor.FrameworkTemporaryStorage;
import org.springframework.stereotype.Component;

/**
 * <pre>
 * 海采入库凭证
 * 应用场景: 按订购总额入库
 * 场景编码: HCRKPZ-CGRK
 * 单据类型: 海采入库单
 * 时间节点: 商品验收入库
 * 凭证周期: 按日汇总生成凭证
 * </pre>
 * Created by LHY on 2017/3/7.
 */
@Component
public class OverseaTemporaryStorage extends FrameworkTemporaryStorage {

}