package com.sfbest.financial.certification.processor.performer;

import com.sfbest.financial.certification.processor.FrameworkTemporaryStorage;
import org.springframework.stereotype.Component;

/**
 * <pre>
 * 红冲暂估
 * 应用场景: 暂估入库、收到发票;
 * 场景编码: HCZG-SDFP
 * 单据类型: 发票、结算单;
 * 时间节点: 发票已审核校验(已对账)
 * 需求描述:
 * </pre>
 * Created by LHY on 2017/3/6.
 */
@Component
public class RedBlankingTemporaryStorage extends FrameworkTemporaryStorage {

}