package com.sfbest.financial.certification.processor.util;

/**
 * 常量参数
 * Created by LHY on 2017/3/7.
 */
public final class AccountInOutConstant {
    /** 系统来源FMS, 用该参数生成账单流水:FMS+流水编号 **/
    public static final String BILL_CODE = "FMS";
    /** 月结卡号:C0000+供应商编码 **/
    public static final String CUSTOMER_CODE = "C0000";
    /** 月结卡号对应的网点 **/
    public static final String ZONE_CODE = "SSM7551";
    /** 结算账号对应的网点 **/
    public static final String VIP_ZONE_CODE = "SSM7551";
    /** 完整帐期标志:0非完整帐期发票，1完整帐期发票 **/
    public static final String BILL_END_INV_FLG = "1";
    /** 付款条件(必须为数字) **/
    public static final int PAYMENT_TERM = 30;
    /** 合同帐户类别 **/
    public static final String VKTYP = "2";
    /** 账单版本号 **/
    public static final String BILL_VERSION_NO = "1";
    /** 货币码 **/
    public static final String CURRENCY_CODE  = "CNY";
    /** BU类型 **/
    public static final String BU_TYPE  = "SY";
    /** BG代码 **/
    public static final String BG_CODE  = "B04";
    /** 部门：固定值 **/
    public static final String DEPART  = "30";
}