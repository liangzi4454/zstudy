package com.sfbest.financial.certification.processor.util;

/**
 *
 */
public enum EnumAPIVoucherStatus {

    voucherstatus(0,"单据生成"),
    voucherstatus1(1,"发送成功"),
    voucherstatus2(2,"发送失败"),
    voucherstatus3(3,"处理成功"),
    voucherstatus4(4,"处理失败");

    private Integer code;
    private String value;

    EnumAPIVoucherStatus(Integer code, String value) {
        this.code = code;
        this.value = value;
    }

    public static EnumAPIVoucherStatus getEnum(Integer code) {
        for (EnumAPIVoucherStatus e : EnumAPIVoucherStatus.values()) {
            if (e.getCode() == code) {
                return e;
            }
        }
        return null;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
