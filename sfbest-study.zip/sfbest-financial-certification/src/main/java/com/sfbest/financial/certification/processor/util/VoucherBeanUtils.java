package com.sfbest.financial.certification.processor.util;

import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.zcxfapi.InterfaceGlHeadersVO;
import com.sfbest.financial.certification.zcxfapi.InterfaceGlLinesVO;
import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;
import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import org.apache.commons.lang.StringUtils;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Created by LHY on 2017/4/13.
 */
public class VoucherBeanUtils {
    public static VoucherBeanUtils voucherBeanUtils = new VoucherBeanUtils();

    /**
     *
     * @param header
     * @param details
     * @return
     * @throws Exception
     */
    public InterfaceGlHeadersVO copyProperties(GfdAccountHeader header, List<GfdAccountDetail> details) throws Exception {
        InterfaceGlHeadersVO vo = copyProperties(header);
        vo.setLines(copyProperties(details));
        return vo;
    }

    /**
     *
     * @param header
     * @throws Exception
     */
    public InterfaceGlHeadersVO copyProperties(GfdAccountHeader header) throws Exception {
        InterfaceGlHeadersVO vo = new InterfaceGlHeadersVO();
        vo.setHeaderId(new BigInteger(header.getHeaderSn()));
        vo.setGlType(header.getAccountType());
        vo.setCompany(header.getCompanyCode());
        vo.setVoucherType(header.getVoucherType());
        vo.setFiscalYear(header.getFiscalYear());
        vo.setFiscalMonth(header.getFiscalMonth());
        vo.setVoucherId(header.getVoucherId());
        vo.setAttachmentNumber(header.getAttachmentNum());
        vo.setPrepareddate(string2Gregorian(TimeHelper.upDateTime(header.getMakingDate(), "yyyy-MM-dd")));
        vo.setEnter(header.getMakingMan());
        vo.setCashier(header.getCashier());
        vo.setSignature(header.getIsSignature());
        vo.setVoucherMakingSystem(header.getSourceSystem());
        vo.setProcessNo(new BigInteger(header.getProcessNo()));
        vo.setSendFlg(header.getSendFlag());
        vo.setCreatedTm(string2Gregorian(TimeHelper.upDateTime("yyyy-MM-dd")));
        return vo;
    }

    /**
     *
     * @param details
     */
    public List<InterfaceGlLinesVO> copyProperties(List<GfdAccountDetail> details) throws Exception {
        List<InterfaceGlLinesVO> list = new ArrayList<>();
        for(GfdAccountDetail detail: details) {
            InterfaceGlLinesVO line = new InterfaceGlLinesVO();
            line.setLineId(new BigInteger(detail.getDetailSn()));
            line.setGlType(detail.getAccountType());
            line.setEntryId(detail.getEntryId());
            line.setAccountCode(detail.getSubjectCode());
            line.setAbstract(detail.getSummary());
            line.setCurrency(detail.getCurrency());
            line.setUnitPrice(detail.getUnitPrice().doubleValue());
            line.setExchangeRate1(detail.getExchangeRate1().doubleValue());
            line.setExchangeRate2(detail.getExchangeRate2().doubleValue());
            line.setDebitQuantity(detail.getDebitCnt().doubleValue());
            line.setPrimaryDebitAmount(detail.getPrimaryDebitAmount().doubleValue());
            line.setSecondaryDebitAmount(detail.getSecondaryDebitAmount().doubleValue());
            line.setNaturalDebitCurrency(detail.getNaturalDebitCurrency().doubleValue());
            line.setCreditQuantity(detail.getCreditCnt().doubleValue());
            line.setPrimaryCreditAmount(detail.getPrimaryCreditAmount().doubleValue());
            line.setSecondaryCreditAmount(detail.getSecondaryCreditAmount().doubleValue());
            line.setNaturalCreditCurrency(detail.getNaturalCreditCurrency().doubleValue());
            line.setBillType(detail.getBillType());
            line.setBillId(detail.getBillId());

            line.setBillDate(string2Gregorian(TimeHelper.upDateTime(detail.getBillDate(), "yyyy-MM-dd")));
            line.setWorkCenter(StringUtils.defaultString(detail.getWorkCenter()));
            line.setWorkNetwork(StringUtils.defaultString(detail.getWorkNetwork()));
            line.setItem1(StringUtils.defaultString(detail.getItem1()));
            line.setItem2(StringUtils.defaultString(detail.getItem2()));
            line.setItem3(StringUtils.defaultString(detail.getItem3()));
            line.setItem4(StringUtils.defaultString(detail.getItem4()));
            line.setItem5(StringUtils.defaultString(detail.getItem5()));
            line.setItem6(StringUtils.defaultString(detail.getItem6()));
            line.setItem7(StringUtils.defaultString(detail.getItem7()));
            line.setItem8(StringUtils.defaultString(detail.getItem8()));
            line.setItem9(StringUtils.defaultString(detail.getItem9()));
            line.setItem10(StringUtils.defaultString(detail.getItem10()));

            line.setCreatedTm(string2Gregorian(TimeHelper.upDateTime("yyyy-MM-dd")));
            line.setHeaderId(new BigInteger(detail.getHeaderSn()));
            line.setProcessNo(Double.valueOf(detail.getProcessNo()));
            line.setSendFlg(detail.getSendFlag());
            list.add(line);
        }
        return list;
    }

    /**
     *
     * @param str
     * @return
     * @throws Exception
     */
    public XMLGregorianCalendar string2Gregorian(String str) throws Exception {
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date = format.parse(str);
        DatatypeFactory dataTypeFactory;
        dataTypeFactory = DatatypeFactory.newInstance();
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTimeInMillis(date.getTime());
        return dataTypeFactory.newXMLGregorianCalendar(gc);
    }
}