package com.sfbest.financial.certification.processor.util;

/**
 * 1. 单据的系统来源
 * 2. 凭证头部与凭证体信息
 * Created by LHY on 2017/3/14.
 * @see VoucherUtil 生成凭证编码信息
 */
public class VoucherConstant {
    /**
     * 单据来源系统-ECS
     */
    public static final String SOURCE_ECS = "ECS";
    /**
     * 单据来源系统-FMS
     */
    public static final String SOURCE_FMS = "FMS";
    /**
     * 凭证头部 HEADER
     */
    public static final String HEADER = "HEADER";
    /**
     * 凭证体 LINE
     */
    public static final String LINE = "LINE";
}