package com.sfbest.financial.certification.processor.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * Created by LHY on 2017/3/29.
 */
public class VoucherUtil {
    /**
     * <pre>
     * 凭证编码(发送给NC的ID)
     * 根据单据来源编码和凭证标识生成发送给NC的凭证编码,分别为15位的凭证头编码与凭证体编码;
     * 生成规则: 商业系统+单据来源+凭证标识(头or体)+年月日+6位随机数
     *      第一位: 8 表示商业系统;
     *      第二位: 1 表示数据来源于FMS,
     *              2 表示数据来源于ECS;
     *      第三位: 1 表示头信息,
     *              2 表示具体信息;
     *      第4-10位: 年月日,如170301;
     *      第11-15位: 随机数;
     * </pre>
     * @param source 单据来源 FMS or ESC
     * @param voucher 凭证标识 HEADER or LINE
     * @return 15位凭证头编码或凭证体编码
     * @see VoucherConstant 凭证信息与单据来源
     */
    public static String getVoucherSn(String source, String voucher) {
        StringBuffer voucherSn = new StringBuffer("8");
        if (VoucherConstant.SOURCE_ECS.equals(source)) {
            voucherSn.append("2");
        } else if (VoucherConstant.SOURCE_FMS.equals(source)) {
            voucherSn.append("1");
        }
        if (VoucherConstant.HEADER.equals(voucher)) {
            voucherSn.append("1");
        } else if (VoucherConstant.LINE.equals(voucher)) {
            voucherSn.append("2");
        }
        voucherSn.append(new SimpleDateFormat("yyMMdd").format(new Date()));
        voucherSn.append(String.valueOf((int)((Math.random()*9+1)*100000)));
        return voucherSn.toString();
    }

    /**
     * 凭证处理批次号
     * @return
     */
    public static String getProcessNo() {
        StringBuffer strBul = new StringBuffer();
        Date now = new Date();
        SimpleDateFormat sf=new SimpleDateFormat("yyMMdd");
        String ymd = sf.format(now);
        strBul.append(ymd);
        strBul.append(new Random().nextInt(8999) + 1000);
        strBul.append(new Random().nextInt(89999) + 10000);

        return strBul.toString();
    }
}
