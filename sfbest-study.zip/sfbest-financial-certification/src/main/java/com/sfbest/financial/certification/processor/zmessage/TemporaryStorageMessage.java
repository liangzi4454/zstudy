package com.sfbest.financial.certification.processor.zmessage;

import com.sfbest.financial.certification.processor.actuator.TemporaryStorageMessageActuator;
import com.sfbest.financial.util.kafka.AbstractKafkaMessage;
import com.sfbest.financial.basehelper.StringHelper;
import com.sfbest.financial.certification.email.GfdZadminEmailService;
import com.sfbest.financial.util.MessageProxy;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringBeanUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * <pre>
 *     通过kafka接收消息处理出入库数据,
 *     参数:
 *          startTime(Long) 结束时间
 *          endTime(Long) 开始时间
 * </pre>
 * <pre>
 *      1.
 *      从入库单表(gshop_product_in_wh)和出库单表(gshop_product_out_wh)抽取数据,
 *      然后将该数据组合成凭证数据(gfd_account_certification)，该凭证数据不是真实的凭证数据，只是用于生成真实凭证(gfd_account_header和gfd_account_detail)而做的中间数据,
 *      即出入库单表和凭证表的中间表;该中间表数据可用于向前核对和向后核对;
 *      2.
 *      处理完成数据之后可以通过kafka消息服务器将数据发送的下一个节点处理,调用方式请使用:
 *      com.sfbest.financial.api.KafkaProducerFacade#send
 *      使用该消息服务器请使用finance-infrastructure-message包,版本请查询公司服务器
 *      3.
 *      注: 在继承job类的类中无法使用spring容器中已经注入的bean对象,所以需要其他方式获取需要的bean对象;
 *      当前该类中使用的是com.sfbest.financial.util.SpringBeanUtils.getBean(class)的方式获取bean对象
 * </pre>
 * <pre>
 *     下一个节点: {@link TemporaryStorageResultMessage#doExecute} 生成真正的凭证数据
 * </pre>
 * <pre>
 *     注: AbstractKafkaMessage 可以不用继承
 * </pre>
 * Created by LHY on 2017/3/8.
 */
@Component
public class TemporaryStorageMessage extends AbstractKafkaMessage {

    /**
     * 具体参数:
     * startTime(Long) 结束时间
     * endTime(Long) 开始时间
     * @param value JSON数据
     * @return
     */
    public boolean doExecute(String value) {
        ConfigurationLoader loader = new ConfigurationLoader();
        try {
            Map<String, Object> map = StringHelper.json2Map(value);
            long startTime = Long.valueOf(String.valueOf(map.get("startTime")));
            long endTime = Long.valueOf(String.valueOf(map.get("endTime")));

            TemporaryStorageMessageActuator temporaryStorageMessageActuator = SpringBeanUtils.getBean(TemporaryStorageMessageActuator.class);
            temporaryStorageMessageActuator.execute(startTime, endTime);
        } catch (Exception e) {
            e.printStackTrace();
            GfdZadminEmailService gfdZadminEmailService = SpringBeanUtils.getBean(GfdZadminEmailService.class);
            MessageProxy proxy = SpringBeanUtils.getBean(MessageProxy.class);
            proxy.sendEmail(gfdZadminEmailService.queryEmailByCode(loader.load("tms_result")), "凭证中间件消息异常", e.getMessage());
            return false;
        }
        return true;
    }
}