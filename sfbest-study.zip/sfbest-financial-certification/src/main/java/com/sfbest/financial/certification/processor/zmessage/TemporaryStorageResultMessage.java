package com.sfbest.financial.certification.processor.zmessage;

import com.sfbest.financial.util.kafka.AbstractKafkaMessage;
import com.sfbest.financial.certification.processor.actuator.TemporaryStorageResultMessageActuator;
import com.sfbest.financial.certification.email.GfdZadminEmailService;
import com.sfbest.financial.util.MessageProxy;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringBeanUtils;
import org.springframework.stereotype.Component;

/**
 * <pre>
 *      生成真正的凭证数据
 * </pre>
 * <pre>
 *      上一个节点: {@link TemporaryStorageMessage#doExecute} 通过kafka接收消息处理出入库数据
 * </pre>
 * <pre>
 *      数据处理完成后需要发往NC:
 *      1. 手动发送 com.sfbest.financial.web.VoucherController#execute 该方式正常使用
 *      2. 定时发送 com.sfbest.financial.certification.processor.zquartz.TemporaryStorageVoucherMessageJob#doExecute 该方式需要在SettlementJob系统中发布,暂时没用
 *      3. kafka发送 com.sfbest.financial.certification.processor.zamessage.TemporaryStorageVoucherMessage#doExecute 该方式需要上一级调用者发送消息调用,暂时没用
 * </pre>
 * Created by LHY on 2017/3/27.
 */
@Component
public class TemporaryStorageResultMessage extends AbstractKafkaMessage {

    /**
     * 具体参数: 一组BillCode
     * @param value JSON数据
     * @return
     */
    public boolean doExecute(String value) {
        try {
            TemporaryStorageResultMessageActuator temporaryStorageResultMessageActuator = SpringBeanUtils.getBean(TemporaryStorageResultMessageActuator.class);
            temporaryStorageResultMessageActuator.execute(value);
            return true;
        } catch (Exception e) {
            ConfigurationLoader loader = new ConfigurationLoader();
            GfdZadminEmailService gfdZadminEmailService = SpringBeanUtils.getBean(GfdZadminEmailService.class);
            MessageProxy proxy = SpringBeanUtils.getBean(MessageProxy.class);
            proxy.sendEmail(gfdZadminEmailService.queryEmailByCode(loader.load("tsrm_result")), "生成凭证结果信息", e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}