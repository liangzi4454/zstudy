package com.sfbest.financial.certification.processor.zmessage;

import com.sfbest.financial.util.kafka.AbstractKafkaMessage;
import com.sfbest.financial.basehelper.StringHelper;
import com.sfbest.financial.certification.processor.actuator.TemporaryStorageVoucherMessageActuator;
import com.sfbest.financial.certification.email.GfdZadminEmailService;
import com.sfbest.financial.util.MessageProxy;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringBeanUtils;

import java.util.Map;

/**
 * <pre>
 *      kafka接收消息发送凭证到NC;
 *      暂时没用;
 * </pre>
 * Created by LHY on 2017/4/13.
 */
public class TemporaryStorageVoucherMessage extends AbstractKafkaMessage {

    public boolean doExecute(String value) {
        ConfigurationLoader loader = new ConfigurationLoader();
        try {
            Map<String, Object> map = StringHelper.json2Map(value);
            long startTime = Long.valueOf(String.valueOf(map.get("startTime")));
            long endTime = Long.valueOf(String.valueOf(map.get("endTime")));
            TemporaryStorageVoucherMessageActuator temporaryStorageVoucherMessageActuator = SpringBeanUtils.getBean(TemporaryStorageVoucherMessageActuator.class);
            temporaryStorageVoucherMessageActuator.execute(startTime, endTime);
            return true;
        } catch (Exception e) {
            GfdZadminEmailService gfdZadminEmailService = SpringBeanUtils.getBean(GfdZadminEmailService.class);
            MessageProxy proxy = SpringBeanUtils.getBean(MessageProxy.class);
            proxy.sendEmail(gfdZadminEmailService.queryEmailByCode(loader.load("tsrm_result")), "发送NC凭证消息", e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}