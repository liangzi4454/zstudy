package com.sfbest.financial.certification.processor.zquartz;

import com.sfbest.financial.basecom.baseclass.BaseJob;
import com.sfbest.financial.certification.processor.actuator.TemporaryStorageMessageActuator;
import com.sfbest.financial.certification.email.GfdZadminEmailService;
import com.sfbest.financial.util.MessageProxy;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringBeanUtils;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.Date;

/**
 * <pre>
 *     通过定时处理处理出入库数据
 *     参数:
 *          startTime(Long) 结束时间
 *          endTime(Long) 开始时间
 * </pre>
 * <pre>
 *      1.
 *      从入库单表(gshop_product_in_wh)和出库单表(gshop_product_out_wh)抽取数据,
 *      然后将该数据组合成凭证数据(gfd_account_certification)，该凭证数据不是真实的凭证数据，只是用于生成真实凭证(gfd_account_header和gfd_account_detail)而做的中间数据,
 *      即出入库单表和凭证表的中间表;该中间表数据可用于向前核对和向后核对;
 *      2.
 *      处理完成数据之后可以通过kafka消息服务器将数据发送的下一个节点处理,调用方式请使用:
 *      com.sfbest.financial.api.KafkaProducerFacade#send
 *      使用该消息服务器请使用finance-infrastructure-message包,版本请查询公司服务器
 *      3.
 *      注: 在继承job类的类中无法使用spring容器中已经注入的bean对象,所以需要其他方式获取需要的bean对象;
 *      当前该类中使用的是com.sfbest.financial.util.SpringBeanUtils.getBean(class)的方式获取bean对象
 * </pre>
 * Created by LHY on 2017/5/2.
 */
public class TemporaryStorageMessageJob extends BaseJob {

    public void execute(JobExecutionContext context) throws JobExecutionException {
        this.doExecute(context.getPreviousFireTime().getTime() / 1000l, new Date().getTime() /1000l);
    }

    public boolean doExecute(long startTime, long endTime) {
        ConfigurationLoader loader = new ConfigurationLoader();
        try {
            TemporaryStorageMessageActuator temporaryStorageMessageActuator = SpringBeanUtils.getBean(TemporaryStorageMessageActuator.class);
            temporaryStorageMessageActuator.execute(startTime, endTime);
        } catch (Exception e) {
            e.printStackTrace();
            GfdZadminEmailService gfdZadminEmailService = SpringBeanUtils.getBean(GfdZadminEmailService.class);
            MessageProxy proxy = SpringBeanUtils.getBean(MessageProxy.class);
            proxy.sendEmail(gfdZadminEmailService.queryEmailByCode(loader.load("tms_result")), "凭证中间件消息异常", e.getMessage());
            return false;
        }
        return true;
    }
}
