package com.sfbest.financial.certification.processor.zquartz;

import com.sfbest.financial.basecom.baseclass.BaseJob;
import com.sfbest.financial.certification.processor.actuator.TemporaryStorageVoucherMessageActuator;
import com.sfbest.financial.certification.email.GfdZadminEmailService;
import com.sfbest.financial.util.MessageProxy;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringBeanUtils;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 通过定时器发送凭证到NC;
 * Created by LHY on 2017/5/2.
 */
@Component
public class TemporaryStorageVoucherMessageJob extends BaseJob {
    /**
     * 获取定时器的开始时间和结束时间
     * @param context
     * @throws JobExecutionException
     */
    public void execute(JobExecutionContext context) throws JobExecutionException {
        this.doExecute(context.getPreviousFireTime().getTime() / 1000l, new Date().getTime() /1000l);
    }

    /**
     * 发送凭证数据到NC
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return
     */
    public boolean doExecute(long startTime, long endTime) {
        ConfigurationLoader loader = new ConfigurationLoader();
        try {
            TemporaryStorageVoucherMessageActuator temporaryStorageVoucherMessageActuator = SpringBeanUtils.getBean(TemporaryStorageVoucherMessageActuator.class);
            temporaryStorageVoucherMessageActuator.execute(startTime, endTime);
            return true;
        } catch (Exception e) {
            GfdZadminEmailService gfdZadminEmailService = SpringBeanUtils.getBean(GfdZadminEmailService.class);
            MessageProxy proxy = SpringBeanUtils.getBean(MessageProxy.class);
            proxy.sendEmail(gfdZadminEmailService.queryEmailByCode(loader.load("tsrm_result")), "发送NC凭证消息", e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}