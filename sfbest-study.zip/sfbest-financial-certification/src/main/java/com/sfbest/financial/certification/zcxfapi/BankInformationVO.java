
package com.sfbest.financial.certification.zcxfapi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bankInformationVO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bankInformationVO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="acc_Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="area_Code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="area_Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="banka" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bankl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bankn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bankname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="banks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bukrs" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="corp_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hkont" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hktyp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="login_Time" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="logout_Time" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="provz" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wears" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="yqzl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bankInformationVO", propOrder = {
    "accStatus",
    "areaCode",
    "areaName",
    "banka",
    "bankl",
    "bankn",
    "bankname",
    "banks",
    "bukrs",
    "city",
    "corpName",
    "hkont",
    "hktyp",
    "loginTime",
    "logoutTime",
    "name",
    "provz",
    "wears",
    "yqzl"
})
public class BankInformationVO {

    @XmlElement(name = "acc_Status")
    protected String accStatus;
    @XmlElement(name = "area_Code")
    protected String areaCode;
    @XmlElement(name = "area_Name")
    protected String areaName;
    protected String banka;
    protected String bankl;
    protected String bankn;
    protected String bankname;
    protected String banks;
    protected String bukrs;
    protected String city;
    @XmlElement(name = "corp_name")
    protected String corpName;
    protected String hkont;
    protected String hktyp;
    @XmlElement(name = "login_Time")
    protected String loginTime;
    @XmlElement(name = "logout_Time")
    protected String logoutTime;
    protected String name;
    protected String provz;
    protected String wears;
    protected String yqzl;

    /**
     * Gets the value of the accStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccStatus() {
        return accStatus;
    }

    /**
     * Sets the value of the accStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccStatus(String value) {
        this.accStatus = value;
    }

    /**
     * Gets the value of the areaCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaCode() {
        return areaCode;
    }

    /**
     * Sets the value of the areaCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaCode(String value) {
        this.areaCode = value;
    }

    /**
     * Gets the value of the areaName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaName() {
        return areaName;
    }

    /**
     * Sets the value of the areaName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaName(String value) {
        this.areaName = value;
    }

    /**
     * Gets the value of the banka property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBanka() {
        return banka;
    }

    /**
     * Sets the value of the banka property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBanka(String value) {
        this.banka = value;
    }

    /**
     * Gets the value of the bankl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankl() {
        return bankl;
    }

    /**
     * Sets the value of the bankl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankl(String value) {
        this.bankl = value;
    }

    /**
     * Gets the value of the bankn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankn() {
        return bankn;
    }

    /**
     * Sets the value of the bankn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankn(String value) {
        this.bankn = value;
    }

    /**
     * Gets the value of the bankname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankname() {
        return bankname;
    }

    /**
     * Sets the value of the bankname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankname(String value) {
        this.bankname = value;
    }

    /**
     * Gets the value of the banks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBanks() {
        return banks;
    }

    /**
     * Sets the value of the banks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBanks(String value) {
        this.banks = value;
    }

    /**
     * Gets the value of the bukrs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBukrs() {
        return bukrs;
    }

    /**
     * Sets the value of the bukrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBukrs(String value) {
        this.bukrs = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the corpName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorpName() {
        return corpName;
    }

    /**
     * Sets the value of the corpName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorpName(String value) {
        this.corpName = value;
    }

    /**
     * Gets the value of the hkont property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHkont() {
        return hkont;
    }

    /**
     * Sets the value of the hkont property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHkont(String value) {
        this.hkont = value;
    }

    /**
     * Gets the value of the hktyp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHktyp() {
        return hktyp;
    }

    /**
     * Sets the value of the hktyp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHktyp(String value) {
        this.hktyp = value;
    }

    /**
     * Gets the value of the loginTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoginTime() {
        return loginTime;
    }

    /**
     * Sets the value of the loginTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoginTime(String value) {
        this.loginTime = value;
    }

    /**
     * Gets the value of the logoutTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogoutTime() {
        return logoutTime;
    }

    /**
     * Sets the value of the logoutTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogoutTime(String value) {
        this.logoutTime = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the provz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvz() {
        return provz;
    }

    /**
     * Sets the value of the provz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvz(String value) {
        this.provz = value;
    }

    /**
     * Gets the value of the wears property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWears() {
        return wears;
    }

    /**
     * Sets the value of the wears property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWears(String value) {
        this.wears = value;
    }

    /**
     * Gets the value of the yqzl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYqzl() {
        return yqzl;
    }

    /**
     * Sets the value of the yqzl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYqzl(String value) {
        this.yqzl = value;
    }

}
