
package com.sfbest.financial.certification.zcxfapi;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for headerDTOJR complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="headerDTOJR">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="header_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lineslist" type="{http://WService.sf.com/}linesDTOJR" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="send_error_msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="send_flg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voucher_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "headerDTOJR", propOrder = {
    "headerId",
    "lineslist",
    "sendErrorMsg",
    "sendFlg",
    "voucherNo"
})
public class HeaderDTOJR {

    @XmlElement(name = "header_id")
    protected String headerId;
    @XmlElement(nillable = true)
    protected List<LinesDTOJR> lineslist;
    @XmlElement(name = "send_error_msg")
    protected String sendErrorMsg;
    @XmlElement(name = "send_flg")
    protected String sendFlg;
    @XmlElement(name = "voucher_no")
    protected String voucherNo;

    /**
     * Gets the value of the headerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeaderId() {
        return headerId;
    }

    /**
     * Sets the value of the headerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeaderId(String value) {
        this.headerId = value;
    }

    /**
     * Gets the value of the lineslist property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lineslist property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLineslist().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LinesDTOJR }
     * 
     * 
     */
    public List<LinesDTOJR> getLineslist() {
        if (lineslist == null) {
            lineslist = new ArrayList<LinesDTOJR>();
        }
        return this.lineslist;
    }

    /**
     * Gets the value of the sendErrorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendErrorMsg() {
        return sendErrorMsg;
    }

    /**
     * Sets the value of the sendErrorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendErrorMsg(String value) {
        this.sendErrorMsg = value;
    }

    /**
     * Gets the value of the sendFlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFlg() {
        return sendFlg;
    }

    /**
     * Sets the value of the sendFlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFlg(String value) {
        this.sendFlg = value;
    }

    /**
     * Gets the value of the voucherNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoucherNo() {
        return voucherNo;
    }

    /**
     * Sets the value of the voucherNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoucherNo(String value) {
        this.voucherNo = value;
    }

}
