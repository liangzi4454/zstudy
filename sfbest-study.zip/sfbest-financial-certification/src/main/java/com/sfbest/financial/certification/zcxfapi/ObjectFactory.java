
package com.sfbest.financial.certification.zcxfapi;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.sfbest.financial.certification.zcxfapi package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetVoucherHeadersResponse_QNAME = new QName("http://WService.sf.com/", "getVoucherHeadersResponse");
    private final static QName _GetVouchersResponse_QNAME = new QName("http://WService.sf.com/", "getVouchersResponse");
    private final static QName _GetBankList_QNAME = new QName("http://WService.sf.com/", "getBankList");
    private final static QName _GetVouchers_QNAME = new QName("http://WService.sf.com/", "getVouchers");
    private final static QName _SetVoucherResponse_QNAME = new QName("http://WService.sf.com/", "setVoucherResponse");
    private final static QName _SetVoucher_QNAME = new QName("http://WService.sf.com/", "setVoucher");
    private final static QName _GetVoucherHeaders_QNAME = new QName("http://WService.sf.com/", "getVoucherHeaders");
    private final static QName _GetBankListResponse_QNAME = new QName("http://WService.sf.com/", "getBankListResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.sfbest.financial.certification.zcxfapi
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetVoucherHeadersResponse }
     * 
     */
    public GetVoucherHeadersResponse createGetVoucherHeadersResponse() {
        return new GetVoucherHeadersResponse();
    }

    /**
     * Create an instance of {@link GetVouchersResponse }
     * 
     */
    public GetVouchersResponse createGetVouchersResponse() {
        return new GetVouchersResponse();
    }

    /**
     * Create an instance of {@link GetBankList }
     * 
     */
    public GetBankList createGetBankList() {
        return new GetBankList();
    }

    /**
     * Create an instance of {@link GetVouchers }
     * 
     */
    public GetVouchers createGetVouchers() {
        return new GetVouchers();
    }

    /**
     * Create an instance of {@link SetVoucherResponse }
     * 
     */
    public SetVoucherResponse createSetVoucherResponse() {
        return new SetVoucherResponse();
    }

    /**
     * Create an instance of {@link SetVoucher }
     * 
     */
    public SetVoucher createSetVoucher() {
        return new SetVoucher();
    }

    /**
     * Create an instance of {@link GetVoucherHeaders }
     * 
     */
    public GetVoucherHeaders createGetVoucherHeaders() {
        return new GetVoucherHeaders();
    }

    /**
     * Create an instance of {@link GetBankListResponse }
     * 
     */
    public GetBankListResponse createGetBankListResponse() {
        return new GetBankListResponse();
    }

    /**
     * Create an instance of {@link InterfaceGlHeadersVO }
     * 
     */
    public InterfaceGlHeadersVO createInterfaceGlHeadersVO() {
        return new InterfaceGlHeadersVO();
    }

    /**
     * Create an instance of {@link VoucherParamDTO }
     * 
     */
    public VoucherParamDTO createVoucherParamDTO() {
        return new VoucherParamDTO();
    }

    /**
     * Create an instance of {@link LinesDTOJR }
     * 
     */
    public LinesDTOJR createLinesDTOJR() {
        return new LinesDTOJR();
    }

    /**
     * Create an instance of {@link HeaderDTOJR }
     * 
     */
    public HeaderDTOJR createHeaderDTOJR() {
        return new HeaderDTOJR();
    }

    /**
     * Create an instance of {@link InterfaceGlLinesVO }
     * 
     */
    public InterfaceGlLinesVO createInterfaceGlLinesVO() {
        return new InterfaceGlLinesVO();
    }

    /**
     * Create an instance of {@link HeaderDTO }
     * 
     */
    public HeaderDTO createHeaderDTO() {
        return new HeaderDTO();
    }

    /**
     * Create an instance of {@link BankInformationVO }
     * 
     */
    public BankInformationVO createBankInformationVO() {
        return new BankInformationVO();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVoucherHeadersResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "getVoucherHeadersResponse")
    public JAXBElement<GetVoucherHeadersResponse> createGetVoucherHeadersResponse(GetVoucherHeadersResponse value) {
        return new JAXBElement<GetVoucherHeadersResponse>(_GetVoucherHeadersResponse_QNAME, GetVoucherHeadersResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVouchersResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "getVouchersResponse")
    public JAXBElement<GetVouchersResponse> createGetVouchersResponse(GetVouchersResponse value) {
        return new JAXBElement<GetVouchersResponse>(_GetVouchersResponse_QNAME, GetVouchersResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBankList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "getBankList")
    public JAXBElement<GetBankList> createGetBankList(GetBankList value) {
        return new JAXBElement<GetBankList>(_GetBankList_QNAME, GetBankList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVouchers }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "getVouchers")
    public JAXBElement<GetVouchers> createGetVouchers(GetVouchers value) {
        return new JAXBElement<GetVouchers>(_GetVouchers_QNAME, GetVouchers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetVoucherResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "setVoucherResponse")
    public JAXBElement<SetVoucherResponse> createSetVoucherResponse(SetVoucherResponse value) {
        return new JAXBElement<SetVoucherResponse>(_SetVoucherResponse_QNAME, SetVoucherResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetVoucher }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "setVoucher")
    public JAXBElement<SetVoucher> createSetVoucher(SetVoucher value) {
        return new JAXBElement<SetVoucher>(_SetVoucher_QNAME, SetVoucher.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVoucherHeaders }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "getVoucherHeaders")
    public JAXBElement<GetVoucherHeaders> createGetVoucherHeaders(GetVoucherHeaders value) {
        return new JAXBElement<GetVoucherHeaders>(_GetVoucherHeaders_QNAME, GetVoucherHeaders.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBankListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://WService.sf.com/", name = "getBankListResponse")
    public JAXBElement<GetBankListResponse> createGetBankListResponse(GetBankListResponse value) {
        return new JAXBElement<GetBankListResponse>(_GetBankListResponse_QNAME, GetBankListResponse.class, null, value);
    }

}
