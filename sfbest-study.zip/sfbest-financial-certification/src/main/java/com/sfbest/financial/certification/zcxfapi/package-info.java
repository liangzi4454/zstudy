@javax.xml.bind.annotation.XmlSchema(namespace = "http://WService.sf.com/")
package com.sfbest.financial.certification.zcxfapi;
