package com.sfbest.financial.util;

import com.sfbest.financial.basehelper.FormatHelper;
import com.sfbest.financial.basehelper.IoHelper;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by LHY on 2017/5/18.
 */
public class ConfigurationLoader {
    private static ConcurrentHashMap<String, String> threadMap = new ConcurrentHashMap<String, String>();
    public static final String ENV_NAME = "env.name";

    public ConfigurationLoader() {
        PropertiesLoader loader = new PropertiesLoader();
        IoHelper ioHelper = new IoHelper();
        ioHelper.copyResources("classpath*:/META-INF/sfbest/config/*.properties", "config/", "/sfbest/config/");
        threadMap = loader.loadMap("config/");
    }
    /**
     * 获取所有配置文件内容
     * @param code
     * @return
     */
    public String load(String code) {
        if(code==null) {
            return "";
        }
        String env_name = threadMap.get(ENV_NAME);
        if(env_name!=null && !code.startsWith(env_name)) {
            code = env_name+"."+code;
        }
        return FormatHelper.formatString(threadMap.get(code));
    }
}