package com.sfbest.financial.util;

import java.util.Calendar;

/**
 * 获得跟日期相关的数据
 * Created by LHY on 2017/3/29.
 */
public class DateUtil {
    private static Calendar calendar = Calendar.getInstance();

    /**
     * 获得日期: 年
     * @return 年
     */
    public static int getCurrentYear() {
        return calendar.get(calendar.YEAR);
    }

    /**
     * 获得日期: 年
     * @return
     */
    public static String getCurrentYearStr() {
        return String.valueOf(getCurrentYear());
    }

    /**
     * 获取月份，0表示1月份
     * @return
     */
    public static int getCurrentMonth() {
        return calendar.get(calendar.MONTH)+1;
    }
    /**
     * 获取月份，0表示1月份
     * @return
     */
    public static String getCurrentMonthStr() {
        int month = getCurrentMonth();
        return String.valueOf(month<10?"0"+month:month);
    }

    /**
     *  获取当前天数
     * @return
     */
    public static int getCurrentDay() {
        return calendar.get(calendar.DAY_OF_MONTH);
    }

    /**
     *  获取当前天数
     * @return
     */
    public static String getCurrentDayStr() {
        int day = getCurrentDay();
        return String.valueOf(day<10?"0"+day:day);
    }

    /**
     * 获取当前小时
     * @return
     */
    public static int getCurrentHour() {
        return calendar.get(calendar.HOUR_OF_DAY);
    }
    /**
     * 获取当前小时
     * @return
     */
    public static String getCurrentHourStr() {
        int hour = getCurrentHour();
        return String.valueOf(hour<10?"0"+hour:hour);
    }

    /**
     * 获取当前分钟
     * @return
     */
    public static int getCurrentMinute() {
        return calendar.get(calendar.MINUTE);
    }
    /**
     * 获取当前分钟
     * @return
     */
    public static String getCurrentMinuteStr() {
        int minute = getCurrentMinute();
        return String.valueOf(minute<10?"0"+minute:minute);
    }

    /**
     * 获取当前秒
     * @return
     */
    public static int getCurrentSecond() {
        return calendar.get(calendar.SECOND);
    }
    /**
     * 获取当前秒
     * @return
     */
    public static String getCurrentSecondString() {
        int second = getCurrentSecond();
        return String.valueOf(second<10?"0"+second:second);
    }

    /**
     * 获取本月最小天数
     * @return
     */
    public static int getMinDayOfCurrentMonth() {
        return calendar.getActualMinimum(calendar.DAY_OF_MONTH);
    }

    /**
     * 获取本月最大天数
     * @return
     */
    public static int getMaxDayOfCurrentMonth() {
        return calendar.getActualMaximum(calendar.DAY_OF_MONTH);
    }
}