package com.sfbest.financial.util;

import com.sfbest.financial.basecom.baseclass.BaseClass;
import com.sfbest.framework.entity.DataTransferObject;
import com.sfbest.framework.util.DateUtil;
import com.sfbest.framework.util.EncryptionUtil;
import com.sfbest.message.mail.api.MailSendService;
import com.sfbest.message.mail.entity.MailInfo;
import com.sfbest.message.sms.api.SmsSendService;
import com.sfbest.message.sms.entity.MsgNotes;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * 发送邮件和短信
 * Created by LHY on 2017/4/25.
 */
@Component
public class MessageProxy extends BaseClass {
    @Resource
    private MailSendService mailSendService;
    @Resource
    private SmsSendService smsSendService;

    /**
     * 发送邮件
     * @param address 邮件地址
     * @param subject 邮件主题
     * @param content 邮件内容
     */
    public void sendEmail(List<String> address, String subject, String content) {
        try {
            String authKey = "sfbest001";
            String ip = SystemUtils.getLocalIp();
            List<MailInfo> mailInfos = new ArrayList<MailInfo>();
            for (String mail: address) {
                int timeStamp = DateUtil.currentTimeSecond();
                MailInfo mailInfo = new MailInfo();
                mailInfo.setSubject(subject);
                mailInfo.setAddress(mail);
                mailInfo.setContent(ip+"\n"+content);
                mailInfo.setTimeStamp(timeStamp);
                mailInfo.setSign(EncryptionUtil.MD5(authKey + timeStamp));
                mailInfo.setType("HOME");
                mailInfos.add(mailInfo);
            }
            DataTransferObject dto = this.mailSendService.sendMailInfos(mailInfos);
            logInfo("邮件调用服务反馈信息，code:" + dto.getCode() + " msg:" + dto.getMsg());
        } catch (Exception e) {
            logInfo("邮件发送异常: " + e);
        }
    }

    /**
     * 发送短信
     * @param mobile 手机号
     * @param content 内容
     */
    public void sendMessage(String mobile, String content) {
        MsgNotes msgnotes = new MsgNotes();
        msgnotes.setMsgType("API");
        msgnotes.setMsgContent(content);
        msgnotes.setMsgTel(mobile);
        try {
            logInfo("短信已经发送至[" + mobile + "]，内容[" + content + "]");
            DataTransferObject dto = smsSendService.sendMessage(msgnotes);
            logInfo("短信调用服务反馈信息，code:" + dto.getCode() + " msg:" + dto.getMsg());
        } catch (Exception e) {
            logError("短信发送异常"+e.getMessage());
        }
    }
}