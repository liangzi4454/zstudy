package com.sfbest.financial.util;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

import java.io.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by LHY on 2017/3/1.
 */
public class PropertiesLoader {
    /**
     * 加载属性配置
     *
     * @param sDir
     * @return
     */
    public ConcurrentHashMap<String, String> loadMap(String sDir) {
        Collection<File> files = FileUtils.listFiles((new File(sDir)), new String[]{"properties"}, true);
        return loadMapFromFiles(files);
    }
    /**
     * 从文件中读取配置文件
     * @param files
     * @return
     */
    private ConcurrentHashMap<String, String> loadMapFromFiles(Collection<File> files) {
        ConcurrentHashMap<String, String> threadMap = new ConcurrentHashMap<String, String>();
        try {
            for (File file : files) {
                PropertiesConfiguration pConfiguration = new PropertiesConfiguration();
                FileInputStream fInputStream = FileUtils.openInputStream(file);
                pConfiguration.load(fInputStream, "UTF-8");
                Iterator<String> em = pConfiguration.getKeys();
                while (em.hasNext()) {
                    String key = em.next();
                    String value = StringUtils.join(pConfiguration.getStringArray(key), ",");
                    if (!threadMap.containsKey(key)) {
                        threadMap.put(key, value);
                    }
                }
                fInputStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return threadMap;
    }

    /**
     * 配置文件顶部有@this$namespace=certification样式的命名空间
     * 从文件中读取配置文件
     * @param files
     * @return
     */
    @Deprecated
    private Map<String, String> loadMapFromFiles2(Collection<File> files) {
        Map<String, String> mReturnMap = new HashMap<String, String>();
        try {
            for (File f : files) {
                PropertiesConfiguration pConfiguration = new PropertiesConfiguration();
                FileInputStream fInputStream = FileUtils.openInputStream(f);
                pConfiguration.load(fInputStream, "utf-8");
                Iterator<String> em = pConfiguration.getKeys();
                // 定义命名空间
                String sNameSpace = StringUtils.defaultString(pConfiguration.getString("@this$namespace"), "");
                while (em.hasNext()) {
                    String sKeyString = em.next();
                    String sValueString = StringUtils.join(pConfiguration.getStringArray(sKeyString), ",");
                    //不可删除
                    if (StringUtils.isNotEmpty(sNameSpace)) {
                        if (!StringUtils.startsWith(sKeyString, "@") && !StringUtils.startsWith(sKeyString, sNameSpace)) {
                            sKeyString = sNameSpace + "." + sKeyString;
                        }
                    }
                   // 进行特殊判断模式
                    // 定义是否强制覆盖
                    boolean bOverWrite = false;
                    if (StringUtils.startsWith(sKeyString, "@")) {
                        String sTarget = StringUtils.substringBetween(sKeyString, "@", "$");
                        // 覆写配置
                        if (sTarget.equals("override")) {
                            // override
                            bOverWrite = true;
                        }
                        // 本配置指向
                        else if (sTarget.equals("this")) {

                        }
                        sKeyString = StringUtils.substringAfter(sKeyString, "$");
                    }
                    if (bOverWrite || !mReturnMap.containsKey(sKeyString)) {
                        mReturnMap.put(sKeyString, sValueString);
                    }
                }
                fInputStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mReturnMap;
    }
}