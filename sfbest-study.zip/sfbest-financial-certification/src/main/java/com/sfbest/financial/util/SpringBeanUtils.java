package com.sfbest.financial.util;

/**
 * 通过class获得spring管理的bean
 * Created by LHY on 2017/3/8.
 */
public final class SpringBeanUtils {
    /**
     * 通过class获得spring管理的bean
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T getBean(Class<T> clazz) {
        return SpringContext.getContext().getBean(clazz);
    }

    /**
     * 根据Bean的名称获得bean对象
     * @param bean 不是全路径名称
     * @return
     */
    public static Object getBean(String bean) {
        return SpringContext.getContext().getBean(bean);
    }
}