package com.sfbest.financial.util;

import org.apache.commons.lang.StringUtils;

import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.List;

public class SystemUtils {

	/**
	 * 获取本地IP地址，兼容win linux
	 * @return
	 */
	public static String getLocalIp() {
		try{
			Enumeration<NetworkInterface> inter = NetworkInterface.getNetworkInterfaces(); 
			while(inter.hasMoreElements()){
				NetworkInterface i = inter.nextElement();
				//method 2
				List<InterfaceAddress>  ads = i.getInterfaceAddresses();
				for(InterfaceAddress ad:ads){
					String ip = ad.getAddress().getHostAddress();
					if(StringUtils.isNotEmpty(ip)&&(ip.charAt(0)=='1'|| ip.charAt(0)=='2')&&!ip.equals("127.0.0.1")){
						return ip;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
}
