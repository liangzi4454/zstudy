package com.sfbest.financial.util.kafka;

import com.sfbest.financial.basecom.baseclass.BaseClass;

/**
 * kafka消息接口的抽象类,kafka将通过IKafkaMessage接口将消息传递到execute()方法
 * 实现IKafkaMessage接口的每个业务类都可以收到kafka发送的消息;为了隐藏与kafka有关
 * 的细节,建议每个业务组件都继承该抽象类,实现doExecute()方法;
 * Created by LHY on 2017/3/8.
 */
public abstract class AbstractKafkaMessage extends BaseClass implements IKafkaMessage {
    /**
     * <pre>
     * 消息接收方法,kafka消息会传递到该方法,
     * 该方法通过调用模板方法doExecute()将kafka消息传递给继承该类的业务业务对象去处理
     * </pre>
     * @param key
     * @param value kafka消息
     * @return
     */
    public boolean execute(String key, String value) {
        return this.doExecute(value);
    }

    /**
     * <pre>
     * 抽象方法:
     * 接收kafka消息实现类都需要重写该方法,该方法的实现类只是一个不同的java对象,
     * 实例化方式如同 A a = new A()的范式一样,所以该方法的实现类中spring bean无法通过注解的方式实现,
     * 因此要通过如下方式实现:
     * SpringBeanUtils.getBean(class);
     * </pre>
     * 通过该调用方式可以直接获取spring容器中的bean组件
     * @param value
     * @return
     */
    public abstract boolean doExecute(String value);
}