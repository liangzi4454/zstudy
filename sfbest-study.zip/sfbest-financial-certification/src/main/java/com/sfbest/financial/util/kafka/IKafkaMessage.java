package com.sfbest.financial.util.kafka;

/**
 * kafka消费者回调接口,实现该接口,回去消费结果
 * Created by LHY on 2017/3/8.
 */
public interface IKafkaMessage {
    boolean execute(String key, String value);
}