package com.sfbest.financial.util.kafka;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 每个线程维护一个KafkaConsumer
 * 优点:方便实现速度较快，因为不需要任何线程间交互易于维护分区内的消息顺序
 * 缺点:更多的TCP连接开销(每个线程都要维护若干个TCP连接)consumer数受限于topic分区数，扩展性差频繁请求导致吞吐量下降线程自己处理消费到的消息可能会导致超时，从而造成rebalance
 * Created by LHY on 2017/3/6.
 */
public class KafkaConsumerGroup {
    private List<KafkaConsumerRunnable> consumers;

    /*private static Map<String, KafkaConsumerRunnable> runnableMap = new HashMap<String, KafkaConsumerRunnable>();
    private static Map<String, Thread> threadMap = new HashMap<String, Thread>();

    public KafkaConsumerGroup() {}*/
    /**
     * 设置参数
     * @param consumerNum 启动线程数,该参数应该为分区partition的倍数,多个线程同时拉取数据,每个线程只处理一个分区的数据
     * @param groupId 消费者分组,当多个消费者在同一组的时候,同一组下的每个消费者从不同的分区partition上获取数据,offset位移也不同;不同组下的消费者可以获取到相同partition的offset
     * @param topic 消费者主题,表示消费者从哪个主题下拉取数据
     * @param className 回调函数，用于调用者业务处理
     */
    public KafkaConsumerGroup(int consumerNum, String groupId, String topic, String className) {
        consumers = new ArrayList<KafkaConsumerRunnable>(consumerNum);
        for (int i = 0; i < consumerNum; ++i) {
            KafkaConsumerRunnable consumerThread = new KafkaConsumerRunnable(groupId, topic, className);
            consumers.add(consumerThread);
        }

        /*for (int i = 0; i < consumerNum; ++i) {
            KafkaConsumerRunnable consumerThread = new KafkaConsumerRunnable(groupId, topic, className);
            runnableMap.put(className, consumerThread);
        }*/
    }

    /**
     * 启动线程
     */
    public void start() {
        for(KafkaConsumerRunnable task : consumers) {
            Thread thread = new Thread(task);
            thread.start();
        }

        /*for(Map.Entry<String, KafkaConsumerRunnable> entry : runnableMap.entrySet()) {
            Thread thread = new Thread(entry.getValue());
            thread.start();
            threadMap.put(entry.getKey(), thread);
        }*/
    }

    /**
     * 停止线程
     * @param className
     */
    public void stop(String className) {
        /*runnableMap.get(className).shutdown();
        threadMap.get(className).interrupt();*/
    }
}