package com.sfbest.financial.util.kafka;

import com.sfbest.financial.baseweb.RootMethod;
import com.sfbest.financial.util.ConfigurationLoader;
import com.sfbest.financial.util.SpringContext;
import org.apache.commons.lang.ClassUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;

import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 每个线程维护一个KafkaConsumer,消费者自动提交offset
 * 优点: 方便实现速度较快，因为不需要任何线程间交互易于维护分区内的消息顺序
 * 缺点: 更多的TCP连接开销(每个线程都要维护若干个TCP连接)consumer数受限于topic分区数，扩展性差频繁请求导致吞吐量下降线程自己处理消费到的消息可能会导致超时，从而造成reBalance;
 * 缺点: 消费者拉取数据的业务与消费者处理数据的业务在同一个线程中执行
 * Created by LHY on 2017/3/6.
 */
public class KafkaConsumerRunnable implements Runnable {
    /** 消费者拉取数据线程启动停止标识 **/
    private final AtomicBoolean closed = new AtomicBoolean(false);
    /** 每个线程维护私有的KafkaConsumer实例 **/
    private final KafkaConsumer<String, String> consumer;
    /** 反射回调函数 **/
    private final String className;
    /**
     * 设置参数
     * @param groupId 消费者分组,当多个消费者在同一组的时候,同一组下的每个消费者从不同的分区partition上获取数据,offset位移也不同;不同组下的消费者可以获取到相同partition的offset
     * @param topic 消费者主题,表示消费者从哪个主题下拉取数据
     * @param className 反射回调函数，用于调用者业务处理
     */
    public KafkaConsumerRunnable(String groupId, String topic, String className) {
        ConfigurationLoader loader = new ConfigurationLoader();
        Properties props = new Properties();
        props.put("bootstrap.servers", loader.load("bootstrap.servers"));
        props.put("group.id", groupId);
        props.put("enable.auto.commit", loader.load("enable.auto.commit"));
        props.put("auto.commit.interval.ms", loader.load("auto.commit.interval.ms"));
        props.put("session.timeout.ms", loader.load("session.timeout.ms"));
        props.put("key.deserializer", loader.load("key.deserializer"));
        props.put("value.deserializer", loader.load("value.deserializer"));
        this.className = className;
        this.consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList(topic));

    }
    /**
     * 运行消费者拉取数据的线程,拉取数据超时时间为1秒钟;
     * 从消费者消费的数据中可以获得消费者(生产者)的主题(topic), 分区(partition), 位移(offset), 消息主键(key), 消息数据(value)等信息
     */
    public void run() {
        try {
            IKafkaMessage iKafkaMessage = null;
            String beanName = getBeanName(ClassUtils.getShortClassName(className));
            if(SpringContext.getContext()!=null && SpringContext.getContext().containsBean(beanName)) {
                iKafkaMessage = (IKafkaMessage)SpringContext.getContext().getBean(beanName);
            } else {
                iKafkaMessage = (IKafkaMessage)RootMethod.rootMethod.upClass(className);
            }
            while (!closed.get()) {
                ConsumerRecords<String, String> records = consumer.poll(1000);
                for (ConsumerRecord<String, String> record : records) {
                    iKafkaMessage.execute(record.key(), record.value());
                }
            }
            System.out.println("线程确实停止了!!!!!!!!!!!!!!!!!!!");
        } catch (WakeupException e) {
            e.printStackTrace();
            if (!closed.get()) throw e;
        } finally {
            consumer.close();
        }
    }

    // Shutdown hook which can be called from a separate thread
    public void shutdown() {
        closed.set(true);
        consumer.wakeup();
    }

    public String getBeanName(String name) {
        return (new StringBuilder()).append(Character.toLowerCase(name.charAt(0))).append(name.substring(1)).toString();
    }
}