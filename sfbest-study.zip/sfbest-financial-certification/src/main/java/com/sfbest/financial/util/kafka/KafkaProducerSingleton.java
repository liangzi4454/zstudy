package com.sfbest.financial.util.kafka;

import java.util.concurrent.Future;

import com.sfbest.financial.util.ConfigurationLoader;
import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.producer.*;

import java.util.Properties;

/**
 * 消息生产者,单利模式
 * Created by LHY on 2017/3/1.
 */
public class KafkaProducerSingleton {
    private KafkaProducerSingleton() {}
    private static class SingletonHolder {
        private static final KafkaProducerSingleton instance = new KafkaProducerSingleton();
    }
    public static KafkaProducerSingleton getInstance() {
        return SingletonHolder.instance;
    }
    /** 消息主题 **/
    private String topic;
    /** 消息主键 **/
    private String key;
    /** 消息值 **/
    private String value;
    /** 生产者 **/
    private KafkaProducer<String, String> kafkaProducer;

    /**
     *
     * @param topic 主题
     * @param value 消息值
     * @throws Exception
     */
    public void send(String topic, String value) throws Exception {
        this.send(topic, "", value);
    }
    /**
     * 发送消息
     * @param topic 主题
     * @param key 主键
     * @param value 消息值
     * @throws Exception
     */
    public void send(String topic, String key, String value) throws Exception {
        Producer<String, String> producer = this.getProducer(null);
        ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, key, value);
        Future<RecordMetadata> future = producer.send(record, new Callback() {
            public void onCompletion(RecordMetadata metadata, Exception exception) {
                if (exception != null) {
                    exception.printStackTrace();
                }
                System.out.println("message send to partition " + metadata.partition() + ", offset: " + metadata.offset());
            }
        });
    }

    /**
     * 发送消息
     * @param topic 主题
     * @param key 主键
     * @param value 消息值
     * @param brokers broker地址
     * @throws Exception
     */
    public void send(String topic, String key, String value, String brokers) throws Exception {
        Producer<String, String> producer = this.getProducer(brokers);
        ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, key, value);
        Future<RecordMetadata> future = producer.send(record, new Callback() {
            public void onCompletion(RecordMetadata metadata, Exception exception) {
                if (exception != null) {
                    exception.printStackTrace();
                }
                System.out.println("message send to partition " + metadata.partition() + ", offset: " + metadata.offset());
            }
        });
    }

    /**
     *
     * @param brokers
     * @return
     */
    private KafkaProducer<String, String> getProducer(String brokers) {
        if (kafkaProducer == null) {
            ConfigurationLoader loader = new ConfigurationLoader();
            Properties props = new Properties();
            props.put("acks", "1");
            props.put("retries", 0);
            props.put("batch.size", 16384);
            props.put("bootstrap.servers", StringUtils.defaultIfEmpty(brokers, loader.load("bootstrap.servers")));
            props.put("serializer.class", loader.load("serializer.class"));
            props.put("key.serializer", loader.load("key.serializer"));
            props.put("value.serializer", loader.load("value.serializer"));
            kafkaProducer = new KafkaProducer<String, String>(props);
        }
        return kafkaProducer;
    }
}
