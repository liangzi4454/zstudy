package com.sfbest.financial.baseweb;

import com.sfbest.financial.certification.kafka.impl.KafkaServiceImpl;
import org.junit.Test;
import org.springframework.util.ClassUtils;

/**
 * Created by LHY on 2017/3/17.
 */
public class RootMethodTest {
    public static final RootMethod root_method = new RootMethod();
    @Test
    public void testUpClass() throws Exception {
        System.out.println(ClassUtils.getShortName(KafkaServiceImpl.class));
        System.out.println(ClassUtils.getShortNameAsProperty(KafkaServiceImpl.class));
    }
}