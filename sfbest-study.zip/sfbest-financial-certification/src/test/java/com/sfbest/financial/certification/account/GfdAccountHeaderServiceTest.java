package com.sfbest.financial.certification.account;

import com.sfbest.financial.Application;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by LHY on 2017/4/17.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class GfdAccountHeaderServiceTest {
    @Resource
    private GfdAccountHeaderService gfdAccountHeaderService;

    @Test
    public void testUpdateDealStatusByVoucherIds() throws Exception {
        List<String> voucherIds = new ArrayList<String>();
        voucherIds.add("811170414536236");
        voucherIds.add("811170414739111");
        gfdAccountHeaderService.updateDealStatusByVoucherIds(voucherIds, 2);
    }
}