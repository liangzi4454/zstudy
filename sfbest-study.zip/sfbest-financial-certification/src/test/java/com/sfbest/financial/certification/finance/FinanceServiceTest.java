package com.sfbest.financial.certification.finance;

import com.sfbest.financial.certification.processor.actuator.TemporaryStorageApiActuator;

import javax.xml.ws.Endpoint;

/**
 * Created by LHY on 2017/5/22.
 */
public class FinanceServiceTest {

    public static void main(String[] args) {
        TemporaryStorageApiActuator financeServiceApiService = new TemporaryStorageApiActuator();
        String address = "http://10.102.11.193:8080/esbservice/api/financeServiceList";
        Endpoint.publish(address, financeServiceApiService);
        System.out.println("Server ready ...");
        try {
            Thread.sleep(5 * 60 * 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Server exist ...");
        System.exit(0);
    }
}
