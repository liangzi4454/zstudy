package com.sfbest.financial.certification.kafka;

import com.alibaba.fastjson.JSON;
import com.sfbest.financial.Application;
import com.sfbest.financial.certification.processor.zmessage.TemporaryStorageResultMessage;
import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;
import com.sfbest.financial.util.SpringBeanUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by LHY on 2017/3/15.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class KafkaServiceTest {

    @Resource
    private KafkaService kafkaService;

    @Test
    public void testQuery() throws Exception {
        GfdZadminKafka kafka = kafkaService.query(1);
        System.out.println(kafka);
    }
    @Test
    public void testTemporaryStorageResultMessage() {
        List<String> result = new ArrayList<String>();
        result.add("FMS20170330100005");
        SpringBeanUtils.getBean(TemporaryStorageResultMessage.class).doExecute(JSON.toJSONString(result));
    }
}