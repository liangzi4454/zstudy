package com.sfbest.financial.util.kafka;

import com.sfbest.financial.Application;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by LHY on 2017/3/1.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("dbdev")
public class KafkaConsumersTest {
    @Test
    public void testConsumer() throws Exception {
        /*String groupId = "group1";
        String topic = "test1";
        int consumerNum = 3;
        String className = "com.sfbest.financial.certification.processor.zamessage.TemporaryStorageMessage";
        KafkaConsumerGroup kafkaConsumerGroup = new KafkaConsumerGroup(consumerNum, groupId, topic, className);
        kafkaConsumerGroup.execute();*/
    }
}