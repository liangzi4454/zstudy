package com.sfbest.financial.util.kafka;

import com.alibaba.fastjson.JSON;
import com.sfbest.financial.basehelper.TimeHelper;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by LHY on 2017/3/1.
 */
public class KafkaProducersTest {

    @Test
    public void testProducer() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        while(true) {
            map.put("startTime", TimeHelper.currentTimeSecond("2016-07-01 08:36:31"));
            map.put("endTime", TimeHelper.currentTimeSecond("2016-07-01 08:37:04"));
            KafkaProducerSingleton.getInstance().send("tms_result", "", JSON.toJSONString(map));
            Thread.sleep(1000000);
        }
    }
    @Test
    public void testProducer2() throws Exception {
        int index = 1;
        while(true) {
            List<String> result = new ArrayList<String>();
            result.add("FMS20170331100005");
            KafkaProducerSingleton.getInstance().send("ts_result", "", JSON.toJSONString(result));
            index++;
            Thread.sleep(1000000);
        }
    }
}