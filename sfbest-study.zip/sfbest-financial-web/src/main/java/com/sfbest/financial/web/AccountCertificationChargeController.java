package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.account.GfdAccountCertificationChargeService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertificationCharge;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 为生成凭证之前的中间消息设置费用编码,根据费用编码自动生成数据;
 * 该费用编码与凭证模板中的费用编码匹配才可以生成正确的凭证;
 * Created by LHY on 2017/6/7.
 */
@Controller
@RequestMapping("/account/certification/charge/")
public class AccountCertificationChargeController {
    @Resource
    private GfdAccountCertificationChargeService gfdAccountCertificationChargeService;
    /**
     * 查询模板列表信息
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        PageData<GfdAccountCertificationCharge> list = gfdAccountCertificationChargeService.queryForList(pageInfo);
        request.setAttribute("data", list);
        return "/certification/charge/list";
    }

    /**
     * 跳转到添加页面
     * @return
     */
    @RequestMapping("/add")
    public String add() {
        return "/certification/charge/add";
    }
    /**
     * 保存添加数据
     * @param gfdAccountCertificationCharge
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public String insert (GfdAccountCertificationCharge gfdAccountCertificationCharge) {
        return gfdAccountCertificationChargeService.insertSelective(gfdAccountCertificationCharge);
    }

    /**
     * 跳转到编辑页面
     * @param request
     * @return
     */
    @RequestMapping("/edit")
    public String edit(HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdAccountCertificationCharge data = gfdAccountCertificationChargeService.selectByPrimaryKey(Integer.valueOf(id));
        request.setAttribute("data", data);
        return "/certification/charge/edit";
    }
    /**
     * 保存编辑
     * @param gfdAccountCertificationCharge
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public String update (GfdAccountCertificationCharge gfdAccountCertificationCharge) {
        return gfdAccountCertificationChargeService.updateByPrimaryKeySelective(gfdAccountCertificationCharge);
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete (int id) {
        String result = gfdAccountCertificationChargeService.deleteByPrimaryKey(id);
        return result;
    }
}