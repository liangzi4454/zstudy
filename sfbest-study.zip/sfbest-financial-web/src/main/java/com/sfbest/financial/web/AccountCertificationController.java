package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.StringHelper;
import com.sfbest.financial.certification.account.GfdAccountCertificationService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCertification;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 查询出入库消息的中间结果
 * Created by LHY on 2017/3/23.
 */
@Controller
@RequestMapping("/account/certification/")
public class AccountCertificationController {
    @Resource
    private GfdAccountCertificationService gfdAccountCertificationService;
    /**
     * 查询模板列表信息
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        try {
            Map<String, Object> upMap = StringHelper.upMap(request.getParameterMap());
            PageData<GfdAccountCertification> list = gfdAccountCertificationService.queryForList(upMap, pageInfo);
            request.setAttribute("data", list);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "/certification/list";
    }

    @RequestMapping("/detail")
    public String detail(ModelMap model, HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdAccountCertification data = gfdAccountCertificationService.queryByPrimaryKey(Integer.valueOf(id));
        model.addAttribute("data", data);
        return "/certification/detail";
    }
}