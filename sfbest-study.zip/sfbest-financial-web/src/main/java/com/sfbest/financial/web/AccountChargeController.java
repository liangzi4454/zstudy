package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.account.GfdAccountChargeItemService;
import com.sfbest.financial.certification.account.GfdAccountChargeService;
import com.sfbest.financial.db.entity.gfd.GfdAccountCharge;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * 费用编码信息
 * Created by LHY on 2017/3/27.
 */
@Controller
@RequestMapping("/account/charge")
public class AccountChargeController {
    @Resource
    private GfdAccountChargeService gfdAccountChargeService;
    @Resource
    private GfdAccountChargeItemService gfdAccountChargeItemService;
    /**
     * 查询费用编码信息
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        PageData<GfdAccountCharge> list = gfdAccountChargeService.queryForList(pageInfo);
        request.setAttribute("data", list);
        return "/charge/list";
    }
    /**
     * 查询费用编码信息
     * @param model
     * @return
     */
    @RequestMapping("/list")
    public String list(ModelMap model) {
        List<GfdAccountCharge> list = gfdAccountChargeService.queryAll();
        model.addAttribute("list",list);
        return "/charge/list";
    }
    /**
     * 跳转到添加页面
     * @return
     */
    @RequestMapping("/add")
    public String add() {
        return "/charge/add";
    }
    /**
     * 保存添加数据
     * @param accountChargeItem
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public String insert (GfdAccountCharge accountChargeItem) {
        return gfdAccountChargeService.insertSelective(accountChargeItem);
    }
    /**
     * 跳转到编辑页面
     * @param request
     * @return
     */
    @RequestMapping("/edit")
    public String edit(HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdAccountCharge data = gfdAccountChargeService.selectByPrimaryKey(Integer.valueOf(id));
        request.setAttribute("data", data);
        return "/charge/edit";
    }
    /**
     * 保存编辑
     * @param accountChargeItem
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public String update (GfdAccountCharge accountChargeItem) {
        return gfdAccountChargeService.updateByPrimaryKeySelective(accountChargeItem);
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete (int id) {
        return gfdAccountChargeService.deleteByPrimaryKey(id);
    }

    /**
     * 凭证模板选择费用类型
     * @param request
     * @return
     */
    @RequestMapping("/item/find")
    @ResponseBody
    public ModelMap find(HttpServletRequest request) {
        ModelMap model = new ModelMap();
        String name = request.getParameter("name");
        List<GfdAccountCharge> list = gfdAccountChargeService.queryAllByName(name);
        model.addAttribute("list", list);
        return model;
    }

    /**
     * 根据两个外键判断该费用类型是否已经被使用
     * @param request
     * @return
     */
    @RequestMapping("/item/exist")
    @ResponseBody
    public String exist(HttpServletRequest request) {
        String id = request.getParameter("id");
        String chargeId = request.getParameter("chargeId");
        String mouldId = request.getParameter("mouldId");
        String[] aa = chargeId.split(",");
        List<Integer> list = new ArrayList<Integer>();
        for(String index: aa) {
            list.add(Integer.valueOf(index));
        }
        return gfdAccountChargeItemService.queryCountExist(Integer.valueOf(id), Integer.valueOf(mouldId), list);
    }
}