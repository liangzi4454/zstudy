package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.basehelper.StringHelper;
import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.account.GfdAccountDetailService;
import com.sfbest.financial.certification.account.GfdAccountHeaderService;
import com.sfbest.financial.db.entity.gfd.GfdAccountDetail;
import com.sfbest.financial.db.entity.gfd.GfdAccountHeader;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 查询发往NC的凭证信息,包括凭证头信息和凭证体信息
 * Created with IntelliJ IDEA.
 * User: 01237177
 * Date: 2017/3/14
 * Time: 12:26
 */
@Controller
@RequestMapping("/account/")
public class AccountController {

    @Resource
    private GfdAccountDetailService gfdAccountDetailService;
    @Resource
    private GfdAccountHeaderService gfdAccountHeaderService;
    /**
     * 查询模板列表信息:查询凭证头信息列表,通过该列表找到每项对应的凭证体列表项
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        try {
            Map<String, Object> upMap = StringHelper.upMap(request.getParameterMap());
            PageData<GfdAccountHeader> list = gfdAccountHeaderService.queryForList(upMap, pageInfo);
            request.setAttribute("data", list);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "/account/headList";
    }

    /**
     * 通过凭证头的headerSn查询到与之关联的所有凭证体信息
     * @param request
     * @param model
     * @return
     */
    @RequestMapping("/detailList")
    public String detailList(HttpServletRequest request, ModelMap model) {
        String headerSn = request.getParameter("headerSn");
        List<GfdAccountDetail> list = gfdAccountDetailService.queryAllByHeaderSn(headerSn);
        model.addAttribute("data",list);
        return "/account/detailList";
    }
}