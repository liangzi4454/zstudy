package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.account.GfdAccountMouldService;
import com.sfbest.financial.db.entity.gfd.GfdAccountMould;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 模板处理
 */
@Controller
@RequestMapping("/account/mould")
public class AccountMouldController {

    @Resource
    private GfdAccountMouldService gfdAccountMouldService;
    /**
     * 查询模板列表信息
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        PageData<GfdAccountMould> list = gfdAccountMouldService.queryForList(pageInfo);
        request.setAttribute("data", list);
        return "/mould/list";
    }

    /**
     * 跳转到添加页面
     * @return
     */
    @RequestMapping("/add")
    public String add() {
        return "/mould/add";
    }
    /**
     * 保存添加数据
     * @param gfdAccountMould
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public String insert (GfdAccountMould gfdAccountMould) {
        return gfdAccountMouldService.insertSelective(gfdAccountMould);
    }

    /**
     * 跳转到编辑页面
     * @param request
     * @return
     */
    @RequestMapping("/edit")
    public String edit(HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdAccountMould data = gfdAccountMouldService.selectByPrimaryKey(Integer.valueOf(id));
        request.setAttribute("data", data);
        return "/mould/edit";
    }
    /**
     * 保存编辑
     * @param gfdAccountMould
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public String update (GfdAccountMould gfdAccountMould) {
        return gfdAccountMouldService.updateByPrimaryKeySelective(gfdAccountMould);
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete (int id) {
        String result = gfdAccountMouldService.deleteByPrimaryKey(id);
        return result;
    }
}