package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.account.GfdAccountMouldSubjectService;
import com.sfbest.financial.db.entity.gfd.GfdAccountMouldSubject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 处理模板体信息
 * Created by LHY on 2017/3/22.
 */
@Controller
@RequestMapping("/account/mould/subject")
public class AccountMouldSubjectController {
    @Resource
    private GfdAccountMouldSubjectService gfdAccountMouldSubjectService;
    /**
     * 分页查询
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        String mouldId = request.getParameter("mouldId");
        PageData<GfdAccountMouldSubject> list = gfdAccountMouldSubjectService.queryForList(Integer.valueOf(mouldId), pageInfo);
        request.setAttribute("mouldId", mouldId);
        request.setAttribute("data", list);
        return "/mould/mouldList";
    }
    /**
     * 不分页查询
     * @param request
     * @return
     */
    @RequestMapping("/mouldList")
    public String list(HttpServletRequest request) {
        String mouldId = request.getParameter("mouldId");
        List<GfdAccountMouldSubject> list = gfdAccountMouldSubjectService.queryAll(Integer.valueOf(mouldId));
        request.setAttribute("list", list);
        request.setAttribute("mouldId", mouldId);
        return "/mould/mouldList";
    }
    /**
     * 插入数据
     * @param subject
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public String insert(GfdAccountMouldSubject subject) {
        return gfdAccountMouldSubjectService.insertSelective(subject);
    }
    /**
     * 跳转到编辑页面
     * @return
     */
    @RequestMapping("/edit")
    @ResponseBody
    public GfdAccountMouldSubject edit(HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdAccountMouldSubject data = gfdAccountMouldSubjectService.selectByPrimaryKey(Integer.valueOf(id));
        return data;
    }
    /**
     *
     * @param subject
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public String update(GfdAccountMouldSubject subject) {
        return gfdAccountMouldSubjectService.updateByPrimaryKeySelective(subject);
    }
    /**
     *
     * @param request
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete(HttpServletRequest request) {
        String id = request.getParameter("id");
        String result = gfdAccountMouldSubjectService.deleteByPrimaryKey(Integer.valueOf(id));
        return result;
    }
}