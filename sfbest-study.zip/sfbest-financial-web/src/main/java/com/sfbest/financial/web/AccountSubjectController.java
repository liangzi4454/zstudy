package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.account.GfdAccountSubjectService;
import com.sfbest.financial.db.entity.gfd.GfdAccountSubject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * NC中的科目代码
 * Created with IntelliJ IDEA.
 * User: 01237177
 * Date: 2017/3/14
 * Time: 12:26
 */
@Controller
@RequestMapping("/subject")
public class AccountSubjectController {

    @Resource
    private GfdAccountSubjectService gfdAccountSubjectService;
    /**
     * accountEntity页面
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        PageData<GfdAccountSubject> pageData = gfdAccountSubjectService.queryForList(pageInfo);
        request.setAttribute("data", pageData);
        return "/subject/list";
    }

    /**
     * 添加凭证的时候调用该方法
     * @return
     */
    @RequestMapping("/find")
    @ResponseBody
    public ModelMap find() {
        ModelMap model = new ModelMap();
        List<GfdAccountSubject> list = gfdAccountSubjectService.queryAll();
        model.addAttribute("list", list);
        return model;
    }

    /**
     * 跳转到kafka创建页面
     * @return
     */
    @RequestMapping("/add")
    public String add() {
        return "/subject/add";
    }
    /**
     * 保存数据
     * @param gfdAccountSubject
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public String insert (GfdAccountSubject gfdAccountSubject) {
        return gfdAccountSubjectService.insertSelective(gfdAccountSubject);
    }
    /**
     * 跳转到编辑页面
     * @return
     */
    @RequestMapping("/edit")
    public String edit(HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdAccountSubject subject = gfdAccountSubjectService.selectByPrimaryKey(Integer.valueOf(id));
        request.setAttribute("data", subject);
        return "/subject/edit";
    }
    /**
     * 保存编辑
     * @param gfdAccountSubject
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public String update (GfdAccountSubject gfdAccountSubject) {
        return gfdAccountSubjectService.updateByPrimaryKeySelective(gfdAccountSubject);
    }
    /**
     * 删除数据
     * @param request
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete (HttpServletRequest request) {
        String id = request.getParameter("id");
        return gfdAccountSubjectService.deleteByPrimaryKey(Integer.valueOf(id));
    }
}