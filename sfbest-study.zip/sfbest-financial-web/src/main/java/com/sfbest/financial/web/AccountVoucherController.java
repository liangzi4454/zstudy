package com.sfbest.financial.web;

import com.sfbest.financial.basehelper.TimeHelper;
import com.sfbest.financial.certification.processor.actuator.TemporaryStorageMessageActuator;
import com.sfbest.financial.certification.processor.actuator.TemporaryStorageVoucherMessageActuator;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

/**
 * 手动发送凭证的接口个
 * Created by LHY on 2017/4/14.
 */
@Controller
@RequestMapping("/account/voucher/")
public class AccountVoucherController {
    @Resource
    private TemporaryStorageMessageActuator temporaryStorageMessageActuator;

    @Resource
    private TemporaryStorageVoucherMessageActuator temporaryStorageVoucherMessageActuator;

    /**
     * 生成凭证
     * @param startTime
     * @param endTime
     * @return
     */
    @RequestMapping("/execute")
    @ResponseBody
    public String execute(String startTime, String endTime) {
        try {
            if(StringUtils.isEmpty(startTime)||StringUtils.isEmpty(endTime)) {
                return "请填写日期";
            }
            return temporaryStorageMessageActuator.execute(TimeHelper.currentTimeSecond(startTime), TimeHelper.currentTimeSecond(endTime));
        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }

    /**
     * 手动发送凭证接口
     * @param startTime
     * @param endTime
     * @return
     */
    @RequestMapping("/send")
    @ResponseBody
    public String send(String startTime, String endTime) {
        try {
            if(StringUtils.isEmpty(startTime)||StringUtils.isEmpty(endTime)) {
                return "请填写日期";
            }
            return temporaryStorageVoucherMessageActuator.execute(TimeHelper.currentTimeSecond(startTime), TimeHelper.currentTimeSecond(endTime));
        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }
}