package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.email.GfdZadminEmailService;
import com.sfbest.financial.db.entity.gfd.GfdZadminEmail;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by LHY on 2017/4/24.
 */
@Controller
@RequestMapping("/email")
public class EmailController {
    @Resource
    private GfdZadminEmailService gfdZadminEmailService;

    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        PageData<GfdZadminEmail> pageData = gfdZadminEmailService.queryForList(pageInfo);
        request.setAttribute("data", pageData);
        return "/email/list";
    }
    /**
     * 跳转到kafka创建页面
     * @return
     */
    @RequestMapping("/add")
    public String add() {
        return "/email/add";
    }
    /**
     * 新增kafka信息
     * @param gfdZadminEmail
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public String insert(GfdZadminEmail gfdZadminEmail) {
        return gfdZadminEmailService.insertSelective(gfdZadminEmail);
    }
    /**
     * 跳转到编辑页面
     * @return
     */
    @RequestMapping("/edit")
    public String edit(HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdZadminEmail data = gfdZadminEmailService.selectByPrimaryKey(Integer.valueOf(id));
        request.setAttribute("data", data);
        return "/email/edit";
    }
    /**
     * 更新kafka信息
     * @param gfdZadminEmail
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public String update(GfdZadminEmail gfdZadminEmail) {
        return gfdZadminEmailService.updateByPrimaryKeySelective(gfdZadminEmail);
    }
    /**
     * 删除信息
     * @param request
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete(HttpServletRequest request) {
        String id = request.getParameter("id");
        return gfdZadminEmailService.deleteByPrimaryKey(Integer.valueOf(id));
    }
}