package com.sfbest.financial.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * 系统首页
 * Created by LHY on 2017/3/9.
 */
@Controller
@RequestMapping("/home")
public class HomeController {
    /**
     * 跳转到首页
     * @return
     */
    @RequestMapping("/index")
    public String index() {
        return "/index";
    }
}