package com.sfbest.financial.web;

import com.sfbest.financial.baseface.PageData;
import com.sfbest.financial.baseface.PageInfo;
import com.sfbest.financial.certification.kafka.KafkaService;
import com.sfbest.financial.db.entity.gfd.GfdZadminKafka;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 实现kafka增伤改查功能
 */
@Controller
@RequestMapping("/kafka/")
public class KafkaController {

    @Resource
    private KafkaService kafkaService;

    /**
     * kafka基本信息页面
     * @param request
     * @param pageInfo
     * @return
     */
    @RequestMapping("/page")
    public String page(HttpServletRequest request, PageInfo pageInfo) {
        PageData<GfdZadminKafka> pageData = kafkaService.queryForList(pageInfo);
        request.setAttribute("data", pageData);
        return "/kafka/list";
    }

    /**
     * 跳转到kafka创建页面
     * @return
     */
    @RequestMapping("/add")
    public String add() {
        return "/kafka/add";
    }
    /**
     * 新增kafka信息
     * @param gfdZadminKafka
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public String insert(GfdZadminKafka gfdZadminKafka) {
        return kafkaService.insert(gfdZadminKafka);
    }
    /**
     * 跳转到编辑页面
     * @return
     */
    @RequestMapping("/edit")
    public String edit(HttpServletRequest request) {
        String id = request.getParameter("id");
        GfdZadminKafka data = kafkaService.query(Integer.valueOf(id));
        request.setAttribute("data", data);
        return "/kafka/edit";
    }
    /**
     * 更新kafka信息
     * @param gfdZadminKafka
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public String update(GfdZadminKafka gfdZadminKafka) {
        return kafkaService.update(gfdZadminKafka);
    }

    /**
     * 删除信息
     * @param request
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete(HttpServletRequest request) {
        String id = request.getParameter("id");
        return kafkaService.deleteByPrimaryKey(Integer.valueOf(id));
    }

    /**
     * 启动消费者线程 还有bug未处理
     * @param id
     * @return
     */
    @RequestMapping("/start/{id}")
    @ResponseBody
    public String start(@PathVariable("id") int id) throws Exception {
        return kafkaService.start(id);
    }
    /**
     * 关闭消费者线程 还未实现
     * @param id
     * @return
     */
    @RequestMapping("/stop/{id}")
    @ResponseBody
    public String stop(@PathVariable("id") int id) throws Exception {
        return kafkaService.stop(id);
    }
}