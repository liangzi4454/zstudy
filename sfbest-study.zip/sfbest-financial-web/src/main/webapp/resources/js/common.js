/*获取form表单数据*/
$.fn.serializeObject = function() {
    var o = {};
    $.each(this.serializeArray(), function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

/*主页面跳转*/
var common = {
    postAjax: function(urls, postData, callback) {
        $.ajax({
            type: "post",
            url: urls,
            data: postData,
            success: function(data) {
                if($.trim(callback)!='' && $.isFunction(callback)) {
                    callback(data);
                } else {
                    Modal.alert({content: data}).on(function(e) {
                        window.location.reload();
                    });
                }
            }
        });
    },
    func_add: function(o) {
        common.func_call(o);
    },
    func_edit: function(o) {
        common.func_call(o);
    },
    func_remove: function(o) {
        Modal.confirm({content: "确认删除该记录？"}).on(function (e) {
            common.postAjax($(o).attr("href"));
        });
        return false;
    },
    func_execute: function(o) {
        Modal.confirm({content: "确认执行该操作？"}).on(function (e) {
            common.postAjax($(o).attr("web_attr_operate_id"), $(o).parents("form").serializeObject());
        });
        return false;
    },
    func_search: function(o) {
        var e = $(o).parents("form");
        if(common.func_regex_search(e)) {
            $(e).attr("action", $(o).attr("web_attr_operate_id")).submit();
        }
    },
    func_call: function(o) {
        var e = $(o).parents("form");
        if(common.func_regex(e)) {
            common.postAjax($(o).attr("web_attr_operate_id"), $(e).serializeObject());
        }
    },
    func_regex: function(o) {
        var flag = true;
        $(o).find("[reg_exp_id]").each(function(n, m) {
            var regExpId = $(m).attr("reg_exp_id");
            var value = $(m).val();
            var reg = new RegExp(map.get(regExpId)[0]);
            if(!reg.test(value)) {
                flag = false;
                if(!$(this).parents(".form-group").children().hasClass("help-block")) {
                    $(this).parents(".form-group").append('<span class="help-block text-danger" style="color: red;">'+map.get(regExpId)[1]+'</span>');
                }
            }
        }).on("focus", function() {
            $(".help-block").remove();
        });
        return flag;
    },
    func_regex_search: function(o) {
        var flag = true;
        $(o).find("[reg_exp_id]").each(function(n, m) {
            var regExpId = $(m).attr("reg_exp_id");
            var value = $(m).val();
            if(value!="") {
                var reg = new RegExp(map.get(regExpId)[0]);
                if(!reg.test(value)) {
                    flag = false;
                    if($(m).attr("data-toggle")==undefined||$(m).attr("data-toggle").length==0) {
                        $(m).attr({"data-toggle":"tooltip", "title":map.get(regExpId)[1]}).tooltip('show');
                    } else {
                        $(m).tooltip('show');
                    }
                }
            }
            $(m).unbind("mousemove").bind("mousemove", function() {
                if($(this).attr("data-toggle")!=undefined) {
                    $(this).tooltip('destroy').removeAttr("data-toggle").removeAttr("data-original-title").removeAttr("title");
                }
            });
        });
        return flag;
    }
};