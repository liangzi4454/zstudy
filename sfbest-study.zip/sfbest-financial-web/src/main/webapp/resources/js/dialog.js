var _html = '<div class="modal">'+
    '<div class="modal-dialog" style="width:[width]px;">'+
    '<div class="modal-content">'+
    '<div class="modal-header" style="padding: 8px;"><h5 class="modal-title"><i class="fa fa-exclamation-circle"></i>[Title]</h5></div>'+
    '<div class="modal-body" style="max-height: 550px;overflow-y:auto;">'+
    '<p><form class="form-horizontal" role="form" id="modal-btn-submit-form" method="post" autocomplete="off">[Message]</form></p>'+
    '</div>'+
    '<div class="modal-footer" style="padding: 8px;">'+
    '<button type="button" class="ok btn btn-primary btn-sm" data-dismiss="[autoClose]">[BtnOk]</button>'+
    '<button type="button" class="cancel btn btn-default btn-sm" data-dismiss="modal">[BtnCancel]</button>'+
    '</div>'+
    '</div>'+
    '</div>'+
    '</div>';
/*获取form表单数据*/
$.fn.serializeObject = function() {
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};
$(function () {
    window.Modal = function () {
        var modalObj = $(_html);
        var modalHtml = modalObj.html();
        // 测试 bootstrap 居中
        modalObj.on('show.bs.modal', function() {
            var $this = $(this);
            var $modal_dialog = $this.find('.modal-dialog');
            // 关键代码，如没将modal设置为 block，则$modala_dialog.height() 为零
            $this.css('display', 'block');
            $modal_dialog.css({'margin-top': Math.max(0, ($(window).height() - $modal_dialog.height()) / 5) });
        });

        var _alert = function (options) {
            modalObj.html(modalHtml);	// 复原
            modalObj.find('.ok').removeClass('btn-success').addClass('btn-primary');
            modalObj.find('.cancel').hide();
            _dialog(options);

            return {
                on: function (callback) {
                    if (callback && callback instanceof Function) {
                        modalObj.find('.ok').click(function () { callback(true) });
                    }
                }
            };
        };

        var _confirm = function (options) {
            modalObj.html(modalHtml); // 复原
            modalObj.find('.ok').removeClass('btn-primary').addClass('btn-success');
            modalObj.find('.cancel').show();
            _dialog(options);

            return {
                on: function (callback) {
                    if (callback && callback instanceof Function) {
                        modalObj.find('.ok').click(function () { callback(true) });
                        //modalObj.find('.cancel').click(function () { callback(false) });
                    }
                }
            };
        };

        var _openDialog = function(options) {
            modalObj.html(modalHtml); // 复原
            modalObj.find('.ok').removeClass('btn-primary').addClass('btn-success');
            modalObj.find('.cancel').show();
            _dialog(options);
            var $form = $('#modal-btn-submit-form');
            $.each(options.data, function(key) {
                if(key=='accountType'||key=='debitCredit') {
                    $form.find("input[name='"+key+"']").attr('checked', false);
                    if(options.data[key]==0) {
                        $form.find("input[name='"+key+"']:first").attr('checked', true);
                    } else {
                        $form.find("input[name='"+key+"']:last").attr('checked', true);
                    }
                } else {
                    $form.find("input[name='"+key+"']").val(options.data[key]);
                }
            });
            return {
                on: function(callback) {
                    if (callback && callback instanceof Function) {
                        modalObj.find('.ok').click(function () {
                            callback($("#modal-btn-submit-form").serializeObject())
                        });
                    }
                }
            }
        };

        var _showDialog = function(options) {
            modalObj.html(modalHtml); // 复原
            modalObj.find('.ok').remove();
            modalObj.find('.cancel').show();
            _dialog(options);
            var $form = $('#modal-btn-submit-form');
            $.each(options.data, function(key) {
                if(key=='accountType'||key=='debitCredit') {
                    $form.find("input[name='"+key+"']").attr('checked', false).attr("disabled", "disabled");
                    if(options.data[key]==0) {
                        $form.find("input[name='"+key+"']:first").attr('checked', true);
                    } else {
                        $form.find("input[name='"+key+"']:last").attr('checked', true);
                    }
                } else {
                    $form.find("input[name='"+key+"']").val(options.data[key]).attr("disabled", "disabled");
                }
            });
        };

        var _dialog = function (options) {
            var ops = {
                content: "",
                title: "提示",
                btnOk: "确定",
                btnCl: "取消",
                width: 300,
                autoClose: true,
                data: {}
            };

            $.extend(ops, options);

            var reg = new RegExp("\\[([^\\[\\]]*?)\\]", 'igm');

            var html = modalObj.html().replace(reg, function (node, key) {
                return {
                    Title: ops.title,
                    Message: ops.content,
                    BtnOk: ops.btnOk,
                    BtnCancel: ops.btnCl,
                    width: ops.width,
                    autoClose: ops.autoClose==true?'modal':''
                }[key];
            });

            modalObj.html(html);
            modalObj.modal({
                backdrop: 'static'
            });
        };

        return {
            alert: _alert,
            confirm: _confirm,
            openDialog: _openDialog,
            showDialog: _showDialog
        }
    }();
});