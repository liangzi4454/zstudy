/**
 * 凭证模板类
 * @type {{}}
 */
var mould = {
    btn: {
        btnAdd: '<button type="button" class="btn btn-primary btn-sm ok" onclick="mould.add();">确定</button>',
        btnEdit: '<button type="button" class="btn btn-primary btn-sm ok" onclick="mould.update();">确定</button>',
        btnCancel: '<button type="button" class="btn btn-default btn-sm cancel" onclick="window.location = window.location">取消</button>'
    },
    init: function() {
        common.postAjax(contextPath+"/subject/find", "", function(data) {
            var _html = "";
            $(data.list).each(function() {
                _html += "<option value=" + this.subjectCode + ">" + this.subjectName + " - " + this.subjectCode +"</option>";
            });
            $('#selectPicker_subjectCode').html(_html);
            // 缺一不可
            $('#selectPicker_subjectCode').selectpicker('refresh');
            $('#selectPicker_subjectCode').selectpicker('render');
        });
    },
    //跳转到添加凭证体页面
    toAdd: function() {
        $("#myModalLabel").text("添加");
        $("#modalFooter").html(this.btn.btnAdd+this.btn.btnCancel);
    },
    //添加凭证体信息
    add: function() {
        common.postAjax(contextPath+"/account/mould/subject/insert", $("#modal-btn-submit").serializeObject());
    },
    //查看凭证体信息
    check: function(id) {
        $("#myModalLabel").text("查看");
        $("#modalFooter").html(this.btn.btnCancel);
        common.postAjax(contextPath+"/account/mould/subject/edit", {"id":id}, function(data) {
            var $form = $('#modal-btn-submit');
            $.each(data, function(key) {
                if(key=='accountType'||key=='debitCredit') {
                    $form.find("input[name='"+key+"']").attr('checked', false).attr("disabled", "disabled");
                    if(data[key]==0) {
                        $form.find("input[name='"+key+"']:first").attr('checked', true);
                    } else {
                        $form.find("input[name='"+key+"']:last").attr('checked', true);
                    }
                } else if(key=='subjectCode') {
                    $form.find('.selectpicker').selectpicker('val', data[key]).attr("disabled", "disabled");
                }  else {
                    $form.find("input[name='"+key+"']").val(data[key]).attr("disabled", "disabled");
                }
            });
        });
    },
    //编辑凭证体信息
    edit: function(id) {
        $("#myModalLabel").text("编辑");
        $("#modalFooter").html(this.btn.btnEdit+this.btn.btnCancel);
        common.postAjax(contextPath+"/account/mould/subject/edit", {"id":id}, function(data) {
            var $form = $('#modal-btn-submit');
            $.each(data, function(key) {
                if(key=='accountType'||key=='debitCredit') {
                    $form.find("input[name='"+key+"']").attr('checked', false);
                    if(data[key]==0) {
                        $form.find("input[name='"+key+"']:first").attr('checked', true);
                    } else {
                        $form.find("input[name='"+key+"']:last").attr('checked', true);
                    }
                } else if(key=='subjectCode') {
                    $form.find('.selectpicker').selectpicker('val', data[key]);
                } else {
                    $form.find("input[name='"+key+"']").val(data[key]);
                }
            });
        });
    },
    update: function() {
        common.postAjax(contextPath+"/account/mould/subject/update", $("#modal-btn-submit").serializeObject());
    }
}