var formatter = {
    40020001: ["[0-9]{4}", "有且只能输入至少4位数字"],
    40020002: ["[a-zA-Z0-9]", "请输入字母数字"],
    40020003: ["[\u4e00-\u9fa5_a-zA-Z0-9]", "不能有特殊字符"]
};
var map = new Map();
$.each(eval(formatter), function(key, value) {
    map.put(key, value);
});

window.alert = function (msg, title, callback) {
    if (!title) {
        title = '对话框';
    }
    var _html = '<div id="selfAlert" class="modal">';
    _html += '<div class="modal-dialog" style="width:[width]px;">';
    _html += '<div class="modal-content">';
    _html += '<div class="modal-header" style="padding: 8px;">';
    _html += '<h5 class="modal-title"><i class="fa fa-exclamation-circle"></i>[Title]</h5>';
    _html += '</div>';
    _html += '<div class="modal-body" style="max-height: 550px;overflow-y:auto;">';
    _html += msg;
    _html += '</div>';
    _html += '<div class="modal-footer" style="padding: 8px;">';
    _html += '<button type="button" class="btn btn-primary btn-sm ok" data-dismiss="[autoClose]">[BtnOk]</button>';
    _html += '<button type="button" class="btn btn-default btn-sm cancel" data-dismiss="modal">[BtnCancel]</button>';
    _html += '</div>';
    _html += '</div>';
    _html += '</div>';
    _html += '</div>';

    if ($('#selfAlert').length <= 0) {
        $('body').append(_html);
    }

    $('#selfAlert').on('hidden.bs.modal', function () {
        $('#selfAlert').remove();
        if (typeof callback == 'function') {
            callback();
        }
    }).modal('show');
}