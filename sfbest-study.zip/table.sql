/*
SQLyog Ultimate v11.24 (32 bit)
MySQL - 5.6.31 : Database - gfd_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `gfd_account_certification` */

DROP TABLE IF EXISTS `gfd_account_certification`;

CREATE TABLE `gfd_account_certification` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `bill_code` varchar(20) NOT NULL DEFAULT '' COMMENT '账单编号,同发票编号,自己生成',
  `invoice_code` varchar(21) NOT NULL DEFAULT '' COMMENT '发票编号,同账单编号',
  `customer_code` varchar(22) DEFAULT '' COMMENT '月结卡号,C0000+供应商编号',
  `zone_code` varchar(23) DEFAULT 'SSM7551' COMMENT '月结卡号对应的网点,默认:SSM7551',
  `vip_code` varchar(24) NOT NULL DEFAULT '' COMMENT '集团客户编码(结算账号):A0000+供应商编码',
  `vip_zone_code` varchar(25) NOT NULL DEFAULT 'SSM7551' COMMENT '结算账号对应的网点,默认:SSM7551',
  `gl_dt` int(11) NOT NULL DEFAULT '0' COMMENT '总账日期:验收日期',
  `bill_end_inv_flg` tinyint(4) NOT NULL DEFAULT '1' COMMENT '完整帐期标志(0-非完整帐期发票，1-完整帐期发票),固定值1',
  `start_dt` int(11) NOT NULL DEFAULT '0' COMMENT '发票开始日期 ',
  `end_dt` int(11) NOT NULL DEFAULT '0' COMMENT '发票结束日期',
  `bill_start_dt` int(11) DEFAULT NULL COMMENT '账期开始日期 ',
  `bill_end_dt` int(11) DEFAULT NULL COMMENT '账期结束日期',
  `bill_period` int(11) DEFAULT NULL COMMENT '账期',
  `payment_term` int(11) NOT NULL DEFAULT '30' COMMENT '付款条件(必须为数字),固定值30',
  `payment_due_dt` int(11) NOT NULL DEFAULT '0' COMMENT '到期日 ',
  `vktyp` tinyint(4) NOT NULL DEFAULT '2' COMMENT '合同帐户类别，默认2',
  `main_transaction` varchar(36) NOT NULL DEFAULT '' COMMENT '行项目主业务',
  `sub_transaction` varchar(37) NOT NULL DEFAULT '' COMMENT '凭证项的分事务 ',
  `bill_version_no` tinyint(4) NOT NULL DEFAULT '1' COMMENT '账单版本号,固定值1',
  `amount` decimal(16,2) NOT NULL DEFAULT '0.00' COMMENT '总计输入金额(单位:元)',
  `currency_code` varchar(5) NOT NULL DEFAULT 'CNY' COMMENT '货币码 ',
  `receipt_batch_number` varchar(30) NOT NULL DEFAULT '' COMMENT '收款批次号 ',
  `bu_type` varchar(2) NOT NULL DEFAULT 'SY' COMMENT 'bu类型',
  `source_sys` varchar(15) NOT NULL DEFAULT 'FMS' COMMENT '系统来源,默认FMS',
  `bill_cnt` int(11) NOT NULL DEFAULT '1' COMMENT '账单行记录数',
  `unique_id` varchar(30) NOT NULL DEFAULT '' COMMENT 'ecbil记录唯一id:FMS+27位流水',
  `bg_code` varchar(10) NOT NULL DEFAULT 'B04' COMMENT 'bg代码:固定值B04',
  `tax_code` varchar(47) NOT NULL DEFAULT '' COMMENT '销售/购买税代码 ',
  `tax` tinyint(4) NOT NULL DEFAULT '0' COMMENT '税率',
  `depart` varchar(4) NOT NULL DEFAULT '30' COMMENT '部门:固定值30',
  `supplier_number` varchar(10) NOT NULL DEFAULT '' COMMENT '供应商编码',
  `io_number` varchar(25) NOT NULL COMMENT '出入库单号',
  `charge_item_code` varchar(20) NOT NULL DEFAULT '' COMMENT '费用类型',
  `region_type_code` varchar(10) NOT NULL DEFAULT '01' COMMENT '拆税区域类型:固定值01',
  `tax_rule_code` varchar(51) NOT NULL DEFAULT '' COMMENT '拆税规则代码',
  `deal_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '处理状态:0未处理,1已处理,2处理失败',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=855 DEFAULT CHARSET=utf8 COMMENT='物资出入库,采购盘点等做账的中间表';

/*Data for the table `gfd_account_certification` */

insert  into `gfd_account_certification`(`id`,`bill_code`,`invoice_code`,`customer_code`,`zone_code`,`vip_code`,`vip_zone_code`,`gl_dt`,`bill_end_inv_flg`,`start_dt`,`end_dt`,`bill_start_dt`,`bill_end_dt`,`bill_period`,`payment_term`,`payment_due_dt`,`vktyp`,`main_transaction`,`sub_transaction`,`bill_version_no`,`amount`,`currency_code`,`receipt_batch_number`,`bu_type`,`source_sys`,`bill_cnt`,`unique_id`,`bg_code`,`tax_code`,`tax`,`depart`,`supplier_number`,`io_number`,`charge_item_code`,`region_type_code`,`tax_rule_code`,`deal_status`,`create_time`,`modified_time`) values (854,'FMS20170606100014','FMS20170606100014','C000080027','SSM7551','C000080027','SSM7551',1467333391,1,1467333391,1467333391,1467333391,1467333391,1467333391,30,1467333391,2,'','',1,'8432.00','CNY','','SY','FMS',1,'FMS201706061000142249350363476','B04','',0,'30','80027','106516063005668640','CTSA','01','',0,1496746566,'2017-06-06 18:56:06');

/*Table structure for table `gfd_account_certification_charge` */

DROP TABLE IF EXISTS `gfd_account_certification_charge`;

CREATE TABLE `gfd_account_certification_charge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_name` varchar(50) NOT NULL DEFAULT '' COMMENT '业务类名称,中文',
  `class_name` varchar(100) NOT NULL DEFAULT '' COMMENT '业务全类名,英文',
  `charge_item_codes` varchar(100) NOT NULL DEFAULT '' COMMENT '费用类型编码,逗号分隔',
  `description` varchar(500) DEFAULT '' COMMENT '业务描述',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='凭证中间业务数据配置';

/*Data for the table `gfd_account_certification_charge` */

insert  into `gfd_account_certification_charge`(`id`,`work_name`,`class_name`,`charge_item_codes`,`description`,`create_time`,`modified_time`) values (1,'深电(购销)采购业务(无预付款) - 暂估入库','com.sfbest.financial.certification.certification.impl.DealerTemporaryStorage','CTSA,CTSB','深电(购销)采购业务(无预付款) - 暂估入库',1496718975,'2017-06-07 10:41:56'),(3,'代销商品入库-发票未到','com.sfbest.financial.certification.certification.impl.AgentTemporaryStorage','CTSB','代销商品入库-发票未到',1496802403,'2017-06-07 10:43:36');

/*Table structure for table `gfd_account_charge` */

DROP TABLE IF EXISTS `gfd_account_charge`;

CREATE TABLE `gfd_account_charge` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `charge_item_code` varchar(20) NOT NULL DEFAULT '' COMMENT '费用类型',
  `charge_item_name` varchar(100) DEFAULT '' COMMENT '费用名称',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_CHARGE_ITEM_CODE` (`charge_item_code`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='费用类型表,模板表';

/*Data for the table `gfd_account_charge` */

insert  into `gfd_account_charge`(`id`,`charge_item_code`,`charge_item_name`,`create_time`,`modified_time`) values (21,'CTSA','CTSA',1496374505,'2017-06-02 11:35:05'),(22,'CTSB','CTSB',1496718975,'2017-06-06 11:16:15');

/*Table structure for table `gfd_account_charge_item` */

DROP TABLE IF EXISTS `gfd_account_charge_item`;

CREATE TABLE `gfd_account_charge_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `charge_id` int(11) NOT NULL DEFAULT '0' COMMENT '费用类型',
  `mould_id` int(11) NOT NULL DEFAULT '0' COMMENT '模板外键',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COMMENT='模板主表,该表与费用类型表关联';

/*Data for the table `gfd_account_charge_item` */

insert  into `gfd_account_charge_item`(`id`,`charge_id`,`mould_id`,`create_time`,`modified_time`) values (78,21,27,1496746016,'2017-06-06 18:46:56');

/*Table structure for table `gfd_account_detail` */

DROP TABLE IF EXISTS `gfd_account_detail`;

CREATE TABLE `gfd_account_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `detail_sn` varchar(20) NOT NULL DEFAULT '' COMMENT '凭证主体编码（发送给NC的ID）',
  `header_sn` varchar(20) NOT NULL DEFAULT '' COMMENT '凭证头编号',
  `bill_id` varchar(25) NOT NULL DEFAULT '' COMMENT '业务单据编号',
  `bill_type` varchar(15) DEFAULT '' COMMENT '原始单据类型',
  `bill_date` date DEFAULT NULL COMMENT '原始单据日期',
  `account_type` varchar(2) DEFAULT 'F' COMMENT '总账类型：F财务账、M管理账',
  `entry_id` int(15) NOT NULL DEFAULT '0' COMMENT '分录号，不能为空',
  `subject_code` varchar(20) NOT NULL DEFAULT '' COMMENT '科目编码，不能为空',
  `summary` varchar(150) NOT NULL DEFAULT '' COMMENT '摘要，如CCP收款单凭证，不能为空',
  `settlement` varchar(15) DEFAULT '' COMMENT '结算方式',
  `doucument_id` varchar(15) DEFAULT '' COMMENT '票据号',
  `document_date` varchar(15) DEFAULT '' COMMENT '票据日期',
  `currency` varchar(10) DEFAULT '' COMMENT '币种，不能为空',
  `unit_price` decimal(12,2) DEFAULT '0.00' COMMENT '单价',
  `exchange_rate1` decimal(8,2) DEFAULT '0.00' COMMENT '汇率1，主辅币核算时使用，折辅汇率',
  `exchange_rate2` decimal(8,2) DEFAULT '0.00' COMMENT '汇率2，折本汇率',
  `debit_cnt` int(8) DEFAULT '0' COMMENT '借方数量',
  `primary_debit_amount` decimal(12,2) DEFAULT '0.00' COMMENT '原币借方发生额，不能为空',
  `secondary_debit_amount` decimal(12,2) DEFAULT '0.00' COMMENT '辅币借方发生额',
  `natural_debit_currency` decimal(12,2) DEFAULT '0.00' COMMENT '本币借方发生额，不能为空',
  `credit_cnt` int(8) DEFAULT '0' COMMENT '贷方数量',
  `primary_credit_amount` decimal(12,2) DEFAULT '0.00' COMMENT '原币贷方发生额，不能为空',
  `secondary_credit_amount` decimal(12,2) DEFAULT '0.00' COMMENT '辅币贷方发生额',
  `natural_credit_currency` decimal(12,2) DEFAULT '0.00' COMMENT '本币贷方发生额，不能为空',
  `debit_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '借贷类型：0借，1贷',
  `process_no` varchar(20) NOT NULL DEFAULT '0' COMMENT '处理批次号',
  `send_error_msg` varchar(4000) DEFAULT '' COMMENT '发送错误信息，备用字段',
  `send_flag` tinyint(1) DEFAULT '0' COMMENT '状态标示，备用字段',
  `nc_ts` varchar(19) DEFAULT '' COMMENT '时间戳，NC特有字段',
  `work_center` varchar(15) DEFAULT '' COMMENT '辅助核算：作业中心',
  `work_network` varchar(15) DEFAULT '' COMMENT '辅助核算：网点编码',
  `ITEM1` varchar(150) DEFAULT '' COMMENT '辅助核算：客商编码',
  `ITEM2` varchar(150) DEFAULT '' COMMENT '辅助核算：人员编码',
  `ITEM3` varchar(150) DEFAULT '' COMMENT '辅助核算: 银行账户',
  `ITEM4` varchar(150) DEFAULT '' COMMENT '辅助核算: 项目代码',
  `ITEM5` varchar(150) DEFAULT '' COMMENT '辅助核算: 收入类型',
  `ITEM6` varchar(150) DEFAULT '' COMMENT '辅助核算: 车牌号码',
  `ITEM7` varchar(150) DEFAULT '' COMMENT '辅助核算: 存货分类(固定值:SP040002)',
  `ITEM8` varchar(150) DEFAULT '' COMMENT '辅助核算: 发票类型',
  `ITEM9` varchar(150) DEFAULT '' COMMENT '辅助核算: 现金流量项目',
  `ITEM10` varchar(150) DEFAULT '' COMMENT '辅助核算: 待抵扣进项税类型',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已删除：0未删除，1已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_DETAIL_SN` (`detail_sn`)
) ENGINE=InnoDB AUTO_INCREMENT=474 DEFAULT CHARSET=utf8 COMMENT='凭证详情';

/*Data for the table `gfd_account_detail` */

insert  into `gfd_account_detail`(`id`,`detail_sn`,`header_sn`,`bill_id`,`bill_type`,`bill_date`,`account_type`,`entry_id`,`subject_code`,`summary`,`settlement`,`doucument_id`,`document_date`,`currency`,`unit_price`,`exchange_rate1`,`exchange_rate2`,`debit_cnt`,`primary_debit_amount`,`secondary_debit_amount`,`natural_debit_currency`,`credit_cnt`,`primary_credit_amount`,`secondary_credit_amount`,`natural_credit_currency`,`debit_type`,`process_no`,`send_error_msg`,`send_flag`,`nc_ts`,`work_center`,`work_network`,`ITEM1`,`ITEM2`,`ITEM3`,`ITEM4`,`ITEM5`,`ITEM6`,`ITEM7`,`ITEM8`,`ITEM9`,`ITEM10`,`create_time`,`modified_time`,`is_deleted`) values (465,'812170606668487','811170606473744','FMS20170606100012','27','2017-06-06','F',1,'140501','期间+商品入库+单据号','','','','CNY','0.00','10.00','10.00',0,'8432.00','0.00','8432.00',0,'0.00','0.00','0.00',0,'170606441568244','',0,'','','','','','','','','','','','','',1496745546,'2017-06-06 18:39:06',0),(466,'812170606803537','811170606473744','FMS20170606100012','27','2017-06-06','F',2,'12210112','期间+采购商品预计进项税','','','','CNY','0.00','10.00','10.00',0,'0.00','0.00','0.00',0,'0.00','0.00','0.00',0,'170606441568244','',0,'','','','','','','','','','','','','',1496745546,'2017-06-06 18:39:06',0),(467,'812170606822773','811170606473744','FMS20170606100012','27','2017-06-06','F',3,'22020121','期间+商品入库+单据号','','','','CNY','0.00','12.00','12.00',0,'0.00','0.00','0.00',0,'8432.00','0.00','8432.00',1,'170606441568244','',0,'','','','','','','','','','','','','',1496745546,'2017-06-06 18:39:06',0),(468,'812170606703219','811170606263618','FMS20170606100013','27','2017-06-06','F',1,'140501','期间+商品入库+单据号','','','','CNY','0.00','10.00','10.00',0,'8432.00','0.00','8432.00',0,'0.00','0.00','0.00',0,'170606447790934','',0,'','','','','','','','','','','','','',1496745646,'2017-06-06 18:40:46',0),(469,'812170606319126','811170606263618','FMS20170606100013','27','2017-06-06','F',2,'12210112','期间+采购商品预计进项税','','','','CNY','0.00','10.00','10.00',0,'0.00','0.00','0.00',0,'0.00','0.00','0.00',0,'170606447790934','',0,'','','','','','','','','','','','','',1496745646,'2017-06-06 18:40:46',0),(470,'812170606279383','811170606263618','FMS20170606100013','27','2017-06-06','F',3,'22020121','期间+商品入库+单据号','','','','CNY','0.00','12.00','12.00',0,'0.00','0.00','0.00',0,'8432.00','0.00','8432.00',1,'170606447790934','',0,'','','','','','','','','','','','','',1496745646,'2017-06-06 18:40:46',0),(471,'812170606717832','811170606503145','FMS20170606100014','27','2017-06-06','F',1,'140501','期间+商品入库+单据号','','','','CNY','0.00','10.00','10.00',0,'8432.00','0.00','8432.00',0,'0.00','0.00','0.00',0,'170606294776491','',0,'','','','','','','','','','','','','',1496746567,'2017-06-06 18:56:07',0),(472,'812170606987181','811170606503145','FMS20170606100014','27','2017-06-06','F',2,'12210112','期间+采购商品预计进项税','','','','CNY','0.00','10.00','10.00',0,'0.00','0.00','0.00',0,'0.00','0.00','0.00',0,'170606294776491','',0,'','','','','','','','','','','','','',1496746567,'2017-06-06 18:56:07',0),(473,'812170606496778','811170606503145','FMS20170606100014','27','2017-06-06','F',3,'22020121','期间+商品入库+单据号','','','','CNY','0.00','12.00','12.00',0,'0.00','0.00','0.00',0,'8432.00','0.00','8432.00',1,'170606294776491','',0,'','','','','','','','','','','','','',1496746567,'2017-06-06 18:56:07',0);

/*Table structure for table `gfd_account_header` */

DROP TABLE IF EXISTS `gfd_account_header`;

CREATE TABLE `gfd_account_header` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `header_sn` varchar(20) NOT NULL DEFAULT '' COMMENT '凭证头编号（发送给NC的ID）',
  `bill_id` varchar(25) NOT NULL DEFAULT '' COMMENT '业务单据编号',
  `account_type` varchar(2) NOT NULL DEFAULT 'F' COMMENT '总账类型：F财务账、M管理账，不能为空',
  `company_code` varchar(20) NOT NULL DEFAULT '' COMMENT '公司代码，如C102，不能为空',
  `voucher_type` varchar(15) NOT NULL DEFAULT '' COMMENT '凭证类型，如记账凭证，不能为空',
  `fiscal_year` char(4) NOT NULL DEFAULT '' COMMENT '会计年度（YYYY），不能为空',
  `fiscal_month` char(2) NOT NULL DEFAULT '' COMMENT '会计期间（MM），不能为空',
  `voucher_id` int(8) NOT NULL DEFAULT '0' COMMENT '凭证号，不能为空',
  `attachment_num` int(8) NOT NULL DEFAULT '0' COMMENT '附单据数，不能为空',
  `making_date` date NOT NULL COMMENT '制单日期，不能为空',
  `making_man` varchar(15) NOT NULL DEFAULT '' COMMENT '制单人，默认虚拟制单人：999999，不能为空',
  `cashier` varchar(15) DEFAULT '' COMMENT '出纳',
  `is_signature` char(1) NOT NULL DEFAULT 'N' COMMENT '是否已签字，不能为空，默认为N',
  `posting_date` date DEFAULT NULL COMMENT '记账日期',
  `posting_man` varchar(12) DEFAULT '' COMMENT '记账人',
  `source_system` varchar(15) DEFAULT '' COMMENT '来源系统，如CCP/CBIL/CBE，不能为空',
  `memo1` varchar(150) DEFAULT '',
  `xml_serialnum` int(20) DEFAULT '0' COMMENT '生成XML文件序列号，备用字段，为空',
  `xml_time` date DEFAULT NULL COMMENT '生成XML文件时间，备用字段，为空',
  `process_no` varchar(20) NOT NULL DEFAULT '0' COMMENT '处理批次号',
  `send_err_msg` varchar(4000) DEFAULT '' COMMENT '发送错误信息，备用字段',
  `send_flag` tinyint(1) DEFAULT '0' COMMENT '状态标示，备用字段',
  `red_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '红冲标识：0正常，1红冲',
  `deal_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '凭证处理状态：0单据生成，1发送成功，2发送失败，3处理成功，4处理失败',
  `nc_ts` varchar(19) DEFAULT '' COMMENT '时间戳，NC特有字段',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已删除：0未删除，1已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_HEADER_SN` (`header_sn`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8 COMMENT='凭证头信息';

/*Data for the table `gfd_account_header` */

insert  into `gfd_account_header`(`id`,`header_sn`,`bill_id`,`account_type`,`company_code`,`voucher_type`,`fiscal_year`,`fiscal_month`,`voucher_id`,`attachment_num`,`making_date`,`making_man`,`cashier`,`is_signature`,`posting_date`,`posting_man`,`source_system`,`memo1`,`xml_serialnum`,`xml_time`,`process_no`,`send_err_msg`,`send_flag`,`red_flag`,`deal_status`,`nc_ts`,`create_time`,`modified_time`,`is_deleted`) values (159,'811170606503145','FMS20170606100014','F','A301','记账凭证','2017','06',30,0,'2017-06-06','999999','','N','2017-06-06','','FMS','',0,NULL,'170606294776491','',0,0,2,'',1496746567,'2017-06-07 16:00:09',0);

/*Table structure for table `gfd_account_mould` */

DROP TABLE IF EXISTS `gfd_account_mould`;

CREATE TABLE `gfd_account_mould` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `mould_name` varchar(50) NOT NULL DEFAULT '' COMMENT '模板名称',
  `description` varchar(500) NOT NULL DEFAULT '' COMMENT '模板描述',
  `company_code` varchar(20) NOT NULL DEFAULT '' COMMENT '公司编码',
  `company_name` varchar(50) NOT NULL DEFAULT '' COMMENT '公司名称',
  `debit_number` tinyint(4) NOT NULL DEFAULT '0' COMMENT '借的数量',
  `credit_number` tinyint(4) NOT NULL DEFAULT '0' COMMENT '贷的数量',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序,首先根据该字段排序,然后根据创建日期排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_ACCOUNT_ENTRY` (`mould_name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='凭证模板表,当创建模板时关联费用类型表';

/*Data for the table `gfd_account_mould` */

insert  into `gfd_account_mould`(`id`,`mould_name`,`description`,`company_code`,`company_name`,`debit_number`,`credit_number`,`sort`,`create_time`,`modified_time`) values (27,'测试1','暂估入库','A301','顺丰科技',2,1,1,1490239003,'2017-03-31 10:52:09');

/*Table structure for table `gfd_account_mould_subject` */

DROP TABLE IF EXISTS `gfd_account_mould_subject`;

CREATE TABLE `gfd_account_mould_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `mould_id` int(11) NOT NULL DEFAULT '0' COMMENT '模板表id',
  `subject_code` varchar(10) NOT NULL DEFAULT '' COMMENT '科目编码',
  `subject_summary` varchar(256) NOT NULL DEFAULT '' COMMENT '摘要信息',
  `currency_symbol` varchar(10) NOT NULL DEFAULT '' COMMENT '标准货币符号,如CNY',
  `ex_rate1` int(11) NOT NULL DEFAULT '0' COMMENT '汇率1',
  `ex_rate2` int(11) NOT NULL DEFAULT '0' COMMENT '汇率2',
  `formula` varchar(256) NOT NULL DEFAULT '' COMMENT '计算公式,存储json格式',
  `account_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '记账类型：0记账凭证，1收付凭证',
  `debit_credit` tinyint(4) DEFAULT '0' COMMENT '借贷方向: 0借,1贷',
  `item1` varchar(150) DEFAULT '' COMMENT '辅助核算：客商编码',
  `item2` varchar(150) DEFAULT '' COMMENT '辅助核算：人员编码',
  `item3` varchar(150) DEFAULT '' COMMENT '辅助核算: 银行账户',
  `item4` varchar(150) DEFAULT '' COMMENT '辅助核算: 项目代码',
  `item5` varchar(150) DEFAULT '' COMMENT '辅助核算: 收入类型',
  `item6` varchar(150) DEFAULT '' COMMENT '辅助核算: 车牌号码',
  `item7` varchar(150) DEFAULT '' COMMENT '辅助核算: 存货分类(固定值:SP040002)',
  `item8` varchar(150) DEFAULT '' COMMENT '辅助核算: 发票类型',
  `item9` varchar(150) DEFAULT '' COMMENT '辅助核算: 现金流量项目',
  `item10` varchar(150) DEFAULT '' COMMENT '辅助核算: 待抵扣进项税类型',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序,首先根据该字段排序,然后根据创建日期排序',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='模板表的子表,记录模板的原子信息';

/*Data for the table `gfd_account_mould_subject` */

insert  into `gfd_account_mould_subject`(`id`,`mould_id`,`subject_code`,`subject_summary`,`currency_symbol`,`ex_rate1`,`ex_rate2`,`formula`,`account_type`,`debit_credit`,`item1`,`item2`,`item3`,`item4`,`item5`,`item6`,`item7`,`item8`,`item9`,`item10`,`sort`,`modified_time`,`create_time`) values (7,27,'12210112','期间+采购商品预计进项税','CNY',10,10,'#{CTSA.amount-(CTSA.amount/(1+CTSA.tax))}',1,0,'','','','','','','','','','',2,'2017-04-05 11:48:02',1490342550),(8,27,'140501','期间+商品入库+单据号','CNY',10,10,'#{CTSA.amount/(1+CTSA.tax)}',0,0,'','','','','','','','','','',1,'2017-04-05 11:47:53',1490342631),(9,27,'22020121','期间+商品入库+单据号','CNY',12,12,'#{CTSA.amount}',0,1,'C0001','C0001','','','','','SP040002','','','',3,'2017-06-06 18:39:46',1490591355);

/*Table structure for table `gfd_account_subject` */

DROP TABLE IF EXISTS `gfd_account_subject`;

CREATE TABLE `gfd_account_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `subject_code` varchar(10) NOT NULL DEFAULT '' COMMENT '科目编码, NC中的科目编码',
  `subject_name` varchar(50) NOT NULL DEFAULT '' COMMENT '科目名称, NC中的科目名称',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_SUBJECT_CODE` (`subject_code`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COMMENT='该表中记录的为NC中的科目代码';

/*Data for the table `gfd_account_subject` */

insert  into `gfd_account_subject`(`id`,`subject_code`,`subject_name`,`create_time`,`modified_time`) values (2,'12210112','其他应收款-单位往来-预计进项税',1489635000,'2017-03-17 11:33:56'),(3,'22020121','应付账款-单位往来-商品款暂估',1489635000,'2017-03-17 11:34:58'),(16,'12210120','其他应收款-单位往来-待抵扣进项税',1489917373,'2017-03-19 18:27:59'),(17,'22020117','应付账款-单位往来-商品款',1489917373,'2017-03-19 17:57:33'),(18,'11220113','应收账款-单位往来-返点收入',1489917459,'2017-03-19 17:58:58'),(19,'64012101','主营业务成本-销售成本-商品款',1489917503,'2017-03-19 17:59:43'),(22,'12210299','其他应收款-单位往来-其他',1489917681,'2017-03-19 18:02:41'),(23,'605108','其他业务收入-商品促销收入',1489917759,'2017-03-19 18:03:59'),(24,'2221101304','应交税费-增值税-销项税额-6%',1489917817,'2017-03-19 18:04:56'),(26,'605199','其他业务收入-其他',1489917878,'2017-03-19 18:05:58'),(28,'22410101','其他应付款-单位往来-暂收款',1489917967,'2017-03-19 18:07:26'),(29,'22410104','其他应付款-单位往来-保证金',1489918314,'2017-03-19 18:13:14'),(31,'630105','营业外收入-赔偿收入',1489918417,'2017-03-19 18:14:57'),(35,'630104','营业处收入-罚款收入',1489918702,'2017-03-19 18:19:41'),(37,'1002','银行存款',1489918779,'2017-03-19 18:20:59'),(52,'140501','库存商品-库存商品',1490321092,'2017-04-18 11:37:37');

/*Table structure for table `gfd_task_schedule` */

DROP TABLE IF EXISTS `gfd_task_schedule`;

CREATE TABLE `gfd_task_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `task_key` varchar(100) NOT NULL COMMENT '任务编号',
  `task_name` varchar(100) NOT NULL COMMENT '任务名称',
  `last_exec_time` int(11) NOT NULL COMMENT '操作时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8 COMMENT='定时任务时间记录表';

/*Data for the table `gfd_task_schedule` */

insert  into `gfd_task_schedule`(`id`,`task_key`,`task_name`,`last_exec_time`,`modified_time`,`add_time`) values (227,'IO_FLOWING_WATER','流水单据处理',1475511000,'2016-12-20 15:37:59',1450345801);

/*Table structure for table `gfd_zadmin_email` */

DROP TABLE IF EXISTS `gfd_zadmin_email`;

CREATE TABLE `gfd_zadmin_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '邮件名称',
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '邮件编码',
  `user_name` varchar(50) NOT NULL DEFAULT '' COMMENT '用户名称',
  `user_email` varchar(50) DEFAULT '' COMMENT '用户邮件',
  `mobile_phone` varchar(11) DEFAULT '' COMMENT '手机号',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '编辑时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='邮件配置';

/*Data for the table `gfd_zadmin_email` */

insert  into `gfd_zadmin_email`(`id`,`name`,`code`,`user_name`,`user_email`,`mobile_phone`,`create_time`,`modified_time`) values (1,'中间消息','tms_result','梁弘扬','liang.hongyang@sf-express.com','18511914454',1495595775,'2017-04-24 18:48:05');

/*Table structure for table `gfd_zadmin_kafka` */

DROP TABLE IF EXISTS `gfd_zadmin_kafka`;

CREATE TABLE `gfd_zadmin_kafka` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '名称描述',
  `topic` varchar(20) NOT NULL DEFAULT '' COMMENT '主题',
  `group_id` varchar(20) NOT NULL DEFAULT '' COMMENT '组名',
  `num` int(11) NOT NULL DEFAULT '1' COMMENT '线程数',
  `class_name` varchar(100) NOT NULL DEFAULT '' COMMENT '类全路径名',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否运行(0未运行;1已运行)',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_delete` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:未删除 1:已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_TOPIC` (`topic`),
  UNIQUE KEY `UNIQUE_CLASS_NAME` (`class_name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='kafka消息队列记录表';

/*Data for the table `gfd_zadmin_kafka` */

insert  into `gfd_zadmin_kafka`(`id`,`name`,`topic`,`group_id`,`num`,`class_name`,`status`,`create_time`,`modified_time`,`is_delete`) values (16,'暂估入库处理','tms_result','tms_result',3,'com.sfbest.financial.certification.zamessage.TemporaryStorageMessage',1,1490601786,'2017-05-19 18:25:29',0),(17,'暂估入库处理-结果数据','tsrm_result','tsrm_result',3,'com.sfbest.financial.certification.zamessage.TemporaryStorageResultMessage',1,1490671346,'2017-05-19 18:25:32',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


DELIMITER $$

USE `gfm_db`$$

DROP PROCEDURE IF EXISTS `proc_gfm_getcode`$$

CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `proc_gfm_getcode`(IN p_code_start VARCHAR(100))
BEGIN
DECLARE p_date CHAR(8);
DECLARE p_now CHAR(8);
DECLARE p_return VARCHAR(30);
DECLARE p_nowno INT;
SET p_now=DATE_FORMAT(NOW(), '%Y%m%d') ;
SET p_date=IFNULL((SELECT a.date_apply FROM gfm_webcode a WHERE  a.code_start=p_code_start),'');
IF(p_date='')
THEN 
	INSERT INTO `gfm_webcode`
	(
	`uid`,
	`code_start`,
	`date_apply`,
	`min_number`,
	`now_number`)
	VALUES
	(
		REPLACE(UUID(),'-',''),
		p_code_start,
		p_now,
		100000,
		100000
	);
	SET p_date=p_now;
END IF;
 IF(p_date!=p_now) THEN
	
	IF LENGTH(p_date)!=8 THEN
		SET p_now='';
	ELSE
		UPDATE gfm_webcode SET now_number=min_number,date_apply=p_now WHERE code_start=p_code_start AND flag_date=1;
	END IF;
END IF;
START TRANSACTION; 
SET p_return=(SELECT now_number FROM gfm_webcode gfm  WHERE gfm.code_start=p_code_start FOR UPDATE);
SET p_return=p_return+1;
UPDATE gfm_webcode SET now_number=p_return WHERE code_start=p_code_start;
COMMIT;
SELECT CONCAT(p_now,p_return) AS webcode;
END$$

DELIMITER ;